# Replaces the YOUR-ACCOUNT placeholder in the package's links with your GitHub user or organisation.
# Usage (PowerShell, from the repository root):
#   ./Tools~/Set-GitHubAccount.ps1 -Account my-company
param([Parameter(Mandatory = $true)][string]$Account)

$root  = Split-Path -Parent $PSScriptRoot
$files = @('package.json', 'README.md', 'Documentation~/index.md', 'Documentation~/index.html')
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)   # Unity's JSON parser dislikes a BOM

foreach ($rel in $files) {
    $path = Join-Path $root $rel
    if (-not (Test-Path $path)) { continue }
    $text = [System.IO.File]::ReadAllText($path)
    [System.IO.File]::WriteAllText($path, $text.Replace('YOUR-ACCOUNT', $Account), $utf8NoBom)
    Write-Host "Updated $rel"
}
Write-Host "Done. Commit, then tag the release:  git tag v1.4.0 ; git push --tags"
