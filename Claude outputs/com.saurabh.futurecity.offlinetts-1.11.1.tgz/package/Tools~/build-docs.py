#!/usr/bin/env python3
"""
FutureCity Offline TTS — documentation builder. Run before every release (from the repository root):

    python Tools~/build-docs.py

It
  1. reads the version, Unity requirement and dependencies from package.json,
  2. reads every release (version, date, notes) from CHANGELOG.md,
  3. rewrites the version banner and the "Version & release history" section in Documentation~/index.md,
  4. regenerates the offline HTML (Documentation~/index.html) used by FutureCity ▸ Plugins ▸ OfflineTTS ▸ Documentation.

Requires:  pip install markdown
"""
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
DOCS_MD = ROOT / "Documentation~" / "index.md"
DOCS_HTML = ROOT / "Documentation~" / "index.html"

ORT_PACKAGE = "com.github.asus4.onnxruntime"
ORT_VERSION = "0.4.9"          # keep in sync with Editor/Installer/TTSPackageInstaller.cs (OrtVersion)
MODEL = "Supertonic 3 (31 languages, 10 voices)"

# Hand-written compatibility notes per version (shown in the docs; only versions that need a note).
UPGRADE_NOTES = {
    "1.11.1": "Fix for Addressables / AssetBundles: baked clips are matched by name. Run Repair Timing Library once and rebuild; no re-baking needed. Keep baked clip names unique.",
    "1.11.0": "Adds the Plugin Test Scene (Playground). Built on 1.10.1: the 1.10.2 changes are withdrawn (use the DialogueTTSVoice.cs from the integration bundle that matches 1.10.1).",
    "1.10.1": "Fix for highlighting that works in the Editor but not in builds. After updating, make a new build (timings are synced and preloaded automatically).",
    "1.10.0": "TextMeshPro is now installed with the plugin (and its essentials imported automatically). Nothing to change in existing projects; re-create the test scenes to get the new subtitles.",
    "1.9.2": "Performance fix: update from 1.9.1 if Play mode freezes or the frame rate drops (especially with music/ambience playing or TTS Auto Highlight in the scene). No setup changes.",
    "1.9.1": "Bug fix + diagnostics. If a baked clip sometimes doesn't highlight, turn on Debug Log on the TTS Speaker and the TTS Word Highlighter, and run Repair Timing Library once.",
    "1.9.0": "RENAMED to com.xrlab.offlinetts / namespace XRLAB.OfflineTTS. Remove the old package first, install the new one (new Git URL or .tgz), then update your scripts' 'using XRLP.OfflineTTS;' to 'using XRLAB.OfflineTTS;' and asmdef references to XRLAB.OfflineTTS(.TMP). Script GUIDs are unchanged, so scenes keep their components. See 'Migrating from com.xrlp.offlinetts'.",
    "1.8.0": "New optional component (TTS Auto Highlight). Nothing changes until you add it. To make highlighting automatic in a project, run FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Auto Highlight To Scene.",
    "1.7.1": "Bug fix only (Unity 6 compile error in the Word Timing Generator). Update from 1.7.0 if you see CS0619 about preloadAudioData.",
    "1.7.0": "Menus moved to FutureCity ▸ Plugins ▸ OfflineTTS (existing components are unaffected). Settings asset is now found automatically and added to Preloaded Assets at build time. For baked/recorded highlighting, put a TTS Speaker on the AudioSource that plays the clip.",
    "1.6.0": "New Editor tool only (Batch Add TTS Speakers). No runtime changes. Changes to prefab assets are saved directly (no Undo): commit first or use the tool's Remove button.",
    "1.5.2": "Documentation and About window only. No API or behaviour changes.",
    "1.5.1": "Adds per-text highlight settings on TTS Word Highlighter. Existing components keep working (all new settings start unticked).",
    "1.5.0": "Dialogue bridges need 1.5.0+. `TTSSpeaker` now stops its line if another script stops or replaces the clip on its AudioSource. Rich-text tags are no longer spoken.",
    "1.4.0": "Install from Git/tarball with automatic setup. ONNX Runtime moved from package.json to the project manifest (added by the installer). New .meta GUIDs: scenes built with an earlier, embedded copy may show 'Missing script' unless the old .meta files were kept.",
    "1.3.0": "`TTSSpeaker.SpeakAsync` returns `Task<bool>` (true = finished, false = stopped).",
}

BANNER_START, BANNER_END = "<!-- VERSION-BANNER:START -->", "<!-- VERSION-BANNER:END -->"
SECTION_START, SECTION_END = "<!-- VERSION-SECTION:START -->", "<!-- VERSION-SECTION:END -->"


def parse_changelog(text):
    """[(version, date, body_markdown)] newest first."""
    releases = []
    parts = re.split(r"^## \[(\d+\.\d+\.\d+)\](?:\s*-\s*(\S+))?\s*$", text, flags=re.M)
    for i in range(1, len(parts), 3):
        version, date, body = parts[i], parts[i + 1] or "", parts[i + 2].strip()
        body = re.sub(r"^### ", "##### ", body, flags=re.M)   # nest under the release heading
        releases.append((version, date, body))
    return releases


def first_line(body):
    for line in body.splitlines():
        line = line.strip()
        if line.startswith("- "):
            text = re.sub(r"\*\*|`", "", line[2:])
            text = re.split(r"(?<=[.;])\s|\s\(", text)[0].rstrip(":;.")
            return text[:110] + ("…" if len(text) > 110 else "")
    return ""


def build_banner(pkg, releases):
    date = releases[0][1] if releases else ""
    return (f"{BANNER_START}\n"
            f"> **Version {pkg['version']}**{f' · released {date}' if date else ''} · "
            f"Unity {pkg.get('unity', '?')}+ · see [Version & release history](#17-version-and-release-history)\n"
            f"{BANNER_END}")


def build_section(pkg, releases):
    v, date = pkg["version"], (releases[0][1] if releases else "")
    deps = pkg.get("dependencies", {})
    lines = [SECTION_START, "## 17. Version and release history", "",
             "### This documentation", "",
             "| | |", "|---|---|",
             f"| Package | `{pkg['name']}` — {pkg.get('displayName', '')} |",
             f"| **Version** | **{v}** |",
             f"| Released | {date or '—'} |",
             f"| Unity | {pkg.get('unity', '?')} or newer |",
             f"| ONNX Runtime | `{ORT_PACKAGE}` {ORT_VERSION} (added to the project automatically) |"]
    for name, ver in deps.items():
        lines.append(f"| Dependency | `{name}` {ver} |")
    lines += [f"| Voice model | {MODEL} — downloaded separately |", "",
              "### Check the version installed in your project", "",
              "* **FutureCity ▸ Plugins ▸ OfflineTTS ▸ About** shows the installed package version, ONNX Runtime version, Unity "
              "version and whether the models are present, with buttons for this documentation and the changelog.",
              "* **Window ▸ Package Manager ▸ In Project ▸ FutureCity Offline TTS**: version on the right. *Version History* lists other versions.",
              "* Git installs: the tag at the end of the URL in `Packages/manifest.json` (e.g. `#v" + v + "`). "
              "Tarball installs: the file name (`com.saurabh.futurecity.offlinetts-" + v + ".tgz`).",
              "* From code: `UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SaurabhFutureCity.OfflineTTS.OfflineTTS).Assembly).version`.",
              "",
              "### Updating", "",
              "* **Git:** change the tag in `Packages/manifest.json` (or reinstall with the new `#vX.Y.Z` URL).",
              "* **Tarball:** install the new `.tgz` with a new file name; don't overwrite the old file in place.",
              "* Read the upgrade notes below for every version between yours and the new one.",
              "",
              "### Releases at a glance", "",
              "| Version | Released | Highlights | Upgrade notes |", "|---|---|---|---|"]
    for ver, d, body in releases:
        note = UPGRADE_NOTES.get(ver, "—")
        lines.append(f"| {'**' + ver + '**' if ver == v else ver} | {d or '—'} | {first_line(body)} | {note} |")
    lines += ["", "### Full changelog", ""]
    for ver, d, body in releases:
        lines += [f"#### {ver}{f' — {d}' if d else ''}", "", body, ""]
    lines.append(SECTION_END)
    return "\n".join(lines)


def replace_block(text, start, end, new, insert_before=None, insert_after=None):
    if start in text and end in text:
        return re.sub(re.escape(start) + r".*?" + re.escape(end), lambda _: new, text, flags=re.S)
    if insert_after and insert_after in text:
        i = text.index(insert_after) + len(insert_after)
        return text[:i] + "\n\n" + new + "\n" + text[i:]
    if insert_before and insert_before in text:
        i = text.index(insert_before)
        return text[:i] + new + "\n\n---\n\n" + text[i:]
    return text.rstrip() + "\n\n---\n\n" + new + "\n"


def ensure_toc(text):
    entry = "17. [Version and release history](#17-version-and-release-history)"
    if entry in text:
        return text
    return re.sub(r"(^16\. \[FAQ\]\(#16-faq\)\s*$)", r"\1\n" + entry, text, count=1, flags=re.M)


def render_html(md_text):
    try:
        import markdown
    except ImportError:
        sys.exit("Install the markdown package first:  pip install markdown")
    body = markdown.markdown(md_text, extensions=["tables", "fenced_code", "toc", "md_in_html"])
    template = DOCS_HTML.read_text(encoding="utf-8")
    head = template[:template.index("<main>") + len("<main>")]
    tail = template[template.index("</main>"):]
    ids = set(re.findall(r'id="([^"]+)"', body))
    broken = sorted(set(re.findall(r'href="#([^"]+)"', body)) - ids)
    if broken:
        print("WARNING: broken in-page links:", broken)
    return head + "\n" + body + "\n" + tail


def main():
    pkg = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
    releases = parse_changelog((ROOT / "CHANGELOG.md").read_text(encoding="utf-8"))
    if not releases or releases[0][0] != pkg["version"]:
        print(f"WARNING: package.json is {pkg['version']} but the newest CHANGELOG entry is "
              f"{releases[0][0] if releases else 'missing'}. Add a CHANGELOG entry for this version.")

    md = DOCS_MD.read_text(encoding="utf-8")
    md = re.sub(r"#v\d+\.\d+\.\d+", f"#v{pkg['version']}", md)                      # install URLs in examples
    md = replace_block(md, BANNER_START, BANNER_END, build_banner(pkg, releases), insert_after=md.splitlines()[0])
    md = replace_block(md, SECTION_START, SECTION_END, build_section(pkg, releases))
    md = ensure_toc(md)
    DOCS_MD.write_text(md, encoding="utf-8")
    DOCS_HTML.write_text(render_html(md), encoding="utf-8")
    print(f"Docs updated for {pkg['name']} {pkg['version']} ({len(releases)} releases).")


if __name__ == "__main__":
    main()
