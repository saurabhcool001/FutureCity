// FutureCity Offline TTS — sample: word highlighting WITHOUT the TTS Auto Highlight component.
// Shows, in code, everything the auto component does for you, so you can build your own flow.
//
//   Example 1  Play a baked / recorded clip and highlight it (speaker + highlighter set up from code).
//   Example 2  Make word timings at runtime for a clip that has none (e.g. loaded from disk).
//   Example 3  Your own effect instead of the TextMeshPro highlighter (word events).
//   Example 4  Live TTS with highlighting.
using TMPro;
using UnityEngine;
using SaurabhFutureCity.OfflineTTS;

public class ManualHighlightExamples : MonoBehaviour
{
    [Tooltip("AudioSource that plays the voice (e.g. the NPC's voice object).")]
    public AudioSource voiceSource;
    [Tooltip("Text that shows the line.")]
    public TMP_Text subtitle;
    [Tooltip("A baked WAV (with its _Timing.asset) or a recording with timings.")]
    public AudioClip bakedClip;
    [TextArea] public string line = "Before you can enter, you need to check the safety signage at the entrance.";

    TTSSpeaker _speaker;
    TTSWordHighlighter _highlighter;

    void Awake()
    {
        // --- Speaker on the AudioSource that plays the clip (listen-only; keeps its 3D settings) ---
        // Don't use ?? with Unity objects: a missing component is a "fake null" in the Editor.
        _speaker = voiceSource.GetComponent<TTSSpeaker>();
        if (_speaker == null) _speaker = TTSSpeaker.AddTo(voiceSource.gameObject, "M1", configureSpatialAudio: false);
        _speaker.followExternalClips = true;

        // --- Highlighter on the text, bound to that speaker ---
        _highlighter = subtitle.GetComponent<TTSWordHighlighter>();
        if (_highlighter == null) _highlighter = subtitle.gameObject.AddComponent<TTSWordHighlighter>();
        _highlighter.Bind(_speaker);   // follow this speaker regardless of Listen To / text match
    }

    // Example 1 -------------------------------------------------------------------------------------------
    [ContextMenu("1. Play baked clip with highlight")]
    public void PlayBakedClip()
    {
        if (!TTSClipTimings.TryGet(bakedClip, out _))
            Debug.LogWarning("This clip has no word timings: bake with 'Save word timings' or use the Word Timing Generator.");

        subtitle.text = line;          // set the text first (or in the same frame)
        voiceSource.clip = bakedClip;
        voiceSource.Play();            // the speaker follows it → the highlighter highlights the current word
    }

    // Example 2 -------------------------------------------------------------------------------------------
    // Clips created or loaded at runtime have no timing asset. Make timings in memory and register them.
    // (The clip must be readable: AudioClip.Create, or imported with Load Type = Decompress On Load.)
    [ContextMenu("2. Make timings at runtime")]
    public void MakeTimingsAtRuntime()
    {
        var samples = new float[bakedClip.samples * bakedClip.channels];
        if (!bakedClip.GetData(samples, 0)) { Debug.LogWarning("Clip data isn't readable."); return; }
        if (bakedClip.channels > 1)
        {
            var mono = new float[bakedClip.samples];
            for (int i = 0; i < mono.Length; i++)
            {
                float sum = 0f;
                for (int c = 0; c < bakedClip.channels; c++) sum += samples[i * bakedClip.channels + c];
                mono[i] = sum / bakedClip.channels;
            }
            samples = mono;
        }

        var timing = ScriptableObject.CreateInstance<TTSClipTiming>();
        timing.clip = bakedClip;
        timing.text = TTSText.ToSpeakable(line);
        timing.words = WordTimingEstimator.EstimateLine(timing.text, samples, bakedClip.frequency, chunkSilence: 0.25f, maxChunkLength: 300);
        timing.source = TTSClipTiming.TimingSource.EstimatedFromRecording;
        TTSClipTimings.Register(timing);   // from now on, TTS Speakers follow this clip like a baked one
    }

    // Example 3 -------------------------------------------------------------------------------------------
    // Use the word events yourself (e.g. a karaoke bar, a world-space pointer, subtitles in another UI system).
    void OnEnable()
    {
        TTSSpeaker.AnyLineStarted += OnLineStarted;
        TTSSpeaker.AnyWordChanged += OnWordChanged;
        TTSSpeaker.AnyLineEnded += OnLineEnded;
    }

    void OnDisable()
    {
        TTSSpeaker.AnyLineStarted -= OnLineStarted;
        TTSSpeaker.AnyWordChanged -= OnWordChanged;
        TTSSpeaker.AnyLineEnded -= OnLineEnded;
    }

    void OnLineStarted(TTSSpeaker speaker, string spokenText) =>
        Debug.Log($"{speaker.name} started: \"{spokenText}\" ({speaker.CurrentLineWords.Count} words)");

    void OnWordChanged(TTSSpeaker speaker, int wordIndex)
    {
        if (wordIndex < 0) return;                             // between words / line ended
        string word = speaker.CurrentLineWords[wordIndex];     // the word being spoken now
        // speaker.CurrentWordProgress = 0..1 through that word
        // → drive your own effect here
    }

    void OnLineEnded(TTSSpeaker speaker) => Debug.Log($"{speaker.name} finished");

    // Example 4 -------------------------------------------------------------------------------------------
    [ContextMenu("4. Speak live with highlight")]
    public async void SpeakLive()
    {
        subtitle.text = line;
        bool finished = await _speaker.SpeakAsync(line);       // the bound highlighter follows live speech too
        Debug.Log(finished ? "Line finished" : "Line was stopped");
    }
}
