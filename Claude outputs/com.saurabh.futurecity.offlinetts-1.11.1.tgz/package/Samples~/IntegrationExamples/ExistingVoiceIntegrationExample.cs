// FutureCity Offline TTS — sample: adding TTS to a project that already has its own voice/audio script.
//
// Pattern (the same one a dialogue bridge uses):
//   1. Reuse the character's existing AudioSource: TTSSpeaker.AddTo(...) keeps its 3D settings.
//   2. Recorded clip first; speak with TTS only when there is no clip (or when you choose to).
//   3. Stop TTS before your own script plays a clip (TTS also stops by itself if another script
//      stops or replaces the clip on the shared AudioSource).
//   4. Optional: highlight the spoken word in the on-screen TextMeshPro text.
using TMPro;
using UnityEngine;
using SaurabhFutureCity.OfflineTTS;

public class ExistingVoiceIntegrationExample : MonoBehaviour
{
    [Tooltip("The character's existing AudioSource (e.g. the one your NPC voice script uses).")]
    public AudioSource characterAudio;
    [Tooltip("On-screen text for the line (optional, for word highlighting).")]
    public TMP_Text subtitle;
    [TTSVoice] public string voice = "M1";

    TTSSpeaker _speaker;

    void Awake()
    {
        // (Don't use ?? with Unity objects: in the Editor a missing component is a "fake null".)
        _speaker = characterAudio.GetComponent<TTSSpeaker>();
        if (_speaker == null) _speaker = TTSSpeaker.AddTo(characterAudio.gameObject, voice, configureSpatialAudio: false);
    }

    /// <summary>Call this wherever your system shows a line.</summary>
    public void ShowLine(string text, AudioClip recordedClip)
    {
        if (subtitle != null) subtitle.text = text;

        if (recordedClip != null)
        {
            _speaker.Stop();                        // 3. never talk over a recorded line
            characterAudio.clip = recordedClip;
            characterAudio.Play();
            return;
        }

        if (subtitle != null)                       // 4. word highlight
        {
            var highlighter = subtitle.GetComponent<TTSWordHighlighter>();
            if (highlighter == null) highlighter = subtitle.gameObject.AddComponent<TTSWordHighlighter>();
            highlighter.Bind(_speaker);
        }
        _speaker.Speak(text);                       // rich-text tags are removed automatically
    }

    /// <summary>Pre-generate known lines (e.g. during a fade) so they play instantly.</summary>
    public void Prewarm(string[] lines) => _ = _speaker.PrewarmAsync(lines);
}
