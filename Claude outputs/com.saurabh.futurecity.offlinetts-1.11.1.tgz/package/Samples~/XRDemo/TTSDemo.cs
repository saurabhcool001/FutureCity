// FutureCity Offline TTS — sample usage.
using System.Threading.Tasks;
using UnityEngine;
using SaurabhFutureCity.OfflineTTS;

public class TTSDemo : MonoBehaviour
{
    public TTSSpeaker trainer;      // NPC with AudioSource (+ your lip sync component)
    public string[] lines =
    {
        "Hi, I'm your safety trainer. Before we start, look around the workshop.",
        "Check the load before you lift it. If it's too heavy, ask for help.",
    };

    async void Start()
    {
        var tts = OfflineTTS.GetOrCreate();
        await tts.InitializeAsync();

        // Optional: make an extra voice by blending two presets (cheap way to give 30+ NPCs distinct voices).
        var a = await tts.GetVoiceAsync("F2");
        var b = await tts.GetVoiceAsync("F4");
        tts.RegisterVoice(VoiceStyle.Blend(a, b, 0.35f, "Trainer"));
        trainer.voice = "Trainer";

        // Pre-generate known lines during the fade-in so they play instantly (and are disk-cached next launch).
        await tts.PrewarmAsync(lines, new TTSRequest { voice = trainer.voice, seed = trainer.seed });

        foreach (var line in lines)
            await trainer.SpeakAsync(line);   // awaits until the line has finished playing
    }

    // Hook this to a dialogue node / UnityEvent with a dynamic string.
    public void SayDynamic(string text) => trainer.Speak(text);

    // Example: export a line as WAV at runtime (e.g. for a video pipeline on PC).
    public Task<string> Export(string text) =>
        OfflineTTS.Instance.SynthesizeToWavAsync(text, System.IO.Path.Combine(Application.persistentDataPath, "export.wav"));
}
