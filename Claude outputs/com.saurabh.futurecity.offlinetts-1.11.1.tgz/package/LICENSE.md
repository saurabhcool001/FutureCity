# License

Copyright (c) 2026 XRLAB. All rights reserved.

This package's source code is proprietary unless your organisation chooses to publish it under a different
licence. Replace this file with your chosen licence (for example MIT) before making the repository public.

Third-party components keep their own licences. See THIRD_PARTY_NOTICES.md.
The Supertonic 3 model weights are NOT included in this package and are licensed separately under OpenRAIL-M.
