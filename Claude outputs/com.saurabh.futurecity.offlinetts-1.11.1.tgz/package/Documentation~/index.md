# FutureCity Offline TTS — Documentation

<!-- VERSION-BANNER:START -->
> **Version 1.11.1** · released 2026-11-07 · Unity 2022.3+ · see [Version & release history](#17-version-and-release-history)
<!-- VERSION-BANNER:END -->


Fully offline, on-device neural **text-to-speech for Unity**, built for XR training content.
It runs the open **Supertonic 3** voice model on **ONNX Runtime**: 31 languages, 10 voices
(5 female, 5 male), and no cloud, API keys, or per-character cost.

| | |
|---|---|
| Package | `com.saurabh.futurecity.offlinetts` |
| Unity | 2022.3 LTS or newer (tested target: Unity 6) |
| Platforms | Meta Quest / Pico / Android XR (ARM64), Windows (PC VR), macOS (Apple Silicon), Linux, Editor |
| Not supported | WebGL, iOS / visionOS, 32-bit Android |
| Model size | ≈ 400 MB (downloaded separately, not part of the package) |

**Contents**

1. [Installation](#1-installation)
2. [Getting the voice models](#2-getting-the-voice-models)
3. [Quick start](#3-quick-start)
4. [Components](#4-components)
5. [Settings asset](#5-settings-asset)
6. [Scripting API](#6-scripting-api)
7. [Editor tools](#7-editor-tools)
8. [Testing](#8-testing)
9. [Videos and voice-over](#9-videos-and-voice-over)
10. [Integrating with an existing voice or dialogue system](#10-integrating-with-an-existing-voice-or-dialogue-system)
11. [Performance on standalone headsets](#11-performance-on-standalone-headsets)
12. [Building for Quest and Android](#12-building-for-quest-and-android)
13. [Version control and teams](#13-version-control-and-teams)
14. [Troubleshooting](#14-troubleshooting)
15. [Licensing](#15-licensing)
16. [FAQ](#16-faq)

17. [Version and release history](#17-version-and-release-history)
---

## 1. Installation

### Option A — Git URL (recommended)

1. Open **Window ▸ Package Manager**.
2. Click **+ ▸ Install package from git URL…**
3. Paste the repository URL, optionally with a version tag:

   ```
   https://github.com/YOUR-ACCOUNT/com.saurabh.futurecity.offlinetts.git#v1.11.1
   ```

4. Click **Install**.

Then let the automatic setup run (below). Within a few seconds the **FutureCity ▸ Plugins ▸ OfflineTTS** menu appears.

> Requires Git installed on the machine and available on PATH. For a private repository, the user also needs
> Git credentials for it (credential manager, SSH URL `git@github.com:…`, or a token).

### Option B — From disk (folder or tarball)

* **Folder:** Package Manager ▸ **+ ▸ Install package from disk…** ▸ select `package.json`.
  Or copy the folder into your project's `Packages/` folder (an "embedded" package that you can edit).
* **Tarball:** Package Manager ▸ **+ ▸ Install package from tarball…** ▸ select `com.saurabh.futurecity.offlinetts-x.y.z.tgz`.

### What the automatic setup does

Unity packages can't declare package registries themselves, and the ONNX Runtime dependency lives on the npm
registry. The first time the package loads, a small installer edits **`Packages/manifest.json`** for you:

| Adds | Why |
|---|---|
| `scopedRegistries` → `https://registry.npmjs.com` with scope `com.github.asus4` | Where ONNX Runtime for Unity is published |
| `dependencies` → `"com.github.asus4.onnxruntime": "0.4.9"` | The inference engine (native libraries for every platform) |
| `testables` → `"com.saurabh.futurecity.offlinetts"` | So the package's tests show up in the Test Runner |
| `com.unity.textmeshpro` (Unity 2022.3 only) | TextMeshPro for word highlighting and subtitles. From Unity 2023.2 / Unity 6, TextMeshPro is part of uGUI, which this package depends on. |
| **TMP Essential Resources** (imported into `Assets/TextMesh Pro`) | TextMeshPro's default font, shaders and settings. Without them TextMeshPro text is invisible. Imported automatically if missing. |

It then asks the Package Manager to resolve. Until ONNX Runtime is present, the rest of the package is excluded
from compilation, so you won't see compile errors in between.

The installer only adds entries, never removes them, and it reuses an existing npm registry entry if you have one.
It runs once per Editor session and does nothing if everything is already in place.

Menu: **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Setup**

* **Repair Project Setup**: run the installer again (e.g. after someone edited the manifest).
* **Toggle Automatic Setup**: turn the automatic check on or off for this machine.
* **Toggle Add To Testables**: choose whether the installer adds the package to `testables`.

<details>
<summary>Manual setup (if you prefer to edit the manifest yourself)</summary>

```json
{
  "scopedRegistries": [
    { "name": "npmjs", "url": "https://registry.npmjs.com", "scopes": ["com.github.asus4"] }
  ],
  "dependencies": {
    "com.github.asus4.onnxruntime": "0.4.9",
    "com.saurabh.futurecity.offlinetts": "https://github.com/YOUR-ACCOUNT/com.saurabh.futurecity.offlinetts.git#v1.11.1"
  },
  "testables": ["com.saurabh.futurecity.offlinetts"]
}
```
</details>

### Dependencies

| Package | Source | Purpose |
|---|---|---|
| `com.github.asus4.onnxruntime` 0.4.9 | npm (added by the installer) | ONNX Runtime + native plugins |
| `com.unity.nuget.newtonsoft-json` 3.2.1 | Unity registry (automatic) | Reading model/voice JSON |
| `com.unity.ugui` (includes **TextMeshPro** in Unity 6) | Unity registry (automatic) | Word highlighting, subtitles, UI |
| `com.unity.textmeshpro` 3.0.x | added by the installer on Unity 2022.3 | TextMeshPro on older Unity versions |
| `com.unity.xr.interaction.toolkit` 3.x | *optional* | Enables the VR test scene and XR components |

### Updating and removing

* **Update:** Package Manager ▸ FutureCity Offline TTS ▸ **Update**. For Git installs, change the `#tag` in the URL and
  reinstall, or edit the tag in `manifest.json`.
* **Remove:** Package Manager ▸ **Remove**. Optionally also delete `Assets/StreamingAssets/Supertonic`,
  `Assets/Features/TTS` and `Assets/OfflineTTS_Test`, and remove the `scopedRegistries` / ONNX Runtime /
  `testables` entries that the installer added.

---

### Migrating from com.xrlab.offlinetts (XRLAB Offline TTS)

The package is now **`com.saurabh.futurecity.offlinetts`** (*FutureCity Offline TTS*) and the namespace is
**`SaurabhFutureCity.OfflineTTS`**. Script IDs (GUIDs) are unchanged, so components, settings, timing assets and prefabs keep working.

1. Commit your project.
2. **Remove the old package:** Package Manager ▸ *XRLAB Offline TTS* ▸ **Remove**, or delete the
   `com.xrlab.offlinetts` line from `Packages/manifest.json`. For an embedded copy, delete the
   `Packages/com.xrlab.offlinetts` folder with Unity closed.
3. **Install the new one** (.tgz or Git). If a project still lists the old package, the installer removes it automatically.
4. **Update your own code** (only if you wrote scripts against the plugin):
   * `using XRLAB.OfflineTTS;` → `using SaurabhFutureCity.OfflineTTS;` (and `.Editor`, `.XR`, `.TMP`)
   * asmdef references `XRLAB.OfflineTTS*` → `SaurabhFutureCity.OfflineTTS*`
   * `#if XRLAB_ORT` / `XRLAB_TMP` / `XRLAB_XRI3` → `FUTURECITY_ORT` / `FUTURECITY_TMP` / `FUTURECITY_XRI3`
   * version defines on `com.xrlab.offlinetts` → `com.saurabh.futurecity.offlinetts`
5. Open the project, check **FutureCity ▸ Plugins ▸ OfflineTTS ▸ About**, and commit `manifest.json` and `packages-lock.json`.

### Migrating from com.xrlp.offlinetts (before 1.9.0)

From **1.9.0** the package is **`com.xrlab.offlinetts`** (*XRLAB Offline TTS*) and the namespace is **`XRLAB.OfflineTTS`**.
Script IDs (GUIDs) are unchanged, so components, settings, timing assets and prefabs keep working.

1. Commit your project.
2. **Remove the old package:** Package Manager ▸ *XRLP Offline TTS* ▸ **Remove**, or delete the
   `com.xrlp.offlinetts` line from `Packages/manifest.json`. For an embedded copy, delete the
   `Packages/com.xrlp.offlinetts` folder with Unity closed.
3. **Install the new one:** Git `https://github.com/<you>/com.xrlab.offlinetts.git#v1.11.1`, or
   `com.xrlab.offlinetts-1.9.0.tgz`. If a project still lists the old package, the installer removes it automatically.
4. **Update your own code** (only if you wrote scripts against the plugin):
   * `using XRLP.OfflineTTS;` → `using XRLAB.OfflineTTS;` (also `XRLP.OfflineTTS.Editor` → `XRLAB.OfflineTTS.Editor`)
   * asmdef references `XRLP.OfflineTTS` / `XRLP.OfflineTTS.TMP` → `XRLAB.OfflineTTS` / `XRLAB.OfflineTTS.TMP`
   * version defines on `com.xrlp.offlinetts` → `com.xrlab.offlinetts`
5. Open the project, check **XRLab ▸ Plugins ▸ OfflineTTS ▸ About** (1.9.0), and commit `manifest.json` and
   `packages-lock.json`.

Your settings asset, model files (`StreamingAssets/Supertonic`), baked clips and timing assets don't need any change.

## 2. Getting the voice models

The model weights (≈ 400 MB) are **not** inside the package. Get them once per project:

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Download Supertonic 3 Models**

This downloads into `Assets/StreamingAssets/Supertonic/`:

```
Assets/StreamingAssets/Supertonic/
├── onnx/
│   ├── duration_predictor.onnx
│   ├── text_encoder.onnx
│   ├── vector_estimator.onnx
│   ├── vocoder.onnx
│   ├── tts.json
│   └── unicode_indexer.json
├── voice_styles/
│   ├── F1.json … F5.json      (female)
│   └── M1.json … M5.json      (male)
└── LICENSE                    (model licence — ship it with your app)
```

**Manual alternative:**

```
hf download supertone-oss-archive/supertonic-3 --local-dir Assets/StreamingAssets/Supertonic
```

Only `onnx/` and `voice_styles/` are needed. To use a mirror, change the URL in the Voice-over Baker
(shown when models are missing) before downloading.

**After this step everything runs fully offline.** At runtime the package makes no network requests.

---

## 3. Quick start

1. **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create or Locate Settings Asset**: finds your existing `TTSSettings` asset, or
   creates `Assets/Features/TTS/OfflineTTSSettings.asset`.
2. **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add TTS Service To Scene** in your first scene.
3. On a character, add an **AudioSource** and a **TTS Speaker**. Pick a **Voice** and **Language** from the dropdowns.
4. Call it from a button, UnityEvent or script:

```csharp
using SaurabhFutureCity.OfflineTTS;

public class Hello : MonoBehaviour
{
    public TTSSpeaker speaker;
    void Start() => speaker.Speak("Hello! Please put on your safety glasses.");
}
```

5. Press Play.

---

## 4. Components

Hover over any field in the Inspector for a detailed tooltip. The tables below repeat that information.

### 4.1 Offline TTS (service)

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add TTS Service To Scene** (or *Add Component ▸ FutureCity ▸ Plugins ▸ OfflineTTS*).
One per app. It owns the model, the voices and the audio cache. If none exists, one is created automatically on first
use. From 1.7.0 that automatic service uses your **project's settings asset** (found automatically; in builds it is
added to *Player Settings ▸ Preloaded Assets* at build time), so your settings apply even in scenes without a service.

| Field | Description |
|---|---|
| Settings | The `TTSSettings` asset. Empty = built-in defaults. |
| Initialize On Awake | Start loading the model immediately. Off = call `InitializeAsync()` yourself (e.g. behind a loading screen). |
| Dont Destroy On Load | Keep the service (and loaded model) across scene loads. |
| Preload Voices | Voices loaded together with the model; others load on first use. |
| On Ready | Event: model loaded, speech can be generated. |
| On Error | Event: loading failed (message passed). |

### 4.2 TTS Speaker

Put it on any character next to its **AudioSource**. Speech plays through that AudioSource, so **lip sync**,
spatializers, mixers and Unity Recorder treat it exactly like recorded dialogue.

| Field | Description |
|---|---|
| Voice | Dropdown: Female 1–5 (F1–F5), Male 1–5 (M1–M5), plus extra voice files found in `voice_styles/`. |
| Language | Dropdown of the 31 supported languages. The text must already be in that language (no translation). |
| Speed | Speaking rate; 1.0 natural, < 1 slower, > 1 faster (pitch unchanged). -1 = settings default. |
| Steps | Quality steps 1–16 (higher = cleaner, slower). -1 = settings default. |
| Seed | Fixed seed = identical delivery each time and effective caching. Different numbers give different takes. -1 = random. |
| Stream Sentences | Start talking after the first sentence is ready; generate the rest while playing. |
| Interrupt | A new `Speak()` stops the current line (on) or queues after it (off). |
| Configure Spatial Audio | Sets up the AudioSource for 3D VR audio on Awake. Off = keep your own AudioSource settings. |
| Debug Log | Off. Logs lines started/finished/dropped, clips followed, and clips ignored because they have no word timings. |
| Follow External Clips | On (default): when another script plays a **baked or recorded clip with word timings** on this AudioSource (an NPC voice script, a dialogue system, Timeline), the speaker follows it and drives word highlighting like live TTS (§4.8). |
| On Speech Started / Finished / Error | Events with the line text (or the error message). *Finished* is not raised for stopped lines. |

Runtime properties: `IsSpeaking`, `IsGenerating`, `Source` (the AudioSource).

### 4.3 TTS Video Narrator

Speaks timed cues over a **VideoPlayer** (flat screens or 360° video). All cues are generated *before* the video
starts, so they fire exactly on time.

| Field | Description |
|---|---|
| Video Player | The VideoPlayer to narrate. |
| Narration Source | AudioSource for the narration (auto-created). 2D = "voice in your head"; 3D = from the screen. |
| Voice / Language / Speed / Seed | As on TTS Speaker. |
| Prepare Before Play | Generate every cue first, then start the video. |
| Play On Start | Start the video automatically after preparing. |
| Video Duck Volume | Video soundtrack volume while the narrator speaks (Audio Output Mode must be *Direct*). |
| Cues | Time (s), Text, optional per-cue Voice, *Pause Video While Speaking*. |
| On Ready / On Cue Started | Events (e.g. hide a loading UI, show subtitles). |

It follows pause, resume and seeking: seeking backwards re-arms cues, and cues far behind the playhead are skipped.

### 4.4 XR components (need XR Interaction Toolkit 3.x)

| Component | Purpose |
|---|---|
| **Talk On Interact** | Makes any XRI interactable speak. Trigger: *Select* (grip/ray/poke), *Activate* (trigger while held), *Hover Enter*. Lines in order or random. |
| **VR Test Panel** | World-space test UI: character selector, female/male voice grid, text box with VR keyboard, Speak/Stop, settings, voice preview, benchmark. |
| **Simulator Auto Disable** | Removes the XR simulator in builds and when a real headset is active (e.g. Quest Link). |

These compile only when XRI ≥ 3.0 is installed, so projects without XRI are unaffected.

### 4.5 TTS Word Highlighter (TextMeshPro)

Highlights the word currently being spoken in any TextMeshPro text (UI or 3D): the word is recoloured and
pops/zooms in, then the next word takes over. Add it to the text that shows the line.

| Field | Description |
|---|---|
| Listen To | *Any Speaker With Matching Text* (default: follows whichever speaker says what this text shows, no setup), *Specific Speakers* (only the listed ones), *Bound From Code* (only the speaker passed to `Bind()`, as dialogue integrations do). |
| Speakers | Used with *Specific Speakers*. |
| Minimum Match | For *Any Speaker…*: share of spoken words that must appear in this text before it follows that speaker. |
| Debug Log | Off. Logs which speaker it follows and why, and how many spoken words matched this text (0 = wording differs from the screen). |

| **Look — this text only** | Every highlight setting (Enabled, Apply Color, Highlight Color, Zoom Scale, Pop Duration, Bounce, Hold Zoom While Spoken, Lift, Tint Spoken Words, Spoken Word Color) with a tick box. Tick a setting to override it **for this text only**. Unticked settings use the parent TTS Override or the global value. |

**Customising one text (Inspector buttons):**

* **Customise all** ticks every setting and fills it with the values this text currently uses, so you can tweak from there.
* **Use global** unticks everything, so the text follows the parent TTS Overrides and the settings asset again.
* **Effective look** shows the final values this text will use.
* **Preview** (Play mode) steps through the text's words without speech so you can see the look. *Preview speed* sets the seconds per word. From code: `highlighter.PreviewHighlight(0.35f)`.

**Order (last wins):** settings asset → TTS Override components on parents → the highlighter's own *Look* values.

The highlight's look comes from the settings asset (**Word Highlight** section, §5). You can change it for a
group of objects with a **TTS Override** on a parent (§4.6), or for one text with the highlighter's own **Look** settings. Words are matched in order, ignoring case, punctuation and
rich-text tags. A word spoken differently from how it's shown (e.g. "5 kg" spoken as "five kilograms") is
simply not highlighted, and the following words re-sync.

**How word timing works:** the voice model doesn't report word timestamps, so they're estimated from the
audio. Each sentence's speaking time is shared out by word length, with extra room after commas and full
stops, then every boundary is snapped to the quietest moment nearby, which is where real gaps between words
are. It's accurate enough to follow along, but not for phoneme-level lip sync (your lip-sync system still
analyses the actual audio).

TextMeshPro is installed together with the plugin (since 1.10.0), so this component is always available. It lives
in the `SaurabhFutureCity.OfflineTTS.TMP` assembly, which compiles once TextMeshPro is present
(`com.unity.textmeshpro` or `com.unity.ugui` 2.0+).

### 4.6 TTS Override

Changes global TTS settings for **one object and everything under it**. For example, turn word highlighting
off on a few cards, use a different highlight colour on a warning panel, or give a whole area a different voice.

1. Add **TTS Override** to the object (a card, a dialogue box, an NPC, a scene root).
2. Tick only the settings you want to change. Unticked settings keep the global value.

| Group | Settings |
|---|---|
| Speech | Speech Enabled, Voice, Language, Speed, Steps, Seed, Stream Sentences |
| Word Highlight | Highlight Enabled, Apply Color, Highlight Color, Zoom Scale, Pop Duration, Bounce, Hold Zoom While Spoken, Lift, Tint Spoken Words, Spoken Word Color |

* **Apply To Children** off = only components on the same GameObject are affected.
* **Nested overrides:** for each setting, the override closest to the object wins.
* **Precedence for speech:** values a script passes in a `TTSRequest` > nearest TTS Override > TTS Speaker fields > settings asset.
* **Precedence for highlight:** the text's own TTS Word Highlighter *Look* > nearest TTS Override > settings asset.
* **Speech Enabled = off** makes TTS Speakers under that object stay silent (`SpeakAsync` returns `false`), and
  dialogue integrations skip TTS there (the recorded clip still plays if there is one).

### 4.7 TTS Test Bench (PC)

On-screen IMGUI panel for Play-mode testing in the Game view (no XR rig needed). It offers voice, language, steps,
speed and seed, Speak, timed generation, WAV export and a benchmark. **F1** toggles it (legacy Input Manager only).

---

### 4.8 Word highlighting for baked and recorded clips

Highlighting isn't limited to live TTS. Any voice clip can drive it once it has **word timings**: a WAV baked with
the Voice-over Baker, a human voice-over recording, or audio from another TTS. There are three ways to set it up.
All three give the same result, so pick whichever fits the project.

| Way | You do | Best for |
|---|---|---|
| **A. Automatic** | Add one **TTS Auto Highlight** to the scene | Most projects, other users, quick setup |
| **B. Manual (Inspector)** | Add a TTS Speaker and a TTS Word Highlighter yourself | Full control over which objects are involved |
| **C. Manual (code)** | Set it up from your own scripts | Custom systems, runtime-loaded clips, your own effects |

#### Step 0 (all ways): make word timings

| Clip | How |
|---|---|
| Baked with the Voice-over Baker | Keep **Save word timings** on (default). Exact per-sentence timings, as accurate as live TTS. |
| Human recording / any other clip | **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Word Timing Generator** (§7.2): add the clips, give each one the exact words it says (type it, or load `clipName \| text` lines), press **Generate word timings**. Estimated from the audio and the text. |
| Clip created or loaded at runtime | In code. See *C. Manual (code)*, example 2. |

Timings are saved as `<clip>_Timing.asset` next to the clip and added to the **timing library**
(`Assets/Features/TTS/TTSTimingLibrary.asset`), which is linked in the settings asset (*Timing Libraries*) automatically.
Before every build, all timing assets in the project are added to this library automatically, the library is linked
to every settings asset and added to *Preloaded Assets*, so builds always contain them (1.10.1+). You can do the same any
time with **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Repair Timing Library**. Note: preloaded timings reference their clips, so
those clips are loaded when the app starts.

**Write the clip's text with the same wording as the on-screen text.** Highlighting matches spoken words to on-screen
words (ignoring case, punctuation and rich-text tags); words that differ simply aren't highlighted.

#### A. Automatic: TTS Auto Highlight

1. **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Auto Highlight To Scene** (or *Add Component ▸ FutureCity ▸ Plugins ▸ OfflineTTS ▸
   TTS Auto Highlight* on any object).
2. Play clips and set texts exactly as your project already does (`AudioSource.Play()`, an NPC script, Timeline,
   a dialogue system). No code changes.

What it does:
* When an AudioSource **starts a clip that has word timings** and has no TTS Speaker, it adds a **listen-only TTS
  Speaker** to it (*Configure Spatial Audio* off, *Follow External Clips* on), keeping the AudioSource's settings.
* When a line starts (baked, recorded, or live TTS), it finds the **TextMeshPro text that best matches** the spoken
  words, adds a **TTS Word Highlighter** if needed, and binds it to that speaker.

Options are in §4.9. Turn on **Debug Log** to see in the Console which speaker was added and which text was matched.

#### B. Manual: Inspector only

1. **Speaker:** on the GameObject whose **AudioSource plays the clip** (e.g. the NPC's voice object), add **TTS
   Speaker**:
   * **Follow External Clips:** on (default)
   * **Configure Spatial Audio:** off if the AudioSource is already set up (e.g. by an NPC voice script)
   * many objects at once: **Batch Add TTS Speakers** (§7.1)
2. **Highlighter:** on the **TextMeshPro text** that shows the line, add **TTS Word Highlighter**:
   * **Listen To:** *Any Speaker With Matching Text* (default) follows whichever speaker says what this text shows.
     *Specific Speakers* follows only the listed ones.
   * **Minimum Match:** lower it (e.g. 0.3) if the screen text has extra words.
   * optional **Look — this text only** for a per-text style.
3. Play the clip as usual. Set the text **before or in the same frame** as the clip starts.

#### C. Manual: code

All of this is in the **Integration Examples** sample (`ManualHighlightExamples.cs`). Import it from
*Package Manager ▸ FutureCity Offline TTS ▸ Samples*.

**1. Speaker + highlighter from code, then play a baked clip**

```csharp
using TMPro;
using UnityEngine;
using SaurabhFutureCity.OfflineTTS;

public class PlayWithHighlight : MonoBehaviour
{
    public AudioSource voiceSource;   // plays the voice
    public TMP_Text subtitle;         // shows the line
    public AudioClip bakedClip;       // has a _Timing.asset

    TTSSpeaker _speaker;

    void Awake()
    {
        // Listen-only speaker on the AudioSource (keeps its 3D settings).
        // Don't use ?? with Unity objects: a missing component is a "fake null" in the Editor.
        _speaker = voiceSource.GetComponent<TTSSpeaker>();
        if (_speaker == null) _speaker = TTSSpeaker.AddTo(voiceSource.gameObject, "M1", configureSpatialAudio: false);
        _speaker.followExternalClips = true;

        // Highlighter on the text, bound to that speaker.
        var highlighter = subtitle.GetComponent<TTSWordHighlighter>();
        if (highlighter == null) highlighter = subtitle.gameObject.AddComponent<TTSWordHighlighter>();
        highlighter.Bind(_speaker);
    }

    public void Play(string text)
    {
        subtitle.text = text;          // text first (or the same frame)
        voiceSource.clip = bakedClip;
        voiceSource.Play();            // speaker follows the clip → current word highlights
    }
}
```

**2. Timings at runtime** (for clips without a timing asset, e.g. loaded from disk or created with `AudioClip.Create`;
the clip must be readable)

```csharp
var samples = new float[clip.samples * clip.channels];
clip.GetData(samples, 0);                                  // downmix to mono first if clip.channels > 1

var timing = ScriptableObject.CreateInstance<TTSClipTiming>();
timing.clip = clip;
timing.text = TTSText.ToSpeakable(lineText);
timing.words = WordTimingEstimator.EstimateLine(timing.text, samples, clip.frequency,
                                                chunkSilence: 0.25f, maxChunkLength: 300);
timing.source = TTSClipTiming.TimingSource.EstimatedFromRecording;
TTSClipTimings.Register(timing);                           // speakers now follow this clip
```

Other runtime options: `TTSClipTimings.Register(library)` to add a whole `TTSClipTimingLibrary`, and
`TTSClipTimings.TryGet(clip, out var timing)` to check whether a clip has timings.

**3. Your own effect instead of the TextMeshPro highlighter**

```csharp
void OnEnable()
{
    TTSSpeaker.AnyLineStarted += (speaker, text) => { /* a line started (baked, recorded or live) */ };
    TTSSpeaker.AnyWordChanged += (speaker, index) =>
    {
        if (index < 0) return;                              // between words / ended
        string word = speaker.CurrentLineWords[index];      // word being spoken now
        float progress = speaker.CurrentWordProgress;       // 0..1 through that word
    };
    TTSSpeaker.AnyLineEnded += speaker => { /* line finished, stopped or replaced */ };
}
```

Per speaker: `speaker.onWordChanged` (UnityEvent), `speaker.CurrentWordIndex`, `speaker.CurrentLineText`,
`speaker.IsSpeaking`, `speaker.IsFollowingExternalClip`. Unsubscribe in `OnDisable`.

**4. Creating timing assets from an Editor script** (batch pipelines)

```csharp
#if UNITY_EDITOR
using SaurabhFutureCity.OfflineTTS.Editor;
// estimate from the clip's audio and save <clip>_Timing.asset + add it to the library linked in settings
if (TTSTimingAssets.TryEstimate(clip, text, out var words))
    TTSTimingAssets.SaveTiming(clip, text, words, TTSClipTiming.TimingSource.EstimatedFromRecording);
#endif
```

#### How it works (for customising)

1. **Timings:** a `TTSClipTiming` asset stores the clip, its text and each word's start and end time. Libraries in the
   settings asset are registered at startup (`TTSClipTimings`); in builds the settings asset is preloaded automatically.
2. **Following:** every `TTSSpeaker` with *Follow External Clips* watches its own AudioSource. When a clip with timings
   starts (played by anyone), it raises `AnyLineStarted`, then updates `CurrentWordIndex` from `AudioSource.time` and
   raises `AnyWordChanged`. Stopping, pausing or replacing the clip raises `AnyLineEnded`.
3. **Highlighting:** a `TTSWordHighlighter` follows a speaker (by text match, from a list, or via `Bind`), maps the
   spoken words to the TextMeshPro words in order, and recolours and zooms the current word on the text mesh.
4. **Auto Highlight** only automates steps 2 and 3's setup (adding components and binding). Anything it does can be done
   by hand with the code above.

Accuracy: baked TTS timings match live TTS. Timings for recordings are estimated, close enough to follow along; very fast
speech or long pauses mid-sentence can drift slightly. Edit the text and press *Re-estimate timings* on the timing asset.

#### Addressables and AssetBundles

If your dialogues or clips are loaded through **Addressables** or **AssetBundles**, the clip that plays at runtime is
a separate copy of the asset, so it isn't the same object the timing asset references. From 1.11.1 timings are also
matched by **clip name** (with the clip's length used to tell apart different clips that share a name), so this works
without any extra setup. Things to know:

* **Keep baked clip names unique** across the project (e.g. `SM_01` … in one module, `WAH_01` … in another). Clips that
  share a name and have nearly the same length can't be told apart.
* After updating, run **Repair Timing Library** once and rebuild. It stores each clip's name and length in its timing asset.
* The preloaded timing library references the clips, so Unity also includes those clips in the player build, next to
  the copies in your Addressables bundles. For a module's dialogue that's usually a few MB. If size matters, ask about
  the "Addressables-only timings" option (keeping the timing library in Addressables instead of Preloaded Assets).

### 4.9 TTS Auto Highlight

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Auto Highlight To Scene**. Use one per scene, or one per hierarchy with
*Children Of This Object*.

| Field | Default | Description |
|---|---|---|
| Scope | Whole Scene | *Whole Scene*: all AudioSources and texts in loaded scenes. *Children Of This Object*: only under this GameObject. |
| Scan Interval | 0.1 s | How often it checks for AudioSources that started a timed clip. |
| Ignore Sources | — | AudioSources it never touches (music, ambience, UI sounds). |
| Add Speakers Automatically | on | Adds a listen-only TTS Speaker to AudioSources playing timed clips. |
| Default Voice | M1 | Voice on speakers it adds (only used if they're later asked to speak live). |
| Find Texts Automatically | on | Finds the best-matching TextMeshPro text for each line and highlights it. |
| Preferred Texts | — | Texts to use first when they match (e.g. your subtitle text). |
| Minimum Match | 0.5 | Share of spoken words that must appear in a text for it to count. |
| Include Live TTS | on | Also handle lines spoken by live TTS. |
| Only Visible Texts | on | Ignore hidden texts. |
| Debug Log | off | Logs speakers added, texts matched and match scores. |

It reuses components that already exist (your own TTS Speakers, highlighters and per-text *Look*), and works alongside
the dialogue bridge.

### 4.10 TTS Subtitle Display

A ready-made **subtitle** for whatever is being spoken: live TTS, or a baked or recorded clip with word timings that a
TTS Speaker follows. It shows the line and highlights the current word.

* **Add it:** **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Subtitles To Scene (Screen)** gives a bottom-of-screen subtitle bar.
  **… (World Space, VR)** gives a 1.6 m panel in front of the camera. Or add **TTS Subtitle Display** to any
  TextMeshPro text yourself (it adds a TTS Word Highlighter automatically).
* Both test scenes include one: a screen subtitle in the Editor test scene, and a world-space subtitle above the
  NPCs in the VR test scene.

| Field | Default | Description |
|---|---|---|
| Speakers | — | Only show lines from these speakers. Empty = every speaker. |
| Show Speaker Name | off | Prefix the line with the speaker's name ("Site Manager: …"). The highlight skips the prefix. |
| Hide When Silent | on | Clear the subtitle when the line ends. |
| Hide Delay | 1 s | How long the finished line stays on screen. |
| Idle Text | — | Text shown when nobody is speaking. |
| Show While Speaking | — | Object shown only while a subtitle is visible (e.g. the background panel). |

The highlight look follows the usual order: the text's own *Look* → TTS Override on parents → settings asset.

---

## 5. Settings asset

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create or Locate Settings Asset**

* If a `TTSSettings` asset already exists **anywhere** in the project, it is selected and highlighted.
  No duplicate is created. If there are several, the one named `OfflineTTSSettings` is used and the others are
  listed in the Console.
* Otherwise `Assets/Features/TTS/OfflineTTSSettings.asset` is created (folders included).

The service, test scenes and Voice-over Baker pick up the existing asset automatically.

| Field | Default | Description |
|---|---|---|
| **Location** | StreamingAssets | Where model files are loaded from: *StreamingAssets* (shipped in the build; unpacked once on Android), *PersistentDataPath* (you deliver files yourself), *AbsolutePath* (PC tools). |
| Model Folder | `Supertonic` | Folder containing `onnx/` and `voice_styles/`. |
| Model Version | `supertonic-3` | Change when you ship different model files: forces Android re-extraction and invalidates the audio cache. |
| **Default Voice** | F1 | Used when a speaker/request doesn't specify one. |
| **Default Language** | en | Used when a speaker/request doesn't specify one. |
| Steps | 8 | Quality on PC/Editor. |
| Speed | 1.05 | Default speaking rate. |
| Chunk Silence | 0.3 s | Pause between sentences of long text. |
| Desktop Threads | 0 (auto) | CPU threads on PC. |
| Mobile Threads | 3 | CPU threads on Quest/Pico (2–3 protects frame rate). |
| Mobile Steps | 5 | Quality on headsets (0 = same as Steps). |
| Use NNAPI On Android | off | Experimental hardware acceleration. |
| Warm Up On Load | on | Generate one tiny phrase after loading so the first real line is fast. |
| Memory Cache Entries | 64 | Recently generated lines kept in RAM. |
| Disk Cache | on | Save generated lines to `persistentDataPath/TTSCache` (instant on next launch). |
| **Timing Libraries** | — | Word timings for baked/recorded clips (§4.8). Filled automatically by the Baker and the Word Timing Generator. |
| **Word Highlight** ▸ Enabled | on | Highlight the spoken word in texts with a TTS Word Highlighter. |
| … Apply Color / Highlight Color | on / amber | Recolour the current word. |
| … Zoom Scale | 1.2 | How much the word zooms in (1 = none, 2 = double). |
| … Pop Duration | 0.15 s | Length of the zoom-in animation. |
| … Bounce | 0.5 | Overshoot at the end of the pop. |
| … Hold Zoom While Spoken | on | Stay zoomed until the word ends (off = pop and settle). |
| … Lift | 0.08 | Small upward hop, as a fraction of font size. |
| … Tint Spoken Words / Spoken Word Color | off / grey | Karaoke-style colour for words already spoken. |

---

## 6. Scripting API

Namespace: `SaurabhFutureCity.OfflineTTS`.

### TTSSpeaker

```csharp
speaker.Speak("Text");                              // fire and forget (UnityEvent friendly)
bool finished = await speaker.SpeakAsync("Text");   // true = played to the end, false = stopped/interrupted/disabled
await speaker.SpeakAsync("Text", new TTSRequest { voice = "F3", speed = 0.9f }); // per-call overrides
speaker.Stop();                                     // stop + clear queue
speaker.Pause(); speaker.Resume();
speaker.voice = "M3"; speaker.language = "de";
await speaker.PrewarmAsync(lines);                  // pre-generate with this speaker's exact settings

// Reuse an AudioSource that another script already configured (keeps its 3D settings):
var s = TTSSpeaker.AddTo(npcAudio.gameObject, "M2", configureSpatialAudio: false);

// Word tracking
int word = speaker.CurrentWordIndex;                // index into speaker.CurrentLineWords, -1 = none
speaker.onWordChanged.AddListener(i => { … });
TTSSpeaker.AnyLineStarted += (speaker, text) => { … };
TTSSpeaker.AnyWordChanged += (speaker, index) => { … };
TTSSpeaker.AnyLineEnded   += speaker => { … };
```

If another script stops the speaker's AudioSource or puts its own clip on it mid-line, the speaker drops
the rest of its line instead of continuing afterwards. This makes it safe to share an AudioSource with an
existing voice script.

### TTSWordHighlighter, TTSOverride, TTSText

```csharp
highlighter.Bind(speaker);                                  // follow this speaker (null = unbind)
TTSHighlightSettings look = TTSOverride.ResolveHighlight(transform);
TTSSpeechOverrides speech = TTSOverride.ResolveSpeech(transform);
string spoken = TTSText.ToSpeakable("<b>Lift</b> with your <color=red>legs</color>"); // "Lift with your legs"
List<string> words = TTSText.Words(spoken);
```

### OfflineTTS (service)

```csharp
var tts = OfflineTTS.GetOrCreate();            // or OfflineTTS.Instance
await tts.InitializeAsync();                   // load model (safe to call many times)
bool ready = tts.IsReady; float p = tts.LoadProgress;

AudioClip clip = await tts.SynthesizeClipAsync("Hello", new TTSRequest { voice = "F2", language = "en" });
TTSClipInfo info = await tts.SynthesizeClipWithTimingAsync("Hello there");   // clip + per-word timings
await tts.SynthesizeStreamingWithTimingAsync("Long text…", piece => { /* piece.clip, piece.words */ });
float[] pcm    = await tts.SynthesizeSamplesAsync("Hello");       // mono float PCM, tts.SampleRate Hz
await tts.SynthesizeStreamingAsync("Long text…", clip => queue.Enqueue(clip)); // one clip per sentence
await tts.SynthesizeToWavAsync("Hello", path);                    // write WAV at runtime
await tts.PrewarmAsync(lines, new TTSRequest { voice = "M1", seed = 42 });  // pre-generate + cache

VoiceStyle a = await tts.GetVoiceAsync("F2");
VoiceStyle b = await tts.GetVoiceAsync("F4");
tts.RegisterVoice(VoiceStyle.Blend(a, b, 0.35f, "Supervisor"));   // new voice usable as speaker.voice = "Supervisor"

tts.ClearCache(includeDisk: true);
```

### TTSRequest

| Field | Meaning |
|---|---|
| `voice`, `language` | Empty = settings default |
| `steps`, `speed` | -1 = settings default |
| `seed` | -1 = random; fixed = reproducible and cacheable |
| `useCache` | Reuse identical earlier results |

All `async` methods must be called from the main thread. They return on the main thread, and inference runs on a
worker thread. Pass a `CancellationToken` to cancel generation.

### Baked and recorded clip timings

```csharp
// Find timings for a clip (from the libraries linked in the settings asset, or registered from code)
if (TTSClipTimings.TryGet(clip, out TTSClipTiming timing)) { /* timing.text, timing.words */ }
TTSClipTimings.Register(myLibrary);                 // make an extra library available at runtime
speaker.followExternalClips = true;                 // follow timed clips other scripts play on its AudioSource
bool following = speaker.IsFollowingExternalClip;
TTSSettings settings = TTSSettings.FindLoaded();    // the project's settings asset (preloaded in builds)
```

### Low-level (no MonoBehaviour)

`SupertonicEngine` runs the model directly. It's thread-safe and usable in Editor tools:

```csharp
using var engine = new SupertonicEngine(onnxDir, EngineOptions.Default);
var voice = VoiceStyle.FromFile(voicePath);
float[] samples = engine.Synthesize("Text", "en", voice, SynthesisParams.Default);
WavUtility.Save("out.wav", samples, engine.SampleRate);
```

---

## 7. Editor tools

Menu **FutureCity ▸ Plugins ▸ OfflineTTS**:

| Menu item | What it does |
|---|---|
| Documentation | Opens this documentation (offline copy). |
| About | Installed version, ONNX Runtime version, Unity version, model status; buttons for docs and changelog. |
| Changelog | Opens the changelog of the installed version (offline). |
| Download Supertonic 3 Models | Downloads models into `StreamingAssets/Supertonic`. |
| Create or Locate Settings Asset | Finds or creates the settings asset (see §5). |
| Add TTS Service To Scene | Adds the service (or selects the existing one) and assigns your settings. |
| Voice-over Baker | Text → WAV files (see §9). |
| Batch Add TTS Speakers | Add or update TTS Speakers on every matching object inside a prefab (see §7.1). |
| Word Timing Generator | Create word timings for recorded or other voice clips so they highlight words (see §7.2, §4.8). |
| Repair Timing Library | Adds every timing asset in the project to the library linked in the settings asset (needed for builds). |
| Add Subtitles To Scene (Screen / World Space, VR) | Adds a TextMeshPro subtitle with word highlighting (see §4.10). |
| Setup ▸ Import TextMeshPro Essentials | Imports TextMeshPro's default font and shaders if they're missing. |
| Add Auto Highlight To Scene | Adds TTS Auto Highlight, for automatic highlighting of baked, recorded and live lines (see §4.9). |
| Run Diagnostics (no Play mode) | Loads the model, speaks a test line, prints speed and output level. |
| Create Editor Test Scene | Desktop test scene with Test Bench. |
| Create VR Test Scene (XRI) | VR test scene (needs XRI 3.x). |
| Create Plugin Test Scene (Playground) | Live TTS + baked clips + subtitle in one scene, for testing the plugin on its own (see §8). |
| Setup ▸ … | Installer repair and toggles (see §1). |

---

### 7.1 Batch Add TTS Speakers

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Batch Add TTS Speakers** puts a TTS Speaker on many objects at once. For example,
it can give every `NpcAudio` object inside an environment or NPC prefab a TTS Speaker with the same settings.

**1. Main Prefab:** the prefab to search through. You can set it three ways:
* drag a prefab asset (Project window) or a scene GameObject (Hierarchy) into the field;
* type part of the name in **Find by name** and press **Find**, then click a result;
* select it in the Project or Hierarchy window and press **Use selected**.

The search covers the whole hierarchy, including nested prefabs and inactive objects.

**2. Object name (text):** the name of the objects that should get a TTS Speaker, e.g. `NpcAudio`.
* **Exact name:** on = the whole name must match (ignoring upper/lower case). Off = the name only has to contain the
  text (`NpcAudio` also matches `NpcAudio (1)`).
* **Also match component type:** also matches objects that have a component of that type (e.g. the `NpcAudio`
  script), whatever the GameObject is called.

**3. Prefab / GameObject to look for:** optional. Drag in a prefab (e.g. your `NpcAudio` or NPC prefab), and every
instance of it inside the Main Prefab matches, even if the instance was renamed. **Also match by its name** adds
objects with the same name that aren't instances of it. A scene GameObject in this field is matched by its name.

An object matches if it meets **any** of the criteria from 2 and 3.

**TTS Speaker settings to apply:** the complete TTS Speaker Inspector (voice and language dropdowns, speed, steps, seed,
streaming, interrupt, spatial audio, events). These values are copied to every speaker added or updated, and are
remembered between sessions. **Reset settings to defaults** restores the defaults.
* Keep **Configure Spatial Audio** off for objects that already have a configured AudioSource (e.g. `NpcAudio`), so
  their 3D settings stay as they are. It's off by default in this tool.
* Event listeners that point to scene objects can't be stored inside prefab assets.

**Options:**

| Option | Choices |
|---|---|
| If a TTS Speaker exists | **Skip** (leave it untouched) or **Update Settings** (overwrite with the values above). |
| Nested prefabs | **Override In Main Prefab**: added only inside the Main Prefab, as an added-component override, so other prefabs using the same NPC aren't affected. **Original Prefab Asset**: added to the nested prefab's own asset, so *every* place that uses it gets it. Read-only sources such as imported `.fbx` models fall back to the override. |
| Voice | **Template Voice** (all matches get the voice above) or **Cycle Through List** (matches get the listed voices in turn, e.g. M1, F1, M2…, so characters sound different). |

**Buttons:**
* **Find Matches** lists every object that would get a TTS Speaker, with its path. Nothing is changed.
* **Add / Update TTS Speakers** goes through the whole Main Prefab and applies the settings. A summary shows how many
  speakers were added, updated and skipped.
* **Remove** takes the TTS Speaker off every match.

**Undo:** changes to **scene objects** can be undone with Ctrl+Z. Changes to **prefab assets** are saved directly into
the prefab file, so commit to version control first, or use **Remove** to take them off again.

### 7.2 Word Timing Generator

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Word Timing Generator** creates word timings for any voice clip.

1. Select clips in the Project window and press **Add selected clips**, or drag clips into the rows (**+ Add empty entry**).
2. Give each clip **exactly what it says**. Type it, or **Load script (.txt / .csv)** with one line per clip:
   `clipName | text` (or `clipName,text`). Clips that aren't in the list yet are found in the project by name.
3. Press **Generate word timings**. Each row shows the result (e.g. *✓ 18 words timed*).

Timings are saved as `<clip>_Timing.asset` next to each clip and added to the timing library linked in your settings.
Clips whose import settings don't allow reading audio (compressed or streaming) are re-imported temporarily to read
them, then restored.

## 8. Testing

### Plugin Test Scene (Playground), recommended

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create Plugin Test Scene (Playground)** creates
`Assets/OfflineTTS_Test/OfflineTTS_Playground.unity`, a single scene for testing the plugin on its own, separate from
your project's dialogue system. It needs XR Interaction Toolkit 3.x and imports its samples on first run.

| Part | What it tests |
|---|---|
| **Left panel: live TTS** | Pick a character and a female/male voice, type with the VR keyboard (or PC keyboard), **SPEAK**. Settings, voice preview, benchmark. |
| **Right panel: Baked Clips** | Every clip from your timing library, each marked *[timings: N words]* or *[NO TIMINGS]*. **PLAY** plays the clip on the trainer's AudioSource exactly like an NPC voice script, and the panel reports **OK … highlighting** or **NOT HIGHLIGHTED … (reason)**. |
| **Subtitle above the NPCs** | Every line (live or baked) with word highlighting, also on the headset. |
| **NPCs, radio** | Grip / trigger to hear their lines; 3D audio. |

Workflow: bake lines (Voice-over Baker, *Save word timings* on) or generate timings for recordings → create the
Playground → press Play (XR simulator or Quest Link), or build only this scene to an APK. To add clips later, select
**TTS Baked Clips Panel** and drag clips into *Clips*.


1. **Run Diagnostics.** The quickest check that models and ONNX Runtime work: you should hear a line, and the
   Console prints `Result: PASS`.
2. **Editor test scene.** Press Play and use the Test Bench in the Game view.
3. **VR test scene.** XRI Starter Assets rig with a world-space panel:
   * choose a **character** (male trainer, female supervisor, radio)
   * choose a **Female F1–F5** or **Male M1–M5** voice
   * **type** text (VR keyboard, or the PC keyboard in the Editor) and press **SPEAK**
   * **Preview all 10 voices**, timing, benchmark, 3D audio toggle
   * grip an NPC to hear its lines; grab the radio and pull the trigger to test spatial audio

   * a **subtitle above the NPCs** shows every spoken line with word highlighting (TextMeshPro), also on the headset

   It works with the **XR Interaction Simulator** (no headset), **Quest Link / Air Link**, or on device.
4. **Automated tests.** **Window ▸ General ▸ Test Runner ▸ EditMode ▸ Run All** covers text handling, WAV
   files, audible output, seed reproducibility, chunking, speed, and all voices. Engine tests are *ignored* while
   models are missing.

Desktop speeds are much faster than a headset. Measure on the device with the panel's **Benchmark** button.

---

## 9. Videos and voice-over

### Narration in the app

Use **TTS Video Narrator** (§4.3). Typical training uses include a narrated 360° walkthrough, or pausing the video
on a freeze-frame while the narrator explains.

### Baked WAV files (Voice-over Baker)

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Voice-over Baker**

* **Single line** or **Batch**: one line per file, `file_id | text`. Lines without `|` are auto-numbered; `#`
  lines are comments. You can load `.txt` or `.csv` (`id,text`).
* Pick voice (or blend two voices), language, steps, speed and **seed** (same seed = reproducible re-bakes).
* Output folder default: **`Assets/Features/TTS/TTS_Baked`** (created automatically).
* **Preview** plays in the Editor; **Bake** writes WAVs and imports them as AudioClips.
* **Save word timings** (on by default) also writes `<name>_Timing.asset` next to each WAV, so baked clips can
  highlight the spoken word (§4.8).

Use baked clips as normal dialogue (zero runtime cost and no model needed in that build), on Timeline Audio Tracks,
in Unity Recorder captures, or in any external video editor.

---

## 10. Integrating with an existing voice or dialogue system

### The pattern

1. **Reuse the character's AudioSource.** Put a TTS Speaker next to the AudioSource your voice script uses,
   or add one from code with `TTSSpeaker.AddTo(go, voice, configureSpatialAudio: false)`. For many characters at once,
   use **Batch Add TTS Speakers** (§7.1), e.g. every `NpcAudio` object in a prefab. Lip sync,
   spatialisation and mixer routing keep working, and your 3D settings aren't touched.
2. **Recorded clip first.** Speak with TTS only when a line has no clip, or when you explicitly want TTS.
3. **Stop TTS before playing a clip** (`speaker.Stop()`). The speaker also stops by itself if another script
   stops or replaces the clip on the shared AudioSource.
4. **Speak what's on screen.** Pass the displayed text after your variable substitution. Rich-text tags are
   removed automatically (`TTSText.ToSpeakable`).
5. **Await the result** if your flow should wait: `bool finished = await speaker.SpeakAsync(text)`.
   `false` means the line was skipped or stopped.
6. **Pre-generate** fixed lines when a conversation opens: `speaker.PrewarmAsync(lines)`.
7. **Highlight words:** `TTSWordHighlighter.Bind(speaker)` on the text component.

See the **Integration Examples** sample (Package Manager ▸ Samples).
For baked or recorded clips with word timings, **TTS Auto Highlight** (§4.9) can do steps 1 and 7 automatically.

### Keeping both systems modular (recommended architecture)

Avoid making your dialogue system reference the TTS package directly, so each one can be reused without the other:

```
Your dialogue system (asmdef A)             TTS package (com.saurabh.futurecity.offlinetts)
  defines IDialogueVoiceProvider    ◀──┐        ▲
  calls it for each line               │        │
                                       │        │
           Bridge (asmdef B: references A + SaurabhFutureCity.OfflineTTS)
           implements IDialogueVoiceProvider with TTSSpeaker
           defineConstraints: FUTURECITY_OFFLINE_TTS
           versionDefines:  com.saurabh.futurecity.offlinetts  →  FUTURECITY_OFFLINE_TTS
```

* The dialogue system works on its own; with no provider in the scene it behaves exactly as before.
* The bridge assembly compiles **only** when the TTS package is installed (version define + define constraint),
  so projects without TTS just skip it.
* The TTS package knows nothing about your dialogue system.

A dialogue integration (DialogueBoxUI + DialogueTTSVoice) follows exactly this structure, with
per-dialogue-box TTS Mode (Off / Fallback When No Clip / Always), per-node overrides (Inherit / Force On /
Force Off, spoken-text override, voice override), narrator support, prewarming and word highlighting.

## 11. Performance on standalone headsets

The model shares the headset's CPU with your game.

* **Pre-generate** known lines during fades or loading (`PrewarmAsync`, the narrator's prepare step, or baking).
* Live generation is for dynamic text. **Stream Sentences** keeps the wait short (the first sentence plays while
  the rest generates).
* Frame drops while generating: lower **Mobile Threads** to 2.
* Generation too slow: lower **Mobile Steps** to 3–4.
* Model loading takes a few seconds and several hundred MB of RAM. Load it once (service in the first scene,
  *Dont Destroy On Load*). On Quest 2, watch the total memory budget.
* The **disk cache** makes repeated lines instant across launches.

---

## 12. Building for Quest and Android

* **Player Settings:** Scripting Backend **IL2CPP**, Target Architecture **ARM64**.
* Managed code stripping: leave as is. The package injects the `link.xml` that ONNX Runtime needs.
* **APK size:** models add ≈ 400 MB. If you exceed store limits, enable **Split Application Binary** (OBB), or
  deliver models yourself and set *Location = PersistentDataPath*.
* On first launch the models are copied from the APK to local storage (one-off, offline). On-device storage is
  therefore about 2× the model size.
* Remove `Assets/OfflineTTS_Test/` or keep its scenes out of Build Settings.
* A build-time check warns if no models are found.

---

## 13. Version control and teams

* **Don't commit models to plain Git.** Either use **Git LFS** for `*.onnx`, or add
  `Assets/StreamingAssets/Supertonic/` to `.gitignore` and let each machine (and the build server) run the
  downloader.
* Commit `Packages/manifest.json` and `packages-lock.json`. The installer's changes are then shared with the team.
* Pin the package with a Git tag (`#v1.11.1`) so every module uses the same version.

---

### Releasing a new version (checklist)

1. Bump `"version"` in `package.json` (e.g. `1.5.3`).
2. Add a `## [1.5.3] - YYYY-MM-DD` entry at the top of `CHANGELOG.md` (*Added / Changed / Fixed*).
3. If users must do something when upgrading, add a line for that version in `UPGRADE_NOTES` in `Tools~/build-docs.py`.
4. Run `python Tools~/build-docs.py`. This updates the version banner, **§17 Version and release history**, the
   install URLs in the examples, and the offline HTML.
5. Commit, then `git tag v1.5.3` and `git push --tags`. For tarballs, `npm pack` produces `com.saurabh.futurecity.offlinetts-1.5.3.tgz`.

---

## 14. Troubleshooting

| Problem | Fix |
|---|---|
| **"Failed to resolve packages … not valid JSON"** | `manifest.json` has extra characters, usually after the final `}`. Validate it at jsonlint.com. |
| **FutureCity ▸ Plugins ▸ OfflineTTS menu missing** | ONNX Runtime isn't installed yet. Wait for resolving to finish, or run **Setup ▸ Repair Project Setup** (that menu is always available). Check the Console for `[OfflineTTS]` messages. |
| **"…has no meta file, but it's in an immutable folder"** | The Git repo is missing `.meta` files. Every file and folder needs its `.meta` committed. |
| **Git install fails** | Install Git and restart Unity/Hub; for private repos, configure credentials or use an SSH URL. |
| **Model load failed / FileNotFound** | Run *Download Supertonic 3 Models*; check *Location* and *Model Folder* in the settings. |
| **No sound** | Game view **Mute Audio** off; *Project Settings ▸ Audio ▸ Disable Unity Audio* off; correct Windows output device; one AudioListener in the scene. Run **Run Diagnostics**: a peak level near 0 means a generation problem; otherwise it's playback. |
| **Sound in 2D but not 3D** | Spatializer plugin silent in the Editor. Set *Project Settings ▸ Audio ▸ Spatializer Plugin* to None for testing, or untick **Configure Spatial Audio**. |
| **Mispronounced numbers, units or names** | Spell them out ("5 kg" → "five kilograms"); preview safety-critical lines. |
| **Frame drops on Quest during speech** | Lower Mobile Threads; pre-generate; see §11. |
| **Same line sounds different each time** | Seed is -1 (random). Set a fixed seed. |
| **Word highlight doesn't show** | The text needs a **TTS Word Highlighter** (or a dialogue bridge with *Auto Add Highlighter*); check *Word Highlight ▸ Enabled* in settings and any **TTS Override** above the text; with *Listen To = Any Speaker…*, lower *Minimum Match* if the spoken text differs a lot from the screen. |
| **Highlight is slightly early/late** | Word timing is estimated from the audio. Fast speech or very long words can drift by a fraction of a word. |
| **TTS keeps talking after my clip starts** | Fixed in 1.5.0: the speaker stops itself when another script stops or swaps its AudioSource clip. Also call `speaker.Stop()` before playing your clip. |
| **Baked clips don't highlight in builds and dialogues/clips use Addressables or AssetBundles** | Fixed in 1.11.1: timings are matched by clip name. Update, run **Repair Timing Library**, rebuild. Keep baked clip names unique. |
| **Highlighting works in the Editor but not in the build** | Update to 1.10.1 and build again: before each build all timing assets are added to the timing library, which is linked to every settings asset and preloaded. Check the build log for *"Build includes N word timing(s)"*. The Editor also logs a warning when it uses a timing that isn't in a linked library. |
| **TextMeshPro text is invisible, pink or shows squares** | TMP Essential Resources are missing: **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Setup ▸ Import TextMeshPro Essentials** (the installer normally does this automatically). |
| **Big frame drop / freezing in Play mode (1.9.1)** | Fixed in 1.9.2: update. Clips without timings (music, ambience) triggered a project-wide search many times a second in the Editor. |
| **One baked clip doesn't highlight (others do)** | Turn on **Debug Log** on the NPC's TTS Speaker and on the text's TTS Word Highlighter, play again and read the Console. *"has NO word timings in a linked timing library"* → run **Repair Timing Library**. *"None of the N spoken words were found in this text"* → the clip's text differs from the card text: re-bake with the on-screen wording. *"Dropped TTS line … another script started"* is expected (the clip won over a pending live line). |
| **Highlight stops after a live TTS line** | Fixed in 1.9.1 (a baked clip started while a live line was still generating wasn't followed). |
| **Warning: timings "not in a timing library"** | The timing asset exists but isn't in the linked library: it works in the Editor only. Run **Repair Timing Library**. |
| **Auto Highlight does nothing** | Turn on its **Debug Log**. "No text matched" → lower *Minimum Match* or add the text to *Preferred Texts*; no "Added a listen-only TTS Speaker" → the clip has no timings, or the AudioSource is in *Ignore Sources* / outside the *Scope*. |
| **Baked/recorded clip doesn't highlight** | The clip needs a timing asset (Baker *Save word timings*, or the Word Timing Generator) in a library linked in the settings asset; the AudioSource playing it needs a **TTS Speaker** with *Follow External Clips* on; the text needs a **TTS Word Highlighter**; the timing text should match the screen text. |
| **My settings are ignored without [OfflineTTS]** | Fixed in 1.7.0: the settings asset is found automatically, and preloaded in builds. Make a build after updating so it's added to *Preloaded Assets*. |
| **Menus moved** | From 1.7.0 everything is under **FutureCity ▸ Plugins ▸ OfflineTTS** (menu bar, Add Component and Create menus). |
| **Tests not in Test Runner** | `testables` missing. Run *Setup ▸ Repair Project Setup* (with *Add To Testables* on). |

---

## 15. Licensing

* **This package's code:** see `LICENSE.md`.
* Parts of the inference code are adapted from the **Supertonic** reference implementation, MIT © Supertone Inc.
* **Supertonic 3 model weights:** **OpenRAIL-M** licence (commercial use allowed, with use-based restrictions).
  Include the licence with any app that ships the model. The upstream project is archived (no further updates).
* **ONNX Runtime for Unity** (asus4) and Microsoft ONNX Runtime: MIT.

See `THIRD_PARTY_NOTICES.md`.

---

## 16. FAQ

**Does it need internet?** Only to install packages and download the models once. At runtime: no.

**Does word highlighting work with baked audio or real voice-over?** Yes. Give the clip word timings (the Baker
saves them automatically; use the Word Timing Generator for recordings), then either add **TTS Auto Highlight** to the
scene (1.8.0+, fully automatic) or set up a TTS Speaker and highlighter yourself. See §4.8.

**Can I add more voices?** Ten presets ship. `VoiceStyle.Blend` creates new voices by mixing two presets, and
the Baker can blend too. Extra `voice_styles/*.json` files appear in the dropdowns automatically.

**Can I clone a real person's voice?** No. This model doesn't support voice cloning.

**Does lip sync work?** Yes. Speech plays through the character's AudioSource like recorded audio.

**Can I use it without XR Interaction Toolkit?** Yes. Only the VR test scene and XR components need XRI.

**WebGL?** Not supported. Use baked WAV files for web builds.

---

<!-- VERSION-SECTION:START -->
## 17. Version and release history

### This documentation

| | |
|---|---|
| Package | `com.saurabh.futurecity.offlinetts` — FutureCity Offline TTS |
| **Version** | **1.11.1** |
| Released | 2026-11-07 |
| Unity | 2022.3 or newer |
| ONNX Runtime | `com.github.asus4.onnxruntime` 0.4.9 (added to the project automatically) |
| Dependency | `com.unity.nuget.newtonsoft-json` 3.2.1 |
| Dependency | `com.unity.ugui` 1.0.0 |
| Voice model | Supertonic 3 (31 languages, 10 voices) — downloaded separately |

### Check the version installed in your project

* **FutureCity ▸ Plugins ▸ OfflineTTS ▸ About** shows the installed package version, ONNX Runtime version, Unity version and whether the models are present, with buttons for this documentation and the changelog.
* **Window ▸ Package Manager ▸ In Project ▸ FutureCity Offline TTS**: version on the right. *Version History* lists other versions.
* Git installs: the tag at the end of the URL in `Packages/manifest.json` (e.g. `#v1.11.1`). Tarball installs: the file name (`com.saurabh.futurecity.offlinetts-1.11.1.tgz`).
* From code: `UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SaurabhFutureCity.OfflineTTS.OfflineTTS).Assembly).version`.

### Updating

* **Git:** change the tag in `Packages/manifest.json` (or reinstall with the new `#vX.Y.Z` URL).
* **Tarball:** install the new `.tgz` with a new file name; don't overwrite the old file in place.
* Read the upgrade notes below for every version between yours and the new one.

### Releases at a glance

| Version | Released | Highlights | Upgrade notes |
|---|---|---|---|
| **1.11.1** | 2026-11-07 | Baked clips loaded with Addressables / AssetBundles weren't highlighted in builds | Fix for Addressables / AssetBundles: baked clips are matched by name. Run Repair Timing Library once and rebuild; no re-baking needed. Keep baked clip names unique. |
| 1.11.0 | 2026-11-07 | Plugin Test Scene | Adds the Plugin Test Scene (Playground). Built on 1.10.1: the 1.10.2 changes are withdrawn (use the DialogueTTSVoice.cs from the integration bundle that matches 1.10.1). |
| 1.10.1 | 2026-11-06 | Baked/recorded clips highlighted in the Editor but not in builds | Fix for highlighting that works in the Editor but not in builds. After updating, make a new build (timings are synced and preloaded automatically). |
| 1.10.0 | 2026-11-06 | TextMeshPro is installed with the plugin: dependency on com.unity.ugui | TextMeshPro is now installed with the plugin (and its essentials imported automatically). Nothing to change in existing projects; re-create the test scenes to get the new subtitles. |
| 1.9.2 | 2026-11-05 | Severe frame drops / freezing in Play mode | Performance fix: update from 1.9.1 if Play mode freezes or the frame rate drops (especially with music/ambience playing or TTS Auto Highlight in the scene). No setup changes. |
| 1.9.1 | 2026-11-05 | Baked/recorded clip not highlighted | Bug fix + diagnostics. If a baked clip sometimes doesn't highlight, turn on Debug Log on the TTS Speaker and the TTS Word Highlighter, and run Repair Timing Library once. |
| 1.9.0 | 2026-11-05 | Package renamed com.xrlp.offlinetts → com.xrlab.offlinetts | RENAMED to com.xrlab.offlinetts / namespace XRLAB.OfflineTTS. Remove the old package first, install the new one (new Git URL or .tgz), then update your scripts' 'using XRLP.OfflineTTS;' to 'using XRLAB.OfflineTTS;' and asmdef references to XRLAB.OfflineTTS(.TMP). Script GUIDs are unchanged, so scenes keep their components. See 'Migrating from com.xrlp.offlinetts'. |
| 1.8.0 | 2026-11-05 | TTS Auto Highlight component | New optional component (TTS Auto Highlight). Nothing changes until you add it. To make highlighting automatic in a project, run FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Auto Highlight To Scene. |
| 1.7.1 | 2026-11-04 | Compile error in Unity 6 | Bug fix only (Unity 6 compile error in the Word Timing Generator). Update from 1.7.0 if you see CS0619 about preloadAudioData. |
| 1.7.0 | 2026-11-04 | Word highlighting for baked and recorded clips | Menus moved to FutureCity ▸ Plugins ▸ OfflineTTS (existing components are unaffected). Settings asset is now found automatically and added to Preloaded Assets at build time. For baked/recorded highlighting, put a TTS Speaker on the AudioSource that plays the clip. |
| 1.6.0 | 2026-11-03 | Batch Add TTS Speakers | New Editor tool only (Batch Add TTS Speakers). No runtime changes. Changes to prefab assets are saved directly (no Undo): commit first or use the tool's Remove button. |
| 1.5.2 | 2026-11-02 | Documentation: Version & release history section | Documentation and About window only. No API or behaviour changes. |
| 1.5.1 | 2026-11-02 | Per-object highlight look on TTSWordHighlighter | Adds per-text highlight settings on TTS Word Highlighter. Existing components keep working (all new settings start unticked). |
| 1.5.0 | 2026-11-02 | Spoken-word highlighting for TextMeshPro: TTSWordHighlighter recolours and pops/zooms the current word | Dialogue bridges need 1.5.0+. `TTSSpeaker` now stops its line if another script stops or replaces the clip on its AudioSource. Rich-text tags are no longer spoken. |
| 1.4.0 | 2026-10-29 | Install from Package Manager via Git URL / disk / tarball | Install from Git/tarball with automatic setup. ONNX Runtime moved from package.json to the project manifest (added by the installer). New .meta GUIDs: scenes built with an earlier, embedded copy may show 'Missing script' unless the old .meta files were kept. |
| 1.3.2 | 2026-10-15 | New settings assets are created at Assets/Features/TTS/OfflineTTSSettings.asset | — |
| 1.3.1 | 2026-10-15 | "Create Settings Asset" is now "Create or Locate Settings Asset": finds an existing TTSSettings asset anywhere… | — |
| 1.3.0 | 2026-10-15 | VR panel: text box + built-in VR keyboard, character selector, female/male voice grid, "Preview all 10 voices"… | `TTSSpeaker.SpeakAsync` returns `Task<bool>` (true = finished, false = stopped). |
| 1.2.0 | 2026-10-15 | VR test scene builder for XR Interaction Toolkit 3.x | — |
| 1.1.0 | 2026-10-15 | PC/Editor test kit: Run Diagnostics | — |
| 1.0.0 | 2026-10-15 | Initial release: Supertonic 3 engine on ONNX Runtime, TTSSpeaker | — |

### Full changelog

#### Unreleased
- Package renamed **`com.xrlab.offlinetts` → `com.saurabh.futurecity.offlinetts`**; display name **FutureCity Offline TTS**.
- Namespaces and assemblies **`XRLAB.OfflineTTS*` → `SaurabhFutureCity.OfflineTTS*`**; defines **`XRLAB_*` → `FUTURECITY_*`**; menus under **FutureCity ▸ Plugins ▸ OfflineTTS**.
- Script IDs unchanged. The installer also removes `com.xrlab.offlinetts` from the manifest.

#### 1.11.1 — 2026-11-07

##### Fixed
- **Baked clips loaded with Addressables / AssetBundles weren't highlighted in builds.** Those systems load their own
  copy of a clip, which never equals the clip referenced by the timing asset. Timings are now also matched by
  **clip name**, using the clip length to tell apart different clips that share a name.
##### Added
- `TTSClipTiming.clipName` / `clipLength`, filled automatically when timings are saved, synced (Repair Timing
  Library, before every build) or edited. Existing timing assets work without re-baking.

#### 1.11.0 — 2026-11-07

Built on 1.10.1. The changes from 1.10.2 (diagnostics, retrying lookups, bridge execution order) are **withdrawn**.
##### Added
- **Plugin Test Scene (Playground)** (FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create Plugin Test Scene (Playground)): one scene
  to test the plugin on its own, in the Editor (XR simulator / Quest Link) or as an APK: live TTS panel (voices,
  keyboard, speak), male + female NPCs, subtitle with word highlighting, and a **Baked Clips panel** filled from the
  timing library.
- **TTS Baked Clips Panel** component: plays listed clips on an AudioSource like an NPC voice script, shows per clip
  whether word timings exist, and reports on the panel whether each clip was followed and highlighted (and why not).
- `TTSClipTimings.KnownClipCount` and `LibraryCount` for status displays.

#### 1.10.1 — 2026-11-06

##### Fixed
- **Baked/recorded clips highlighted in the Editor but not in builds.** The Editor finds timing assets that aren't in
  the timing library linked to the settings asset in use (e.g. a project with several settings assets); builds didn't.
  Now:
  - before every build, all timing assets in the project are added to the timing library, the library is linked to
    **every** settings asset, and it's added to *Player Settings ▸ Preloaded Assets*;
  - at runtime, any loaded timing library is used, even if the active settings asset doesn't link it;
  - baking, the Word Timing Generator and Repair Timing Library do the same sync.

#### 1.10.0 — 2026-11-06

##### Added
- **TextMeshPro is installed with the plugin**: dependency on `com.unity.ugui` (includes TextMeshPro in Unity 6 /
  2023.2+); on Unity 2022.3 the installer adds `com.unity.textmeshpro`. **TMP Essential Resources** are imported
  automatically when missing (menu: Setup ▸ Import TextMeshPro Essentials).
- **TTS Subtitle Display** component: a TextMeshPro subtitle showing whatever line is spoken (live, baked or recorded)
  with word highlighting; speaker filter, speaker-name prefix, hide when silent, idle text, background toggle.
- Menus **Add Subtitles To Scene (Screen)** and **(World Space, VR)**.
- Both test scenes now include subtitles, so word highlighting is visible in the Editor and on the headset.
##### Changed
- TTS Word Highlighter finds the first spoken word anywhere in the text (works with prefixes such as a speaker name).

#### 1.9.2 — 2026-11-05

##### Fixed (performance)
- **Severe frame drops / freezing in Play mode (Editor), introduced in 1.9.1.** The Editor fallback for timings that
  aren't in a library searched the whole project each time a clip without timings was checked; with music, ambience
  or other non-voice audio playing and TTS Auto Highlight in the scene, that happened ~10 times a second. Clips
  without timings are now remembered (checked once), and the fallback uses an index built once and refreshed only when
  the project changes.
- TTS Auto Highlight: refreshes its AudioSource list once a second (was every scan) and checks each clip once per
  AudioSource.
- TTS Word Highlighter: no longer forces a TextMeshPro rebuild every time the text changes (inside layout groups this
  could rebuild every frame while a line played); it only forces one when the text has no mesh yet.
- Settings lookup: when no settings asset is loaded, the scan for it runs at most once a second.

#### 1.9.1 — 2026-11-05

##### Fixed
- Baked/recorded clip not highlighted (and live TTS audio starting over it) when the clip started while a live TTS
  line on the same speaker was still being generated. The speaker now yields: it drops the pending line and follows
  the clip. Speaking while a clip is already playing still takes over as before.
##### Added
- **Debug Log** on TTS Speaker (lines started/finished/dropped, clips followed, clips without timings) and on
  TTS Word Highlighter (which speaker it follows and why, how many spoken words matched the text).
- **Repair Timing Library** (FutureCity ▸ Plugins ▸ OfflineTTS): adds every timing asset in the project to the linked
  library, so they work in builds.
- In the Editor, a clip whose timing asset exists but isn't in a linked library is still highlighted, with a warning
  that it won't work in builds until the library is repaired.

#### 1.9.0 — 2026-11-05

##### Changed (breaking: renamed)
- Package renamed **`com.xrlp.offlinetts` → `com.xrlab.offlinetts`**; display name **XRLAB Offline TTS**.
- Namespaces **`XRLP.OfflineTTS` → `XRLAB.OfflineTTS`** (and `.Editor`, `.XR`, `.XR.Editor`); assemblies
  `XRLAB.OfflineTTS`, `XRLAB.OfflineTTS.TMP`, `XRLAB.OfflineTTS.XR`, `XRLAB.OfflineTTS.Editor`, … ;
  defines `XRLAB_ORT`, `XRLAB_TMP`, `XRLAB_XRI3`.
- Script GUIDs are unchanged, so components and assets in existing scenes and prefabs stay connected.
- Editor preferences use new keys (the Batch Add TTS Speakers template and model URL return to defaults once).
##### Added
- The installer removes the old `com.xrlp.offlinetts` entry from `Packages/manifest.json` (dependencies and
  testables) and warns if an old embedded `Packages/com.xrlp.offlinetts` folder is still present.

#### 1.8.0 — 2026-11-05

##### Added
- **TTS Auto Highlight** component (FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Auto Highlight To Scene): one per scene makes
  word highlighting fully automatic. It adds a listen-only TTS Speaker to any AudioSource that plays a clip with word
  timings, finds the TextMeshPro text that shows the line (best word match), adds a TTS Word Highlighter and binds it.
  Works for baked, recorded and live TTS lines; scope (whole scene or children), ignore list, preferred texts,
  minimum match, debug log.
- `TTSText.MatchRatio(spoken, displayed)`: the shared rule for matching spoken lines to on-screen text.
- Integration Examples sample: `ManualHighlightExamples.cs` (manual setup in code, runtime timings, word events,
  live TTS).
- Documentation §4.8 rewritten as a complete guide (automatic, manual Inspector, manual code, how it works),
  new §4.9 component reference, troubleshooting and FAQ entries.

#### 1.7.1 — 2026-11-04

##### Fixed
- Compile error in Unity 6 (CS0619): `AudioImporter.preloadAudioData` is obsolete. The Word Timing Generator now uses
  the per-platform sample setting (`AudioImporterSampleSettings.preloadAudioData`) when it temporarily re-imports a
  compressed or streaming clip to read its audio.

#### 1.7.0 — 2026-11-04

##### Added
- **Word highlighting for baked and recorded clips.** `TTSClipTiming` (word timings per AudioClip),
  `TTSClipTimingLibrary`, runtime registry `TTSClipTimings`. A TTS Speaker follows any timed clip that another
  script plays on its AudioSource (`followExternalClips`, on by default) and drives highlighting like live TTS.
- **Voice-over Baker** saves exact per-sentence word timings next to each WAV (*Save word timings*, on by default)
  and links the timing library to the settings asset.
- **Word Timing Generator** (FutureCity ▸ Plugins ▸ OfflineTTS ▸ Word Timing Generator): word timings for human
  recordings or any voice clip from its script (typed or loaded as `clipName | text`); temporarily re-imports
  compressed/streaming clips to read them.
- Timing asset Inspector: word list with times, *Play clip*, *Re-estimate timings*.
- `TTSSettings.timingLibraries`, `TTSSettings.FindLoaded()`, `TTSSpeaker.IsFollowingExternalClip`.
##### Changed
- **Menus moved to `FutureCity ▸ Plugins ▸ OfflineTTS`** (menu bar, Add Component and Create menus).
- An automatically created TTS service now uses the project's settings asset (found automatically; added to
  *Player Settings ▸ Preloaded Assets* at build time) instead of built-in defaults.

#### 1.6.0 — 2026-11-03

##### Added
- **Batch Add TTS Speakers** (Tools ▸ XRLP ▸ Offline TTS ▸ Batch Add TTS Speakers): pick a Main Prefab (drag it in,
  or type its name and press Find), enter an object name (e.g. `NpcAudio`) and/or a Target Prefab, configure every
  TTS Speaker setting once, then add or update a TTS Speaker on every match in the whole hierarchy (nested prefabs
  and inactive objects included).
  - Matches by GameObject name (exact or contains, case-insensitive), by component type (e.g. the `NpcAudio` script),
    and/or by instances of a Target Prefab (even when renamed).
  - *Find Matches* preview, *Add / Update*, *Remove*; existing speakers can be skipped or updated.
  - Nested prefabs: add as an override inside the Main Prefab, or to the nested prefab's own asset.
  - Voice: same for all, or cycle through a list (e.g. M1, F1, M2…) so characters sound different.
  - Settings remembered between sessions; works on prefab assets and scene objects (Undo for scene objects).

#### 1.5.2 — 2026-11-02

##### Added
- Documentation: **Version & release history** section (current version, release date, requirements,
  compatibility/upgrade notes and the full changelog), generated from `package.json` and `CHANGELOG.md`
  on every release. Version banner at the top of the offline documentation.
- **Tools ▸ XRLP ▸ Offline TTS ▸ About** — shows the installed package version, ONNX Runtime version, Unity version
  and model status, with buttons for the documentation and changelog.
- `Tools~/build-docs.py` — regenerates the version section and `Documentation~/index.html` (run before each release).

#### 1.5.1 — 2026-11-02

##### Added
- **Per-object highlight look** on `TTSWordHighlighter` ("Look — this text only"): every highlight setting with a
  tick box to override it for that text only. Order: settings asset → parent TTS Overrides → the text's own values.
- Custom Inspector: *Customise all*, *Use global*, live *Effective look*, and a Play-mode *Preview* that steps through
  the words without speech (`PreviewHighlight()` / `StopPreview()` from code). New Editor assembly `XRLP.OfflineTTS.TMP.Editor`.
- `TTSHighlightOverrides` (reusable tick-to-override highlight settings), `TTSWordHighlighter.EffectiveSettings`.

#### 1.5.0 — 2026-11-02

##### Added
- **Spoken-word highlighting** for TextMeshPro: `TTSWordHighlighter` recolours and pops/zooms the current word
  (colour, zoom, pop duration, bounce, hold, lift, karaoke tint). Separate assembly `XRLP.OfflineTTS.TMP`,
  compiled only when TextMeshPro is present.
- Word timing: `TTSWordTiming`, `WordTimingEstimator`, `OfflineTTS.SynthesizeStreamingWithTimingAsync`,
  `SynthesizeClipWithTimingAsync`, `TTSClipInfo`; `TTSSpeaker.CurrentWordIndex`, `CurrentLineWords`,
  `onWordChanged`, static `AnyLineStarted` / `AnyWordChanged` / `AnyLineEnded`.
- **TTS Override** component: per-object overrides (tick-to-override) of speech and highlight settings,
  nearest override wins. Global highlight defaults in the settings asset (Word Highlight section).
- `TTSSpeaker.SpeakAsync(text, TTSRequest overrides)`, `PrewarmAsync(lines)`, `TTSSpeaker.AddTo(...)`
  (attach without overwriting an existing AudioSource setup), `TTSText.ToSpeakable` / `Words`.
- Integration Examples sample; documentation section on integrating with existing voice/dialogue systems.
##### Changed
- `TTSSpeaker` stops its line when another script stops or replaces the clip on its AudioSource
  (safe to share an AudioSource with an existing voice script).
- Rich-text tags are removed before speaking.

#### 1.4.0 — 2026-10-29

##### Added
- Install from Package Manager via Git URL / disk / tarball. First-run installer adds the npm scoped registry,
  ONNX Runtime dependency and `testables` to the project manifest automatically, then resolves
  (Tools ▸ XRLP ▸ Offline TTS ▸ Setup for repair/toggles).
- `.meta` files for every asset (required for Git / immutable package installs).
- Voice and Language dropdowns (`[TTSVoice]`, `[TTSLanguage]`) on TTS Speaker, Video Narrator (+ per-cue voice),
  Settings and TTSRequest.
- Detailed tooltips on every Inspector field and in the Voice-over Baker.
- Full documentation (Documentation~/index.md + offline HTML), linked from Package Manager and
  Tools ▸ XRLP ▸ Offline TTS ▸ Documentation.
##### Changed
- Voice-over Baker default output folder: Assets/Features/TTS/TTS_Baked (created automatically).
- ONNX Runtime is no longer a direct package.json dependency (added to the project by the installer);
  all package assemblies compile only once it is present (define XRLP_ORT).

#### 1.3.2 — 2026-10-15

- New settings assets are created at Assets/Features/TTS/OfflineTTSSettings.asset (folders created if missing).

#### 1.3.1 — 2026-10-15

- "Create Settings Asset" is now "Create or Locate Settings Asset": finds an existing TTSSettings asset anywhere in
  the project (prefers one named OfflineTTSSettings), selects and pings it, and only creates one if none exists.
- Add TTS Service / test scenes / baker reuse the existing settings asset; Add TTS Service won't add a second service.

#### 1.3.0 — 2026-10-15

- VR panel: text box + built-in VR keyboard, character selector, female/male voice grid, "Preview all 10 voices",
  floating name/voice tags. VR test scene now has a male and a female NPC.
- `TTSSpeaker.SpeakAsync` now returns `Task<bool>` (true = played to the end, false = stopped).

#### 1.2.0 — 2026-10-15

- VR test scene builder for XR Interaction Toolkit 3.x (Starter Assets rig, simulator, teleport floor).
- TTSVRTestPanel (world-space, ray/poke operated), TTSXRTalkOnInteract (select/activate/hover to speak),
  TTSSimulatorAutoDisable. XR assemblies compile only when XRI >= 3.0 is present.

#### 1.1.0 — 2026-10-15

- PC/Editor test kit: Run Diagnostics (no Play mode), Create Editor Test Scene, TTSTestBench play-mode panel
  (speak, timed generation, benchmark, WAV export), EditMode tests.
- Supports Enter Play Mode Options with domain reload disabled.
- Shared Edit-mode audio preview helper.

#### 1.0.0 — 2026-10-15

- Initial release: Supertonic 3 engine on ONNX Runtime, TTSSpeaker (sentence streaming), TTSVideoNarrator,
  memory + disk cache, voice blending, Editor voice-over baker, model downloader, Android model unpacking.

<!-- VERSION-SECTION:END -->
