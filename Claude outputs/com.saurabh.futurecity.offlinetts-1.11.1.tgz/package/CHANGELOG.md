# Changelog
All notable changes to FutureCity Offline TTS (named XRLAB Offline TTS / com.xrlab.offlinetts before this rename, and XRLP Offline TTS / com.xrlp.offlinetts before 1.9.0). Versions follow [Semantic Versioning](https://semver.org/).

## [Unreleased]
### Changed
- **Package renamed `com.xrlab.offlinetts` → `com.saurabh.futurecity.offlinetts`**; display name **FutureCity Offline TTS**.
- Namespaces and assemblies **`XRLAB.OfflineTTS*` → `SaurabhFutureCity.OfflineTTS*`** (`.Editor`, `.XR`, `.XR.Editor`,
  `.TMP`, `.TMP.Editor`, `.Installer`, `.Tests.Editor`).
- Scripting defines **`XRLAB_*` → `FUTURECITY_*`** (`FUTURECITY_ORT`, `FUTURECITY_XRI3`, `FUTURECITY_TMP`...).
- Menus moved to **`FutureCity ▸ Plugins ▸ OfflineTTS`** (menu bar, Add Component and Create menus).
- Editor preference keys renamed, so first-time setup prompts run once more.
- Script IDs (GUIDs) are unchanged: components, settings, timing assets and prefabs keep working.
- The installer now also removes `com.xrlab.offlinetts` from a project's manifest (as it already did for `com.xrlp.offlinetts`).

## [1.11.1] - 2026-11-07
### Fixed
- **Baked clips loaded with Addressables / AssetBundles weren't highlighted in builds.** Those systems load their own
  copy of a clip, which never equals the clip referenced by the timing asset. Timings are now also matched by
  **clip name**, using the clip length to tell apart different clips that share a name.
### Added
- `TTSClipTiming.clipName` / `clipLength`, filled automatically when timings are saved, synced (Repair Timing
  Library, before every build) or edited. Existing timing assets work without re-baking.

## [1.11.0] - 2026-11-07
Built on 1.10.1. The changes from 1.10.2 (diagnostics, retrying lookups, bridge execution order) are **withdrawn**.
### Added
- **Plugin Test Scene (Playground)** (FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create Plugin Test Scene (Playground)): one scene
  to test the plugin on its own, in the Editor (XR simulator / Quest Link) or as an APK: live TTS panel (voices,
  keyboard, speak), male + female NPCs, subtitle with word highlighting, and a **Baked Clips panel** filled from the
  timing library.
- **TTS Baked Clips Panel** component: plays listed clips on an AudioSource like an NPC voice script, shows per clip
  whether word timings exist, and reports on the panel whether each clip was followed and highlighted (and why not).
- `TTSClipTimings.KnownClipCount` and `LibraryCount` for status displays.

## [1.10.1] - 2026-11-06
### Fixed
- **Baked/recorded clips highlighted in the Editor but not in builds.** The Editor finds timing assets that aren't in
  the timing library linked to the settings asset in use (e.g. a project with several settings assets); builds didn't.
  Now:
  - before every build, all timing assets in the project are added to the timing library, the library is linked to
    **every** settings asset, and it's added to *Player Settings ▸ Preloaded Assets*;
  - at runtime, any loaded timing library is used, even if the active settings asset doesn't link it;
  - baking, the Word Timing Generator and Repair Timing Library do the same sync.

## [1.10.0] - 2026-11-06
### Added
- **TextMeshPro is installed with the plugin**: dependency on `com.unity.ugui` (includes TextMeshPro in Unity 6 /
  2023.2+); on Unity 2022.3 the installer adds `com.unity.textmeshpro`. **TMP Essential Resources** are imported
  automatically when missing (menu: Setup ▸ Import TextMeshPro Essentials).
- **TTS Subtitle Display** component: a TextMeshPro subtitle showing whatever line is spoken (live, baked or recorded)
  with word highlighting; speaker filter, speaker-name prefix, hide when silent, idle text, background toggle.
- Menus **Add Subtitles To Scene (Screen)** and **(World Space, VR)**.
- Both test scenes now include subtitles, so word highlighting is visible in the Editor and on the headset.
### Changed
- TTS Word Highlighter finds the first spoken word anywhere in the text (works with prefixes such as a speaker name).

## [1.9.2] - 2026-11-05
### Fixed (performance)
- **Severe frame drops / freezing in Play mode (Editor), introduced in 1.9.1.** The Editor fallback for timings that
  aren't in a library searched the whole project each time a clip without timings was checked; with music, ambience
  or other non-voice audio playing and TTS Auto Highlight in the scene, that happened ~10 times a second. Clips
  without timings are now remembered (checked once), and the fallback uses an index built once and refreshed only when
  the project changes.
- TTS Auto Highlight: refreshes its AudioSource list once a second (was every scan) and checks each clip once per
  AudioSource.
- TTS Word Highlighter: no longer forces a TextMeshPro rebuild every time the text changes (inside layout groups this
  could rebuild every frame while a line played); it only forces one when the text has no mesh yet.
- Settings lookup: when no settings asset is loaded, the scan for it runs at most once a second.

## [1.9.1] - 2026-11-05
### Fixed
- Baked/recorded clip not highlighted (and live TTS audio starting over it) when the clip started while a live TTS
  line on the same speaker was still being generated. The speaker now yields: it drops the pending line and follows
  the clip. Speaking while a clip is already playing still takes over as before.
### Added
- **Debug Log** on TTS Speaker (lines started/finished/dropped, clips followed, clips without timings) and on
  TTS Word Highlighter (which speaker it follows and why, how many spoken words matched the text).
- **Repair Timing Library** (FutureCity ▸ Plugins ▸ OfflineTTS): adds every timing asset in the project to the linked
  library, so they work in builds.
- In the Editor, a clip whose timing asset exists but isn't in a linked library is still highlighted, with a warning
  that it won't work in builds until the library is repaired.

## [1.9.0] - 2026-11-05
### Changed (breaking: renamed)
- Package renamed **`com.xrlp.offlinetts` → `com.xrlab.offlinetts`**; display name **XRLAB Offline TTS**.
- Namespaces **`XRLP.OfflineTTS` → `XRLAB.OfflineTTS`** (and `.Editor`, `.XR`, `.XR.Editor`); assemblies
  `XRLAB.OfflineTTS`, `XRLAB.OfflineTTS.TMP`, `XRLAB.OfflineTTS.XR`, `XRLAB.OfflineTTS.Editor`, … ;
  defines `XRLAB_ORT`, `XRLAB_TMP`, `XRLAB_XRI3`.
- Script GUIDs are unchanged, so components and assets in existing scenes and prefabs stay connected.
- Editor preferences use new keys (the Batch Add TTS Speakers template and model URL return to defaults once).
### Added
- The installer removes the old `com.xrlp.offlinetts` entry from `Packages/manifest.json` (dependencies and
  testables) and warns if an old embedded `Packages/com.xrlp.offlinetts` folder is still present.

## [1.8.0] - 2026-11-05
### Added
- **TTS Auto Highlight** component (FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Auto Highlight To Scene): one per scene makes
  word highlighting fully automatic. It adds a listen-only TTS Speaker to any AudioSource that plays a clip with word
  timings, finds the TextMeshPro text that shows the line (best word match), adds a TTS Word Highlighter and binds it.
  Works for baked, recorded and live TTS lines; scope (whole scene or children), ignore list, preferred texts,
  minimum match, debug log.
- `TTSText.MatchRatio(spoken, displayed)`: the shared rule for matching spoken lines to on-screen text.
- Integration Examples sample: `ManualHighlightExamples.cs` (manual setup in code, runtime timings, word events,
  live TTS).
- Documentation §4.8 rewritten as a complete guide (automatic, manual Inspector, manual code, how it works),
  new §4.9 component reference, troubleshooting and FAQ entries.

## [1.7.1] - 2026-11-04
### Fixed
- Compile error in Unity 6 (CS0619): `AudioImporter.preloadAudioData` is obsolete. The Word Timing Generator now uses
  the per-platform sample setting (`AudioImporterSampleSettings.preloadAudioData`) when it temporarily re-imports a
  compressed or streaming clip to read its audio.

## [1.7.0] - 2026-11-04
### Added
- **Word highlighting for baked and recorded clips.** `TTSClipTiming` (word timings per AudioClip),
  `TTSClipTimingLibrary`, runtime registry `TTSClipTimings`. A TTS Speaker follows any timed clip that another
  script plays on its AudioSource (`followExternalClips`, on by default) and drives highlighting like live TTS.
- **Voice-over Baker** saves exact per-sentence word timings next to each WAV (*Save word timings*, on by default)
  and links the timing library to the settings asset.
- **Word Timing Generator** (FutureCity ▸ Plugins ▸ OfflineTTS ▸ Word Timing Generator): word timings for human
  recordings or any voice clip from its script (typed or loaded as `clipName | text`); temporarily re-imports
  compressed/streaming clips to read them.
- Timing asset Inspector: word list with times, *Play clip*, *Re-estimate timings*.
- `TTSSettings.timingLibraries`, `TTSSettings.FindLoaded()`, `TTSSpeaker.IsFollowingExternalClip`.
### Changed
- **Menus moved to `FutureCity ▸ Plugins ▸ OfflineTTS`** (menu bar, Add Component and Create menus).
- An automatically created TTS service now uses the project's settings asset (found automatically; added to
  *Player Settings ▸ Preloaded Assets* at build time) instead of built-in defaults.

## [1.6.0] - 2026-11-03
### Added
- **Batch Add TTS Speakers** (Tools ▸ XRLP ▸ Offline TTS ▸ Batch Add TTS Speakers): pick a Main Prefab (drag it in,
  or type its name and press Find), enter an object name (e.g. `NpcAudio`) and/or a Target Prefab, configure every
  TTS Speaker setting once, then add or update a TTS Speaker on every match in the whole hierarchy (nested prefabs
  and inactive objects included).
  - Matches by GameObject name (exact or contains, case-insensitive), by component type (e.g. the `NpcAudio` script),
    and/or by instances of a Target Prefab (even when renamed).
  - *Find Matches* preview, *Add / Update*, *Remove*; existing speakers can be skipped or updated.
  - Nested prefabs: add as an override inside the Main Prefab, or to the nested prefab's own asset.
  - Voice: same for all, or cycle through a list (e.g. M1, F1, M2…) so characters sound different.
  - Settings remembered between sessions; works on prefab assets and scene objects (Undo for scene objects).

## [1.5.2] - 2026-11-02
### Added
- Documentation: **Version & release history** section (current version, release date, requirements,
  compatibility/upgrade notes and the full changelog), generated from `package.json` and `CHANGELOG.md`
  on every release. Version banner at the top of the offline documentation.
- **Tools ▸ XRLP ▸ Offline TTS ▸ About** — shows the installed package version, ONNX Runtime version, Unity version
  and model status, with buttons for the documentation and changelog.
- `Tools~/build-docs.py` — regenerates the version section and `Documentation~/index.html` (run before each release).
## [1.5.1] - 2026-11-02
### Added
- **Per-object highlight look** on `TTSWordHighlighter` ("Look — this text only"): every highlight setting with a
  tick box to override it for that text only. Order: settings asset → parent TTS Overrides → the text's own values.
- Custom Inspector: *Customise all*, *Use global*, live *Effective look*, and a Play-mode *Preview* that steps through
  the words without speech (`PreviewHighlight()` / `StopPreview()` from code). New Editor assembly `XRLP.OfflineTTS.TMP.Editor`.
- `TTSHighlightOverrides` (reusable tick-to-override highlight settings), `TTSWordHighlighter.EffectiveSettings`.
## [1.5.0] - 2026-11-02
### Added
- **Spoken-word highlighting** for TextMeshPro: `TTSWordHighlighter` recolours and pops/zooms the current word
  (colour, zoom, pop duration, bounce, hold, lift, karaoke tint). Separate assembly `XRLP.OfflineTTS.TMP`,
  compiled only when TextMeshPro is present.
- Word timing: `TTSWordTiming`, `WordTimingEstimator`, `OfflineTTS.SynthesizeStreamingWithTimingAsync`,
  `SynthesizeClipWithTimingAsync`, `TTSClipInfo`; `TTSSpeaker.CurrentWordIndex`, `CurrentLineWords`,
  `onWordChanged`, static `AnyLineStarted` / `AnyWordChanged` / `AnyLineEnded`.
- **TTS Override** component: per-object overrides (tick-to-override) of speech and highlight settings,
  nearest override wins. Global highlight defaults in the settings asset (Word Highlight section).
- `TTSSpeaker.SpeakAsync(text, TTSRequest overrides)`, `PrewarmAsync(lines)`, `TTSSpeaker.AddTo(...)`
  (attach without overwriting an existing AudioSource setup), `TTSText.ToSpeakable` / `Words`.
- Integration Examples sample; documentation section on integrating with existing voice/dialogue systems.
### Changed
- `TTSSpeaker` stops its line when another script stops or replaces the clip on its AudioSource
  (safe to share an AudioSource with an existing voice script).
- Rich-text tags are removed before speaking.
## [1.4.0] - 2026-10-29
### Added
- Install from Package Manager via Git URL / disk / tarball. First-run installer adds the npm scoped registry,
  ONNX Runtime dependency and `testables` to the project manifest automatically, then resolves
  (Tools ▸ XRLP ▸ Offline TTS ▸ Setup for repair/toggles).
- `.meta` files for every asset (required for Git / immutable package installs).
- Voice and Language dropdowns (`[TTSVoice]`, `[TTSLanguage]`) on TTS Speaker, Video Narrator (+ per-cue voice),
  Settings and TTSRequest.
- Detailed tooltips on every Inspector field and in the Voice-over Baker.
- Full documentation (Documentation~/index.md + offline HTML), linked from Package Manager and
  Tools ▸ XRLP ▸ Offline TTS ▸ Documentation.
### Changed
- Voice-over Baker default output folder: Assets/Features/TTS/TTS_Baked (created automatically).
- ONNX Runtime is no longer a direct package.json dependency (added to the project by the installer);
  all package assemblies compile only once it is present (define XRLP_ORT).
## [1.3.2] - 2026-10-15
- New settings assets are created at Assets/Features/TTS/OfflineTTSSettings.asset (folders created if missing).
## [1.3.1] - 2026-10-15
- "Create Settings Asset" is now "Create or Locate Settings Asset": finds an existing TTSSettings asset anywhere in
  the project (prefers one named OfflineTTSSettings), selects and pings it, and only creates one if none exists.
- Add TTS Service / test scenes / baker reuse the existing settings asset; Add TTS Service won't add a second service.
## [1.3.0] - 2026-10-15
- VR panel: text box + built-in VR keyboard, character selector, female/male voice grid, "Preview all 10 voices",
  floating name/voice tags. VR test scene now has a male and a female NPC.
- `TTSSpeaker.SpeakAsync` now returns `Task<bool>` (true = played to the end, false = stopped).
## [1.2.0] - 2026-10-15
- VR test scene builder for XR Interaction Toolkit 3.x (Starter Assets rig, simulator, teleport floor).
- TTSVRTestPanel (world-space, ray/poke operated), TTSXRTalkOnInteract (select/activate/hover to speak),
  TTSSimulatorAutoDisable. XR assemblies compile only when XRI >= 3.0 is present.
## [1.1.0] - 2026-10-15
- PC/Editor test kit: Run Diagnostics (no Play mode), Create Editor Test Scene, TTSTestBench play-mode panel
  (speak, timed generation, benchmark, WAV export), EditMode tests.
- Supports Enter Play Mode Options with domain reload disabled.
- Shared Edit-mode audio preview helper.
## [1.0.0] - 2026-10-15
- Initial release: Supertonic 3 engine on ONNX Runtime, TTSSpeaker (sentence streaming), TTSVideoNarrator,
  memory + disk cache, voice blending, Editor voice-over baker, model downloader, Android model unpacking.
