// FutureCity Offline TTS — Batch add TTS Speakers.
// FutureCity ▸ Plugins ▸ OfflineTTS ▸ Batch Add TTS Speakers
//
// 1. Main Prefab:   drag a prefab (or a scene object), or type its name and press Find.
// 2. Object name:   e.g. "NpcAudio" — matches GameObjects with that name and/or a component of that type.
// 3. Target prefab: e.g. your NpcAudio/NPC prefab — matches every instance of it inside the Main Prefab.
// Configure the TTS Speaker template (every TTS Speaker setting), press Find Matches to preview,
// then Add / Update to put a TTS Speaker on every match in the whole hierarchy (inactive objects included).

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using Object = UnityEngine.Object;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    public class TTSSpeakerBatchWindow : EditorWindow
    {
        enum ExistingSpeakerMode { Skip, UpdateSettings }
        enum NestedPrefabMode { OverrideInMainPrefab, OriginalPrefabAsset }
        enum VoiceAssignment { TemplateVoice, CycleThroughList }

        // ---- 1. main prefab
        [SerializeField] GameObject mainPrefab;
        [SerializeField] string prefabSearch = "";
        string[] _searchResults = Array.Empty<string>();

        // ---- 2. object name / 3. target prefab
        [SerializeField] string targetName = "NpcAudio";
        [SerializeField] bool exactName = true;
        [SerializeField] bool matchComponentType = true;
        [SerializeField] GameObject targetPrefab;
        [SerializeField] bool targetPrefabAlsoByName = true;

        // ---- options
        [SerializeField] ExistingSpeakerMode existingMode = ExistingSpeakerMode.UpdateSettings;
        [SerializeField] NestedPrefabMode nestedMode = NestedPrefabMode.OverrideInMainPrefab;
        [SerializeField] VoiceAssignment voiceAssignment = VoiceAssignment.TemplateVoice;
        [SerializeField] string[] voiceCycle = { "M1", "F1", "M2", "F2", "M3", "F3", "M4", "F4", "M5", "F5" };

        // ---- template + state
        GameObject _templateGO;
        TTSSpeaker _template;
        UnityEditor.Editor _templateEditor;
        List<string> _preview = new List<string>();
        string _lastReport;
        Vector2 _scroll, _previewScroll;
        bool _showTemplate = true, _showOptions = true;
        bool _editingAsset;   // true while the Main Prefab is opened in isolation (no Undo there)

        const string TemplatePrefKey = "SaurabhFutureCity.OfflineTTS.BatchSpeakerTemplate";

        [MenuItem("FutureCity/Plugins/OfflineTTS/Batch Add TTS Speakers", priority = 25)]
        public static void Open()
        {
            var w = GetWindow<TTSSpeakerBatchWindow>("Batch TTS Speakers");
            w.minSize = new Vector2(440, 560);
            if (Selection.activeGameObject != null && w.mainPrefab == null) w.mainPrefab = Selection.activeGameObject;
        }

        // ------------------------------------------------------------------ template lifecycle

        void OnEnable() => CreateTemplate();

        void OnDisable()
        {
            SaveTemplate();
            if (_templateEditor != null) DestroyImmediate(_templateEditor);
            if (_templateGO != null) DestroyImmediate(_templateGO);
        }

        void CreateTemplate()
        {
            if (_template != null) return;
            _templateGO = new GameObject("TTS Speaker Template") { hideFlags = HideFlags.HideAndDontSave };
            _templateGO.AddComponent<AudioSource>();
            _template = _templateGO.AddComponent<TTSSpeaker>();
            _template.configureSpatialAudio = false; // default for objects that already have a configured AudioSource (e.g. NpcAudio)
            string json = EditorPrefs.GetString(TemplatePrefKey, "");
            if (!string.IsNullOrEmpty(json))
            {
                try { EditorJsonUtility.FromJsonOverwrite(json, _template); } catch (Exception) { /* old/invalid data */ }
            }
            _templateEditor = UnityEditor.Editor.CreateEditor(_template);
        }

        void SaveTemplate()
        {
            if (_template != null) EditorPrefs.SetString(TemplatePrefKey, EditorJsonUtility.ToJson(_template));
        }

        // ------------------------------------------------------------------ GUI

        void OnGUI()
        {
            CreateTemplate();
            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            // 1 ---------------------------------------------------------------------------
            EditorGUILayout.LabelField("1. Main Prefab", EditorStyles.boldLabel);
            mainPrefab = (GameObject)EditorGUILayout.ObjectField(new GUIContent("Main Prefab",
                "The prefab to search through (every child, nested prefabs and inactive objects included). " +
                "A prefab asset from the Project window, or a GameObject in the open scene."), mainPrefab, typeof(GameObject), true);

            using (new EditorGUILayout.HorizontalScope())
            {
                prefabSearch = EditorGUILayout.TextField(new GUIContent("Find by name",
                    "Type part of the prefab's name and press Find to list matching prefab assets."), prefabSearch);
                if (GUILayout.Button(new GUIContent("Find", "Search the project for prefabs with this name."), GUILayout.Width(60)))
                    SearchPrefabs();
                if (GUILayout.Button(new GUIContent("Use selected", "Use the object selected in the Project or Hierarchy window."), GUILayout.Width(90))
                    && Selection.activeGameObject != null)
                    mainPrefab = Selection.activeGameObject;
            }
            foreach (var path in _searchResults)
            {
                if (GUILayout.Button(new GUIContent(path, "Use this prefab as the Main Prefab."), EditorStyles.miniButton))
                {
                    mainPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                    _searchResults = Array.Empty<string>();
                }
            }
            if (mainPrefab != null)
                EditorGUILayout.HelpBox(IsAsset(mainPrefab)
                    ? $"Prefab asset: {AssetDatabase.GetAssetPath(mainPrefab)}\nChanges are saved straight into the prefab (no Undo): use 'Remove' or version control to revert."
                    : "Scene object: changes are recorded with Undo; save the scene afterwards.", MessageType.None);

            // 2 ---------------------------------------------------------------------------
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("2. Object name (text)", EditorStyles.boldLabel);
            targetName = EditorGUILayout.TextField(new GUIContent("Object name",
                "Name of the objects that should get a TTS Speaker, e.g. NpcAudio. Leave empty to match only by Target Prefab."), targetName);
            using (new EditorGUI.IndentLevelScope())
            {
                exactName = EditorGUILayout.Toggle(new GUIContent("Exact name",
                    "On: the name must match exactly (ignoring upper/lower case).\nOff: the name only has to contain the text " +
                    "(e.g. 'NpcAudio' also matches 'NpcAudio (1)')."), exactName);
                matchComponentType = EditorGUILayout.Toggle(new GUIContent("Also match component type",
                    "Also match objects that have a component whose type is this name (e.g. the NpcAudio script), " +
                    "whatever the GameObject itself is called."), matchComponentType);
            }

            // 3 ---------------------------------------------------------------------------
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("3. Prefab / GameObject to look for", EditorStyles.boldLabel);
            targetPrefab = (GameObject)EditorGUILayout.ObjectField(new GUIContent("Target Prefab",
                "Optional: a prefab (e.g. your NpcAudio or NPC prefab). Every instance of it inside the Main Prefab is matched, " +
                "even if it was renamed. A scene GameObject here is matched by its name."), targetPrefab, typeof(GameObject), true);
            if (targetPrefab != null)
                using (new EditorGUI.IndentLevelScope())
                    targetPrefabAlsoByName = EditorGUILayout.Toggle(new GUIContent("Also match by its name",
                        "Also match objects that have the same name as the Target Prefab but aren't instances of it."), targetPrefabAlsoByName);

            // template -------------------------------------------------------------------
            EditorGUILayout.Space();
            _showTemplate = EditorGUILayout.Foldout(_showTemplate, new GUIContent("TTS Speaker settings to apply",
                "Every setting of the TTS Speaker component. These values are copied to each TTS Speaker that is added or updated. " +
                "Remembered between sessions."), true, EditorStyles.foldoutHeader);
            if (_showTemplate && _templateEditor != null)
            {
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    EditorGUI.BeginChangeCheck();
                    _templateEditor.OnInspectorGUI();
                    if (EditorGUI.EndChangeCheck()) SaveTemplate();
                    EditorGUILayout.HelpBox("Tip: keep 'Configure Spatial Audio' OFF when the objects already have a configured " +
                                            "AudioSource (e.g. NpcAudio), so their 3D settings stay unchanged. Event listeners that " +
                                            "point to scene objects can't be stored in prefab assets.", MessageType.None);
                    if (GUILayout.Button(new GUIContent("Reset settings to defaults", "Restore the default TTS Speaker values.")))
                    {
                        EditorPrefs.DeleteKey(TemplatePrefKey);
                        DestroyImmediate(_templateEditor); DestroyImmediate(_templateGO);
                        _template = null; CreateTemplate();
                    }
                }
            }

            // options --------------------------------------------------------------------
            _showOptions = EditorGUILayout.Foldout(_showOptions, "Options", true, EditorStyles.foldoutHeader);
            if (_showOptions)
            {
                using (new EditorGUI.IndentLevelScope())
                {
                    existingMode = (ExistingSpeakerMode)EditorGUILayout.EnumPopup(new GUIContent("If a TTS Speaker exists",
                        "Skip: leave objects that already have a TTS Speaker untouched.\n" +
                        "Update Settings: overwrite their settings with the values above."), existingMode);
                    nestedMode = (NestedPrefabMode)EditorGUILayout.EnumPopup(new GUIContent("Nested prefabs",
                        "When a match is inside a nested prefab (e.g. an NPC prefab placed in the Main Prefab):\n" +
                        "• Override In Main Prefab: add the TTS Speaker only inside the Main Prefab (an added-component override). " +
                        "Other prefabs using the same NPC are not affected.\n" +
                        "• Original Prefab Asset: add it to the NPC's own prefab asset, so EVERY place that uses it gets it."), nestedMode);
                    voiceAssignment = (VoiceAssignment)EditorGUILayout.EnumPopup(new GUIContent("Voice",
                        "Template Voice: every match gets the voice set above.\n" +
                        "Cycle Through List: matches get the voices below in turn, so characters sound different."), voiceAssignment);
                    if (voiceAssignment == VoiceAssignment.CycleThroughList)
                    {
                        var so = new SerializedObject(this);
                        EditorGUILayout.PropertyField(so.FindProperty("voiceCycle"), new GUIContent("Voices",
                            "Voices given to matches in order (F1–F5 female, M1–M5 male); repeats when it reaches the end."), true);
                        so.ApplyModifiedProperties();
                    }
                }
            }

            // actions --------------------------------------------------------------------
            EditorGUILayout.Space();
            bool ready = mainPrefab != null && (!string.IsNullOrWhiteSpace(targetName) || targetPrefab != null);
            using (new EditorGUI.DisabledScope(!ready))
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(new GUIContent("Find Matches", "List every object that would get a TTS Speaker (nothing is changed)."), GUILayout.Height(28)))
                    FindMatches();
                if (GUILayout.Button(new GUIContent("Add / Update TTS Speakers", "Go through the whole Main Prefab and add (or update) a TTS Speaker on every match."), GUILayout.Height(28)))
                    Apply(remove: false);
                if (GUILayout.Button(new GUIContent("Remove", "Remove the TTS Speaker from every match (undo helper)."), GUILayout.Width(70), GUILayout.Height(28)))
                    if (EditorUtility.DisplayDialog("Remove TTS Speakers", "Remove the TTS Speaker component from every matching object?", "Remove", "Cancel"))
                        Apply(remove: true);
            }
            if (!ready) EditorGUILayout.HelpBox("Set a Main Prefab and an Object name and/or a Target Prefab.", MessageType.Info);

            if (_preview.Count > 0)
            {
                EditorGUILayout.LabelField($"Matches ({_preview.Count})", EditorStyles.boldLabel);
                _previewScroll = EditorGUILayout.BeginScrollView(_previewScroll, GUILayout.MaxHeight(160));
                foreach (var p in _preview) EditorGUILayout.LabelField(p, EditorStyles.miniLabel);
                EditorGUILayout.EndScrollView();
            }
            if (!string.IsNullOrEmpty(_lastReport)) EditorGUILayout.HelpBox(_lastReport, MessageType.Info);

            EditorGUILayout.EndScrollView();
        }

        // ------------------------------------------------------------------ search

        void SearchPrefabs()
        {
            string term = prefabSearch.Trim();
            _searchResults = AssetDatabase.FindAssets("t:Prefab " + term)
                .Select(g => AssetDatabase.GUIDToAssetPath(g))
                .Where(p => System.IO.Path.GetFileNameWithoutExtension(p).IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                .OrderBy(p => System.IO.Path.GetFileNameWithoutExtension(p).Length)
                .Take(15).ToArray();
            if (_searchResults.Length == 0) ShowNotification(new GUIContent($"No prefab named '{term}'"));
            else if (_searchResults.Length == 1) { mainPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(_searchResults[0]); _searchResults = Array.Empty<string>(); }
        }

        List<GameObject> Matches(GameObject root)
        {
            var result = new List<GameObject>();
            string name = targetName?.Trim() ?? "";
            GameObject targetAsset = targetPrefab != null && IsAsset(targetPrefab) ? GetAssetRoot(targetPrefab) : null;
            string targetPrefabName = targetPrefab != null ? targetPrefab.name : null;

            foreach (var t in root.GetComponentsInChildren<Transform>(true))
            {
                var go = t.gameObject;
                bool match = false;
                if (name.Length > 0)
                {
                    match = NameMatches(go.name, name, exactName);
                    if (!match && matchComponentType)
                        match = go.GetComponents<Component>().Any(c => c != null &&
                                    string.Equals(c.GetType().Name, name, StringComparison.OrdinalIgnoreCase));
                }
                if (!match && targetPrefab != null)
                {
                    if (targetAsset != null) match = IsInstanceRootOf(go, targetAsset);
                    if (!match && (targetAsset == null || targetPrefabAlsoByName)) match = NameMatches(go.name, targetPrefabName, exact: true);
                }
                if (match) result.Add(go);
            }
            return result;
        }

        static bool NameMatches(string objectName, string wanted, bool exact) =>
            exact ? string.Equals(objectName, wanted, StringComparison.OrdinalIgnoreCase)
                  : objectName.IndexOf(wanted, StringComparison.OrdinalIgnoreCase) >= 0;

        /// <summary>True if <paramref name="go"/> is the root of an instance of <paramref name="asset"/> (directly or via variants/nesting).</summary>
        static bool IsInstanceRootOf(GameObject go, GameObject asset)
        {
            if (!PrefabUtility.IsAnyPrefabInstanceRoot(go)) return false;
            Object source = PrefabUtility.GetCorrespondingObjectFromSource(go);
            for (int guard = 0; source != null && guard < 16; guard++)
            {
                if (source == asset) return true;
                var next = PrefabUtility.GetCorrespondingObjectFromSource(source);
                if (next == source) break;
                source = next;
            }
            return false;
        }

        static bool IsAsset(GameObject go) => go != null && EditorUtility.IsPersistent(go);
        static GameObject GetAssetRoot(GameObject go) => go.transform.root.gameObject;

        static string PathOf(Transform t, Transform root)
        {
            var parts = new List<string>();
            for (var c = t; c != null; c = c.parent) { parts.Add(c.name); if (c == root) break; }
            parts.Reverse();
            return string.Join("/", parts);
        }

        // ------------------------------------------------------------------ preview + apply

        void FindMatches()
        {
            _lastReport = null;
            WithMainRoot(root =>
            {
                _preview = Matches(root).Select(go => PathOf(go.transform, root.transform) +
                                                      (go.GetComponent<TTSSpeaker>() != null ? "   (has TTS Speaker)" : "")).ToList();
                return false; // nothing changed
            });
            if (_preview.Count == 0) _lastReport = "No matches. Check the Object name / Target Prefab, or untick 'Exact name'.";
        }

        void Apply(bool remove)
        {
            int added = 0, updated = 0, skipped = 0, removed = 0, assets = 0, voiceIndex = 0;
            var touchedAssets = new HashSet<GameObject>();

            WithMainRoot(root =>
            {
                bool changedMain = false;
                foreach (var match in Matches(root))
                {
                    GameObject target = match;
                    bool inAsset = false;
                    if (nestedMode == NestedPrefabMode.OriginalPrefabAsset && PrefabUtility.IsPartOfPrefabInstance(match)
                        && PrefabUtility.GetNearestPrefabInstanceRoot(match) != root)
                    {
                        var original = PrefabUtility.GetCorrespondingObjectFromOriginalSource(match);
                        // Only real .prefab assets can be edited (not imported models such as .fbx).
                        if (original != null && AssetDatabase.GetAssetPath(original).EndsWith(".prefab", StringComparison.OrdinalIgnoreCase))
                        { target = original; inAsset = true; }
                    }

                    var existing = target.GetComponent<TTSSpeaker>();
                    if (remove)
                    {
                        if (existing == null) continue;
                        if (inAsset) Object.DestroyImmediate(existing, true);
                        else if (_editingAsset) Object.DestroyImmediate(existing);
                        else Undo.DestroyObjectImmediate(existing);
                        removed++;
                    }
                    else if (existing != null)
                    {
                        if (existingMode == ExistingSpeakerMode.Skip) { skipped++; continue; }
                        if (!inAsset && !_editingAsset) Undo.RecordObject(existing, "Update TTS Speaker");
                        CopyTemplate(existing, ref voiceIndex);
                        updated++;
                    }
                    else
                    {
                        var speaker = (inAsset || _editingAsset) ? target.AddComponent<TTSSpeaker>() : Undo.AddComponent<TTSSpeaker>(target);
                        CopyTemplate(speaker, ref voiceIndex);
                        added++;
                    }

                    if (inAsset) touchedAssets.Add(GetAssetRoot(target));
                    else { changedMain = true; EditorUtility.SetDirty(target); }
                }
                return changedMain;
            });

            foreach (var assetRoot in touchedAssets) { PrefabUtility.SavePrefabAsset(assetRoot); assets++; }

            _lastReport = remove
                ? $"Removed {removed} TTS Speaker(s)."
                : $"Added {added}, updated {updated}, skipped {skipped}." + (assets > 0 ? $" Saved {assets} nested prefab asset(s)." : "");
            Debug.Log("[OfflineTTS] Batch TTS Speakers: " + _lastReport);
            FindMatches();
        }

        void CopyTemplate(TTSSpeaker speaker, ref int voiceIndex)
        {
            EditorUtility.CopySerialized(_template, speaker);
            if (voiceAssignment == VoiceAssignment.CycleThroughList && voiceCycle != null && voiceCycle.Length > 0)
                speaker.voice = voiceCycle[voiceIndex++ % voiceCycle.Length];
            EditorUtility.SetDirty(speaker);
        }

        /// <summary>
        /// Runs <paramref name="work"/> on the Main Prefab's root. Prefab assets are opened in isolation
        /// (and saved if work returns true); scene objects are edited in place with Undo.
        /// </summary>
        void WithMainRoot(Func<GameObject, bool> work)
        {
            if (mainPrefab == null) return;
            if (IsAsset(mainPrefab))
            {
                string path = AssetDatabase.GetAssetPath(mainPrefab);
                var contents = PrefabUtility.LoadPrefabContents(path);
                _editingAsset = true;
                try
                {
                    if (work(contents)) PrefabUtility.SaveAsPrefabAsset(contents, path);
                }
                finally
                {
                    _editingAsset = false;
                    PrefabUtility.UnloadPrefabContents(contents);
                }
            }
            else
            {
                if (work(mainPrefab) && mainPrefab.scene.IsValid()) EditorSceneManager.MarkSceneDirty(mainPrefab.scene);
            }
        }
    }
}
