// FutureCity Offline TTS — Editor testing tools (PC).
//   FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create Editor Test Scene   – desktop test scene with speaker, panel and video narrator
//   FutureCity ▸ Plugins ▸ OfflineTTS ▸ Run Diagnostics            – loads the model and speaks a line WITHOUT entering Play mode

using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Video;
using Debug = UnityEngine.Debug;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    /// <summary>Plays AudioClips in Edit mode through the editor's internal preview player.</summary>
    public static class EditorAudioPreview
    {
        static AudioClip _clip;

        public static void Play(float[] samples, int sampleRate, string name = "TTS Preview")
        {
            Stop();
            if (_clip != null) UnityEngine.Object.DestroyImmediate(_clip);
            _clip = AudioClip.Create(name, Math.Max(1, samples.Length), 1, sampleRate, false);
            if (samples.Length > 0) _clip.SetData(samples, 0);

            var play = AudioUtil?.GetMethod("PlayPreviewClip", BindingFlags.Static | BindingFlags.Public, null,
                new[] { typeof(AudioClip), typeof(int), typeof(bool) }, null);
            if (play != null) play.Invoke(null, new object[] { _clip, 0, false });
            else Debug.LogWarning("[OfflineTTS] Edit-mode audio preview isn't available in this Unity version. Use the test scene in Play mode.");
        }

        public static void Stop() =>
            AudioUtil?.GetMethod("StopAllPreviewClips", BindingFlags.Static | BindingFlags.Public)?.Invoke(null, null);

        static Type AudioUtil => typeof(AudioImporter).Assembly.GetType("UnityEditor.AudioUtil");
    }

    public static class TTSEditorTesting
    {
        public const string TestFolder = "Assets/OfflineTTS_Test";

        /// <summary>
        /// Creates a TextMeshPro subtitle with word highlighting (position, rotation, world space?). Provided by the
        /// TextMeshPro editor assembly; null if TextMeshPro isn't available.
        /// </summary>
        public static Func<Vector3, Quaternion, bool, GameObject> CreateSubtitle;

        // ------------------------------------------------------------------ diagnostics (no Play mode)

        [MenuItem("FutureCity/Plugins/OfflineTTS/Run Diagnostics (no Play mode)", priority = 40)]
        public static void RunDiagnostics()
        {
            if (!EnsureModels()) return;

            string root = TTSModelSetup.StreamingRoot();
            var report = new System.Text.StringBuilder("[OfflineTTS] Diagnostics\n");
            report.AppendLine($"  Unity {Application.unityVersion} · {SystemInfo.operatingSystem} · {SystemInfo.processorType} ({SystemInfo.processorCount} threads)");
            report.AppendLine($"  Models: {root}");

            try
            {
                EditorUtility.DisplayProgressBar("Offline TTS diagnostics", "Loading model…", 0.2f);
                var sw = Stopwatch.StartNew();
                using (var engine = new SupertonicEngine(ModelLocator.OnnxDir(root), EngineOptions.Default))
                {
                    report.AppendLine($"  Model load: {sw.Elapsed.TotalSeconds:0.00} s · sample rate {engine.SampleRate} Hz");

                    var voice = VoiceStyle.FromFile(ModelLocator.VoicePath(root, "F1"));
                    const string line = "This is an offline text to speech test, running inside the Unity editor.";

                    EditorUtility.DisplayProgressBar("Offline TTS diagnostics", "Warm-up…", 0.5f);
                    engine.Synthesize("Hi.", "en", voice, new SynthesisParams { Steps = 1, Speed = 1.05f, Seed = 1 });

                    float[] samples = null;
                    foreach (var steps in new[] { 8, 5 })
                    {
                        EditorUtility.DisplayProgressBar("Offline TTS diagnostics", $"Synthesising ({steps} steps)…", steps == 8 ? 0.7f : 0.9f);
                        sw.Restart();
                        var s = engine.Synthesize(line, "en", voice, new SynthesisParams { Steps = steps, Speed = 1.05f, ChunkSilence = 0.3f, Seed = 1 });
                        double gen = sw.Elapsed.TotalSeconds, audio = s.Length / (double)engine.SampleRate;
                        report.AppendLine($"  {steps} steps: {audio:0.00} s audio in {gen:0.00} s → {audio / Math.Max(gen, 1e-6):0.0}x real-time");
                        if (samples == null) samples = s;
                    }

                    float peak = 0f;
                    foreach (var v in samples) peak = Math.Max(peak, Math.Abs(v));
                    report.AppendLine($"  Output peak level: {peak:0.000} " + (peak < 0.01f ? "⚠ near-silent — check model files" : "✓"));

                    WavUtility.ApplyEdgeFade(samples, engine.SampleRate);
                    EditorAudioPreview.Play(samples, engine.SampleRate);
                }
                report.AppendLine("  Result: PASS — you should hear the test line now.");
                Debug.Log(report.ToString());
            }
            catch (Exception e)
            {
                report.AppendLine("  Result: FAIL — " + e.Message);
                Debug.LogError(report + "\n" + e);
                EditorUtility.DisplayDialog("Offline TTS diagnostics failed", e.Message, "OK");
            }
            finally { EditorUtility.ClearProgressBar(); }
        }

        // ------------------------------------------------------------------ test scene

        [MenuItem("FutureCity/Plugins/OfflineTTS/Create Editor Test Scene", priority = 41)]
        public static void CreateTestScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            EnsureModels();

            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

            // Main Camera (from defaults) carries the AudioListener; place it like a seated user.
            var cam = Camera.main;
            if (cam != null) { cam.transform.position = new Vector3(0, 1.6f, -1.5f); cam.transform.rotation = Quaternion.identity; }

            var floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Floor";

            // Service
            var service = new GameObject("[OfflineTTS]").AddComponent<OfflineTTS>();
            AssignSettings(service);

            // Talking "NPC" in front of the camera (3D audio, so pan your view to hear it move).
            var npc = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            npc.name = "Test NPC (TTSSpeaker)";
            npc.transform.position = new Vector3(0, 1f, 1.5f);
            npc.AddComponent<AudioSource>();
            var speaker = npc.AddComponent<TTSSpeaker>();
            speaker.configureSpatialAudio = true;

            // On-screen test panel
            var bench = new GameObject("TTS Test Bench").AddComponent<TTSTestBench>();
            bench.speaker = speaker;

            CreateVideoNarratorTest(new Vector3(2.2f, 1.6f, 2f), 25f);
            CreateSubtitle?.Invoke(Vector3.zero, Quaternion.identity, false);   // screen subtitles with word highlighting

            Directory.CreateDirectory(TestFolder);
            string path = $"{TestFolder}/OfflineTTS_TestScene.unity";
            EditorSceneManager.SaveScene(scene, path);
            Selection.activeGameObject = bench.gameObject;

            EditorUtility.DisplayDialog("Offline TTS test scene",
                $"Created {path}.\n\nPress Play and use the Test Bench panel in the Game view.\n\n" +
                "Video test: select the 'Video Narrator Test' object, assign a VideoClip to its VideoPlayer, edit the cue times, and enable it.",
                "OK");
        }

        /// <summary>Adds a disabled video screen with a TTSVideoNarrator and sample cues.</summary>
        public static GameObject CreateVideoNarratorTest(Vector3 position, float yaw)
        {
            var screen = GameObject.CreatePrimitive(PrimitiveType.Quad);
            screen.name = "Video Narrator Test (assign a VideoClip, then enable)";
            screen.transform.position = position;
            screen.transform.rotation = Quaternion.Euler(0, yaw, 0);
            screen.transform.localScale = new Vector3(1.92f, 1.08f, 1f);
            var vp = screen.AddComponent<VideoPlayer>();
            vp.renderMode = VideoRenderMode.MaterialOverride;
            vp.targetMaterialRenderer = screen.GetComponent<Renderer>();
            vp.audioOutputMode = VideoAudioOutputMode.Direct;
            vp.isLooping = false;
            var narrationSrc = screen.AddComponent<AudioSource>();
            narrationSrc.spatialBlend = 0f;
            var narrator = screen.AddComponent<TTSVideoNarrator>();
            narrator.videoPlayer = vp;
            narrator.narrationSource = narrationSrc;
            narrator.cues.Add(new NarrationCue { time = 0.5, text = "In this video, watch how the worker checks the load before lifting." });
            narrator.cues.Add(new NarrationCue { time = 5.0, text = "Notice the feet are shoulder width apart, and the back stays straight.", pauseVideoWhileSpeaking = true });
            narrator.cues.Add(new NarrationCue { time = 10.0, text = "Now the load is kept close to the waist while walking." });
            screen.SetActive(false);
            return screen;
        }

        /// <summary>Assigns the project's existing TTSSettings asset (if any) to the service. Never creates one.</summary>
        public static void AssignSettings(OfflineTTS service) =>
            TTSModelSetup.AssignSettings(service, TTSModelSetup.FindSettings());

        public static bool EnsureModels()
        {
            if (TTSModelSetup.ModelsPresent()) return true;
            if (EditorUtility.DisplayDialog("Offline TTS", "Supertonic models were not found in StreamingAssets/Supertonic.", "Download now", "Cancel"))
                TTSModelSetup.DownloadModels();
            return false;
        }
    }
}
