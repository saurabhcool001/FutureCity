// FutureCity Offline TTS — builds a VR test scene for XR Interaction Toolkit 3.x.
// FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create VR Test Scene (XRI)

using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.PackageManager.UI;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation;
using UnityEngine.XR.Interaction.Toolkit.UI;
using SaurabhFutureCity.OfflineTTS.XR;
using SaurabhFutureCity.OfflineTTS.Editor;

namespace SaurabhFutureCity.OfflineTTS.XR.Editor
{
    public static class TTSVRTestSceneBuilder
    {
        const string XriPackage = "com.unity.xr.interaction.toolkit";
        const string RigPrefabName = "XR Origin (XR Rig)";
        static readonly string[] SimulatorPrefabNames = { "XR Interaction Simulator", "XR Device Simulator" };

        [MenuItem("FutureCity/Plugins/OfflineTTS/Create VR Test Scene (XRI)", priority = 42)]
        public static void Create() => Build(playground: false);

        /// <summary>
        /// The plugin's test scene: everything in the VR test scene (live TTS with keyboard, male + female NPCs, subtitle)
        /// plus a Baked Clips panel filled from the timing library, to test baked / recorded clips and highlighting.
        /// </summary>
        [MenuItem("FutureCity/Plugins/OfflineTTS/Create Plugin Test Scene (Playground)", priority = 43)]
        public static void CreatePlayground() => Build(playground: true);

        static void Build(bool playground)
        {
            // 1) XRI Starter Assets provide the XR Origin rig with ray/poke/grab + locomotion already wired.
            var rigPrefab = FindPrefab(RigPrefabName);
            var simPrefab = SimulatorPrefabNames.Select(FindPrefab).FirstOrDefault(p => p != null);

            if (rigPrefab == null || simPrefab == null)
            {
                string missing = rigPrefab == null && simPrefab == null ? "Starter Assets and the XR simulator"
                               : rigPrefab == null ? "Starter Assets" : "the XR simulator (for testing without a headset)";
                int choice = EditorUtility.DisplayDialogComplex("VR test scene",
                    $"This scene uses XR Interaction Toolkit samples. Missing: {missing}.\n\n" +
                    "Import them now? After Unity finishes compiling, run this menu again.",
                    "Import", "Cancel", rigPrefab != null ? "Continue without simulator" : "");
                if (choice == 1) return;
                if (choice == 0)
                {
                    if (rigPrefab == null) ImportSample("Starter Assets");
                    if (simPrefab == null && !ImportSample("Interaction Simulator")) ImportSample("Device Simulator");
                    return;
                }
                if (rigPrefab == null) return;
            }

            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            TTSEditorTesting.EnsureModels();

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Lighting + floor (teleportable)
            var light = new GameObject("Directional Light").AddComponent<Light>();
            light.type = LightType.Directional;
            light.transform.rotation = Quaternion.Euler(50, -30, 0);

            var floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Floor (Teleportation Area)";
            floor.transform.localScale = new Vector3(2, 1, 2);
            floor.AddComponent<TeleportationArea>();

            // XR rig (its camera carries the AudioListener)
            var rig = (GameObject)PrefabUtility.InstantiatePrefab(rigPrefab);
            rig.transform.position = Vector3.zero;

            // Simulator for keyboard/mouse testing; removes itself when a headset is active or in builds
            if (simPrefab != null)
            {
                var sim = (GameObject)PrefabUtility.InstantiatePrefab(simPrefab);
                sim.AddComponent<TTSSimulatorAutoDisable>();
            }

            // Event system for world-space UI
            var es = new GameObject("EventSystem", typeof(EventSystem), typeof(XRUIInputModule));

            // TTS service
            var service = new GameObject("[OfflineTTS]").AddComponent<OfflineTTS>();
            TTSEditorTesting.AssignSettings(service);

            // Two NPCs (male + female): select them (grip, or trigger on the ray) to make them talk
            var trainer = CreateNpc("Trainer (male) - select to talk", new Vector3(-0.35f, 1f, 2f), "M1",
                new Color(0.25f, 0.4f, 0.75f), new[]
                {
                    "Hello! I'm your safety trainer. My voice is generated on this device.",
                    "Remember to check the load before you lift it.",
                    "Great job. Walk around me and listen to how my voice stays where I am.",
                });
            var supervisor = CreateNpc("Supervisor (female) - select to talk", new Vector3(0.45f, 1f, 2.2f), "F1",
                new Color(0.75f, 0.3f, 0.55f), new[]
                {
                    "Hi, I'm the site supervisor. Please sign in before you start work.",
                    "If something is too heavy, always ask a colleague for help.",
                    "Make sure your hard hat and high visibility vest are on.",
                });

            // Table + grabbable "radio": pick it up and pull the trigger; move it around your head to hear 3D audio
            var table = GameObject.CreatePrimitive(PrimitiveType.Cube);
            table.name = "Table";
            table.transform.position = new Vector3(1.0f, 0.375f, 0.9f);
            table.transform.localScale = new Vector3(0.8f, 0.75f, 0.6f);

            var radio = GameObject.CreatePrimitive(PrimitiveType.Cube);
            radio.name = "Radio - grab + trigger to talk";
            radio.transform.position = new Vector3(1.0f, 0.85f, 0.9f);
            radio.transform.localScale = new Vector3(0.2f, 0.12f, 0.08f);
            var rb = radio.AddComponent<Rigidbody>();
            rb.mass = 0.5f;
            radio.AddComponent<AudioSource>();
            var radioSpeaker = radio.AddComponent<TTSSpeaker>();
            radioSpeaker.voice = "F2";
            var grab = radio.AddComponent<XRGrabInteractable>();
            var radioTalk = radio.AddComponent<TTSXRTalkOnInteract>();
            radioTalk.interactable = grab;
            radioTalk.speaker = radioSpeaker;
            radioTalk.trigger = TTSXRTalkOnInteract.TriggerMode.Activate;
            radioTalk.lines = new[]
            {
                "Radio check. Move me around your head to test spatial audio.",
                "This is control. All workers, please report to the assembly point.",
                "Testing, one, two, three.",
            };

            // World-space test panel to the front-left, angled toward the player
            var panel = new GameObject("TTS VR Test Panel");
            panel.transform.position = new Vector3(-1.05f, 1.25f, 1.25f);
            panel.transform.rotation = Quaternion.Euler(0, -40f, 0);
            var panelComp = panel.AddComponent<TTSVRTestPanel>();
            panelComp.characters = new[] { trainer, supervisor, radioSpeaker };

            // Video narration test behind the table (disabled until a clip is assigned)
            TTSEditorTesting.CreateVideoNarratorTest(new Vector3(1.6f, 1.6f, 2.6f), 30f);

            // World-space subtitle above the NPCs: shows every spoken line with word highlighting (TextMeshPro).
            TTSEditorTesting.CreateSubtitle?.Invoke(new Vector3(0.05f, 2.25f, 2.3f), Quaternion.identity, true);

            Directory.CreateDirectory(TTSEditorTesting.TestFolder);
            if (playground)
            {
                // Baked clips panel to the right, angled toward the player; plays clips on the trainer's AudioSource
                // the way an NPC voice script does, so highlighting of baked audio can be checked.
                var bakedGo = new GameObject("TTS Baked Clips Panel");
                bakedGo.transform.position = new Vector3(1.4f, 1.25f, 1.6f);
                bakedGo.transform.rotation = Quaternion.Euler(0, 40f, 0);
                var baked = bakedGo.AddComponent<TTSBakedClipsPanel>();
                baked.playOn = trainer.GetComponent<AudioSource>();
                baked.clips = AssetDatabase.FindAssets("t:TTSClipTiming")
                    .Select(g => AssetDatabase.LoadAssetAtPath<TTSClipTiming>(AssetDatabase.GUIDToAssetPath(g)))
                    .Where(t => t != null && t.clip != null)
                    .Select(t => t.clip).Distinct().OrderBy(c => c.name).ToList();
                TTSTimingAssets.SyncAllTimings();   // make sure the timings are linked + preloaded for builds too
            }

            string path = playground
                ? $"{TTSEditorTesting.TestFolder}/OfflineTTS_Playground.unity"
                : $"{TTSEditorTesting.TestFolder}/OfflineTTS_VRTestScene.unity";
            EditorSceneManager.SaveScene(scene, path);
            Selection.activeGameObject = panel;

            if (playground)
            {
                EditorUtility.DisplayDialog("Offline TTS — Plugin Test Scene (Playground)",
                    $"Created {path}\n\n" +
                    "• LEFT panel: live TTS: pick character + voice, type text, SPEAK\n" +
                    "• RIGHT panel: baked clips (from your timing library): PLAY plays a clip on the trainer like an NPC voice script; " +
                    "the panel shows whether it was followed and highlighted\n" +
                    "• Subtitle above the NPCs: every line with word highlighting\n\n" +
                    "Add more clips: select 'TTS Baked Clips Panel' and drag clips into Clips.\n" +
                    "Test in the Editor (XR simulator / Quest Link) or build only this scene to an APK.",
                    "OK");
                return;
            }
            EditorUtility.DisplayDialog("Offline TTS — VR test scene",
                $"Created {path}\n\n" +
                "• Test panel (left): pick a character, pick a female/male voice, type text, press SPEAK\n" +
                "• Two NPCs (male + female): select them (grip) to talk\n" +
                "• Subtitle above the NPCs: shows every spoken line with word highlighting\n" +
                "• Radio on the table: grab it, pull trigger to talk, move it around your head\n\n" +
                (simPrefab != null
                    ? "Without a headset: press Play and use the XR simulator (keyboard + mouse).\n"
                    : "No simulator in the scene: test with a headset over Link.\n") +
                "With Quest Link / Air Link: enable OpenXR for Windows in Project Settings ▸ XR Plug-in Management, then press Play.\n" +
                "On device: add the scene to Build Settings and build for Android (IL2CPP, ARM64).",
                "OK");
        }

        static TTSSpeaker CreateNpc(string name, Vector3 position, string voice, Color color, string[] lines)
        {
            var npc = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            npc.name = name;
            npc.transform.position = position;
            npc.transform.rotation = Quaternion.Euler(0, 180, 0);

            var mat = new Material(npc.GetComponent<Renderer>().sharedMaterial) { color = color };
            Directory.CreateDirectory(TTSEditorTesting.TestFolder);
            string matPath = AssetDatabase.GenerateUniqueAssetPath($"{TTSEditorTesting.TestFolder}/{voice}_NPC.mat");
            AssetDatabase.CreateAsset(mat, matPath);
            npc.GetComponent<Renderer>().sharedMaterial = mat;

            npc.AddComponent<AudioSource>();
            var speaker = npc.AddComponent<TTSSpeaker>();
            speaker.voice = voice;
            var interactable = npc.AddComponent<XRSimpleInteractable>();
            var talk = npc.AddComponent<TTSXRTalkOnInteract>();
            talk.interactable = interactable;
            talk.speaker = speaker;
            talk.trigger = TTSXRTalkOnInteract.TriggerMode.Select;
            talk.lines = lines;
            return speaker;
        }

        static GameObject FindPrefab(string exactName)
        {
            foreach (var guid in AssetDatabase.FindAssets("t:Prefab " + exactName.Split(' ')[0]))
            {
                string p = AssetDatabase.GUIDToAssetPath(guid);
                if (Path.GetFileNameWithoutExtension(p) == exactName)
                    return AssetDatabase.LoadAssetAtPath<GameObject>(p);
            }
            return null;
        }

        static bool ImportSample(string nameContains)
        {
            var sample = Sample.FindByPackage(XriPackage, null)
                .FirstOrDefault(s => s.displayName.Contains(nameContains));
            if (string.IsNullOrEmpty(sample.displayName))
            {
                Debug.LogWarning($"[OfflineTTS] XRI sample containing '{nameContains}' not found. Import it from Package Manager ▸ XR Interaction Toolkit ▸ Samples.");
                return false;
            }
            if (!sample.isImported) sample.Import(Sample.ImportOptions.OverridePreviousImports);
            Debug.Log($"[OfflineTTS] Imported XRI sample '{sample.displayName}'.");
            return true;
        }
    }
}
