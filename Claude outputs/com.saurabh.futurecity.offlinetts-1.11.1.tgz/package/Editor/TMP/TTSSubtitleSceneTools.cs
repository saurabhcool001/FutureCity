// FutureCity Offline TTS — builds TextMeshPro subtitles (screen or world space) with word highlighting.
//   FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Subtitles To Scene
// Also used by the Editor and VR test scenes.

using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using SaurabhFutureCity.OfflineTTS.Installer;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    [InitializeOnLoad]
    static class TTSSubtitleSceneTools
    {
        static TTSSubtitleSceneTools() => TTSEditorTesting.CreateSubtitle = Create;

        [MenuItem("FutureCity/Plugins/OfflineTTS/Add Subtitles To Scene (Screen)", priority = 5)]
        static void AddScreen() => Selection.activeGameObject = Create(Vector3.zero, Quaternion.identity, false);

        [MenuItem("FutureCity/Plugins/OfflineTTS/Add Subtitles To Scene (World Space, VR)", priority = 6)]
        static void AddWorld()
        {
            var cam = Camera.main;
            Vector3 pos = cam != null ? cam.transform.position + cam.transform.forward * 2f + Vector3.down * 0.4f : new Vector3(0, 1.4f, 2f);
            Quaternion rot = cam != null ? Quaternion.LookRotation(Vector3.ProjectOnPlane(cam.transform.forward, Vector3.up)) : Quaternion.identity;
            Selection.activeGameObject = Create(pos, rot, true);
        }

        /// <summary>
        /// Creates a subtitle: a canvas with a dark background (shown while speaking) and a TextMeshPro text with
        /// TTS Subtitle Display + TTS Word Highlighter. World space = 1.6 m × 0.3 m panel for VR.
        /// </summary>
        public static GameObject Create(Vector3 position, Quaternion rotation, bool worldSpace)
        {
            TTSPackageInstaller.EnsureTmpEssentials(interactive: false);   // default font + shaders, else text is invisible

            var root = new GameObject(worldSpace ? "Subtitles (World Space)" : "Subtitles (Screen)", typeof(RectTransform));
            Undo.RegisterCreatedObjectUndo(root, "Add Subtitles");
            var canvas = root.AddComponent<Canvas>();
            var rt = (RectTransform)root.transform;

            if (worldSpace)
            {
                canvas.renderMode = RenderMode.WorldSpace;
                rt.position = position;
                rt.rotation = rotation;
                rt.sizeDelta = new Vector2(1600, 300);
                rt.localScale = Vector3.one * 0.001f;   // 1000 px = 1 m
            }
            else
            {
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvas.sortingOrder = 100;
                var scaler = root.AddComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1920, 1080);
                scaler.matchWidthOrHeight = 0.5f;
            }

            // Background: a sibling of the text, so hiding it never disables the subtitle component itself.
            var bg = new GameObject("Background", typeof(RectTransform), typeof(Image));
            bg.transform.SetParent(root.transform, false);
            var bgRt = (RectTransform)bg.transform;
            var img = bg.GetComponent<Image>();
            img.color = new Color(0.149f, 0.196f, 0.22f, 0.88f);   // #263238, 88%
            img.raycastTarget = false;

            var textGo = new GameObject("Subtitle Text", typeof(RectTransform));
            textGo.transform.SetParent(root.transform, false);
            var textRt = (RectTransform)textGo.transform;
            var tmp = textGo.AddComponent<TextMeshProUGUI>();
            tmp.text = "";
            tmp.color = new Color(0.925f, 0.937f, 0.945f);          // #ECEFF1
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.raycastTarget = false;

            if (worldSpace)
            {
                Stretch(bgRt, 0, 0);
                Stretch(textRt, 40, 24);
                tmp.fontSize = 64;
            }
            else
            {
                // Bottom band, 16% of the screen height.
                bgRt.anchorMin = new Vector2(0.1f, 0.03f); bgRt.anchorMax = new Vector2(0.9f, 0.19f);
                bgRt.offsetMin = bgRt.offsetMax = Vector2.zero;
                textRt.anchorMin = bgRt.anchorMin; textRt.anchorMax = bgRt.anchorMax;
                textRt.offsetMin = new Vector2(30, 14); textRt.offsetMax = new Vector2(-30, -14);
                tmp.fontSize = 40;
            }

            var highlighter = textGo.AddComponent<TTSWordHighlighter>();
            highlighter.listenTo = TTSWordHighlighter.ListenMode.BoundFromCode;
            var display = textGo.AddComponent<TTSSubtitleDisplay>();
            var so = new SerializedObject(display);
            so.FindProperty("showWhileSpeaking").objectReferenceValue = bg;
            so.ApplyModifiedPropertiesWithoutUndo();
            bg.SetActive(false);

            return root;
        }

        static void Stretch(RectTransform rt, float padX, float padY)
        {
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(padX, padY); rt.offsetMax = new Vector2(-padX, -padY);
        }
    }
}
