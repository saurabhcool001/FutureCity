// FutureCity Offline TTS — FutureCity ▸ Plugins ▸ OfflineTTS ▸ Add Auto Highlight To Scene
using UnityEditor;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    static class TTSAutoHighlightMenu
    {
        [MenuItem("FutureCity/Plugins/OfflineTTS/Add Auto Highlight To Scene", priority = 4)]
        static void AddToScene()
        {
#if UNITY_2023_1_OR_NEWER
            var existing = Object.FindFirstObjectByType<TTSAutoHighlight>();
#else
            var existing = Object.FindObjectOfType<TTSAutoHighlight>();
#endif
            if (existing != null)
            {
                Debug.Log("[OfflineTTS] The scene already has a TTS Auto Highlight; selecting it.");
                Selection.activeObject = existing;
                EditorGUIUtility.PingObject(existing);
                return;
            }
            var go = new GameObject("[TTS Auto Highlight]");
            go.AddComponent<TTSAutoHighlight>();
            Undo.RegisterCreatedObjectUndo(go, "Add TTS Auto Highlight");
            Selection.activeObject = go;
        }
    }
}
