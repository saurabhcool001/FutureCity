// FutureCity Offline TTS — Word Timing Generator window (FutureCity ▸ Plugins ▸ OfflineTTS ▸ Word Timing Generator).
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    // ------------------------------------------------------------------ Word Timing Generator window

    public class TTSWordTimingWindow : EditorWindow
    {
        [Serializable]
        class Entry
        {
            public AudioClip clip;
            [TextArea(2, 4)] public string text;
            public string status;
        }

        [SerializeField] List<Entry> entries = new List<Entry>();
        Vector2 _scroll;

        [MenuItem("FutureCity/Plugins/OfflineTTS/Word Timing Generator", priority = 22)]
        public static void Open()
        {
            var w = GetWindow<TTSWordTimingWindow>("Word Timings");
            w.minSize = new Vector2(460, 420);
            w.AddSelectedClips();
        }

        void OnGUI()
        {
            EditorGUILayout.HelpBox(
                "Create word timings for any voice clip (human recordings, other TTS, older bakes) so the spoken word is " +
                "highlighted while it plays. Give each clip the exact words it says. Timings are estimated from the audio " +
                "and the text, saved next to the clip, and added to the timing library linked in your settings asset.",
                MessageType.Info);

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(new GUIContent("Add selected clips", "Add the AudioClips selected in the Project window."))) AddSelectedClips();
                if (GUILayout.Button(new GUIContent("Load script (.txt / .csv)",
                        "Fill the text for clips from a file with one line per clip: clipName | text  (or CSV: clipName,text). " +
                        "Clips that aren't in the list yet are found in the project by name and added."))) LoadScript();
                if (GUILayout.Button(new GUIContent("Clear", "Remove all entries from this list (assets are not touched)."))) entries.Clear();
            }

            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            for (int i = 0; i < entries.Count; i++)
            {
                var e = entries[i];
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        var clip = (AudioClip)EditorGUILayout.ObjectField(new GUIContent("Clip", "The voice clip."), e.clip, typeof(AudioClip), false);
                        if (clip != e.clip) { e.clip = clip; e.text = string.IsNullOrEmpty(e.text) ? ExistingText(clip) : e.text; e.status = null; }
                        if (GUILayout.Button(new GUIContent("✕", "Remove this entry from the list."), GUILayout.Width(24))) { entries.RemoveAt(i); GUIUtility.ExitGUI(); }
                    }
                    EditorGUILayout.LabelField(new GUIContent("Text (exactly what is said)",
                        "Word for word what the clip says. Use the same wording as the on-screen text so highlighting can match it."));
                    e.text = EditorGUILayout.TextArea(e.text ?? "", GUILayout.MinHeight(40));
                    if (!string.IsNullOrEmpty(e.status)) EditorGUILayout.LabelField(e.status, EditorStyles.miniLabel);
                }
            }
            EditorGUILayout.EndScrollView();

            if (GUILayout.Button(new GUIContent("+ Add empty entry", "Add a row to fill in by hand."))) entries.Add(new Entry());

            EditorGUILayout.Space();
            using (new EditorGUI.DisabledScope(entries.Count == 0))
                if (GUILayout.Button(new GUIContent("Generate word timings", "Estimate and save timings for every entry that has a clip and text."), GUILayout.Height(30)))
                    Generate();
        }

        static string ExistingText(AudioClip clip)
        {
            if (clip == null) return "";
            string path = AssetDatabase.GetAssetPath(clip);
            var timing = AssetDatabase.LoadAssetAtPath<TTSClipTiming>($"{Path.GetDirectoryName(path)?.Replace('\\', '/')}/{clip.name}_Timing.asset");
            return timing != null ? timing.text : "";
        }

        void AddSelectedClips()
        {
            foreach (var clip in Selection.objects.OfType<AudioClip>())
                if (entries.All(e => e.clip != clip))
                    entries.Add(new Entry { clip = clip, text = ExistingText(clip) });
        }

        void LoadScript()
        {
            string path = EditorUtility.OpenFilePanel("Script", "", "txt,csv");
            if (string.IsNullOrEmpty(path)) return;
            int filled = 0, added = 0;
            foreach (var raw in File.ReadAllLines(path))
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;
                int sep = line.IndexOf('|');
                if (sep < 0) sep = line.IndexOf(',');
                if (sep <= 0) continue;
                string name = line.Substring(0, sep).Trim();
                string text = line.Substring(sep + 1).Trim().Trim('"');

                var entry = entries.FirstOrDefault(e => e.clip != null && string.Equals(e.clip.name, name, StringComparison.OrdinalIgnoreCase));
                if (entry == null)
                {
                    var guid = AssetDatabase.FindAssets($"t:AudioClip {name}")
                        .FirstOrDefault(g => string.Equals(Path.GetFileNameWithoutExtension(AssetDatabase.GUIDToAssetPath(g)), name, StringComparison.OrdinalIgnoreCase));
                    if (guid == null) continue;
                    entry = new Entry { clip = AssetDatabase.LoadAssetAtPath<AudioClip>(AssetDatabase.GUIDToAssetPath(guid)) };
                    entries.Add(entry);
                    added++;
                }
                entry.text = text;
                filled++;
            }
            ShowNotification(new GUIContent($"Filled {filled} text(s), added {added} clip(s)"));
        }

        void Generate()
        {
            var library = TTSTimingAssets.GetOrCreateLibrary();
            int ok = 0, failed = 0;
            try
            {
                for (int i = 0; i < entries.Count; i++)
                {
                    var e = entries[i];
                    if (e.clip == null || string.IsNullOrWhiteSpace(e.text)) { e.status = "Skipped: needs a clip and its text."; continue; }
                    if (EditorUtility.DisplayCancelableProgressBar("Word timings", e.clip.name, i / (float)entries.Count)) break;

                    if (TTSTimingAssets.TryEstimate(e.clip, e.text, out var words))
                    {
                        TTSTimingAssets.SaveTiming(e.clip, e.text, words, TTSClipTiming.TimingSource.EstimatedFromRecording, library);
                        e.status = $"✓ {words.Length} words timed";
                        ok++;
                    }
                    else { e.status = "Couldn't read the audio of this clip."; failed++; }
                }
            }
            finally { EditorUtility.ClearProgressBar(); }
            TTSTimingAssets.SyncAllTimings();   // link to every settings asset + preload, so builds include them
            Debug.Log($"[OfflineTTS] Word timings: {ok} created/updated, {failed} failed. Library: {AssetDatabase.GetAssetPath(library)}");
        }
    }
}
