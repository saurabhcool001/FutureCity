// FutureCity Offline TTS — first-run project setup.
//
// Unity packages cannot declare scoped registries, so a package that depends on an npm package
// (ONNX Runtime for Unity) can't pull it in by itself. This installer runs as soon as the package is
// imported (it has no dependency on ONNX Runtime, so it always compiles) and:
//   1. adds the npm scoped registry for "com.github.asus4" to Packages/manifest.json,
//   2. adds com.github.asus4.onnxruntime to the project dependencies,
//   3. adds this package to "testables" so its tests appear in the Test Runner,
// then asks the Package Manager to resolve. Until ONNX Runtime is installed, the rest of this package is
// excluded from compilation (define constraint FUTURECITY_ORT), so there are no compile errors in between.

using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEngine;
using PackageInfo = UnityEditor.PackageManager.PackageInfo;

namespace SaurabhFutureCity.OfflineTTS.Installer
{
    [InitializeOnLoad]
    public static class TTSPackageInstaller
    {
        public const string PackageName = "com.saurabh.futurecity.offlinetts";
        /// <summary>Name this package had before 1.9.0. If a project still references it, it's removed (this package replaces it).</summary>
        /// <summary>Earlier names of this package. Installing this one removes them (they share script IDs).</summary>
        public static readonly string[] OldPackageNames = { "com.xrlp.offlinetts", "com.xrlab.offlinetts" };
        public const string OrtPackage = "com.github.asus4.onnxruntime";
        public const string OrtVersion = "0.4.9";
        const string RegistryName = "npmjs";
        const string RegistryUrl = "https://registry.npmjs.com";
        const string RegistryScope = "com.github.asus4";

        const string AutoSetupPref = "SaurabhFutureCity.OfflineTTS.AutoSetup";
        const string AddTestablesPref = "SaurabhFutureCity.OfflineTTS.AddTestables";
        const string SessionKey = "SaurabhFutureCity.OfflineTTS.SetupChecked";

        static string ManifestPath => Path.Combine(Directory.GetCurrentDirectory(), "Packages", "manifest.json");

        static TTSPackageInstaller()
        {
            if (Application.isBatchMode && Environment.GetCommandLineArgs().Contains("-futurecitySkipSetup")) return;
            EditorApplication.delayCall += () =>
            {
                if (!EditorPrefs.GetBool(AutoSetupPref, true)) return;
                // TextMeshPro fonts/shaders: checked after every reload (cheap), because TMP may have just been installed.
                EnsureTmpEssentials(interactive: false);
                if (SessionState.GetBool(SessionKey, false)) return;
                SessionState.SetBool(SessionKey, true);
                EnsureProjectSetup(interactive: false);
            };
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Setup/Repair Project Setup (registry, ONNX Runtime, testables)", priority = 900)]
        static void RepairMenu() => EnsureProjectSetup(interactive: true);

        [MenuItem("FutureCity/Plugins/OfflineTTS/Setup/Toggle Automatic Setup", priority = 901)]
        static void ToggleAuto()
        {
            bool now = !EditorPrefs.GetBool(AutoSetupPref, true);
            EditorPrefs.SetBool(AutoSetupPref, now);
            Debug.Log($"[OfflineTTS] Automatic project setup is now {(now ? "ON" : "OFF")}.");
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Setup/Toggle Automatic Setup", true)]
        static bool ToggleAutoValidate()
        {
            Menu.SetChecked("FutureCity/Plugins/OfflineTTS/Setup/Toggle Automatic Setup", EditorPrefs.GetBool(AutoSetupPref, true));
            return true;
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Setup/Toggle Add To Testables", priority = 902)]
        static void ToggleTestables()
        {
            bool now = !EditorPrefs.GetBool(AddTestablesPref, true);
            EditorPrefs.SetBool(AddTestablesPref, now);
            Debug.Log($"[OfflineTTS] Adding the package to 'testables' is now {(now ? "ON" : "OFF")}.");
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Setup/Toggle Add To Testables", true)]
        static bool ToggleTestablesValidate()
        {
            Menu.SetChecked("FutureCity/Plugins/OfflineTTS/Setup/Toggle Add To Testables", EditorPrefs.GetBool(AddTestablesPref, true));
            return true;
        }

        /// <summary>Makes sure the project manifest has everything this package needs. Returns true if it changed.</summary>
        public static bool EnsureProjectSetup(bool interactive)
        {
            try
            {
                if (!File.Exists(ManifestPath)) { Debug.LogError($"[OfflineTTS] {ManifestPath} not found."); return false; }

                var root = JObject.Parse(File.ReadAllText(ManifestPath));
                var added = new System.Collections.Generic.List<string>();

                // 1) Scoped registry (reuse any existing npm registry entry; just add our scope to it)
                var registries = root["scopedRegistries"] as JArray;
                if (registries == null) { registries = new JArray(); root["scopedRegistries"] = registries; }
                var npm = registries.OfType<JObject>().FirstOrDefault(r =>
                {
                    var url = (string)r["url"] ?? "";
                    return url.TrimEnd('/').Equals(RegistryUrl, StringComparison.OrdinalIgnoreCase) ||
                           url.TrimEnd('/').Equals("https://registry.npmjs.org", StringComparison.OrdinalIgnoreCase);
                });
                if (npm == null)
                {
                    registries.Add(new JObject
                    {
                        ["name"] = RegistryName,
                        ["url"] = RegistryUrl,
                        ["scopes"] = new JArray(RegistryScope),
                    });
                    added.Add($"scoped registry {RegistryUrl} ({RegistryScope})");
                }
                else
                {
                    var scopes = npm["scopes"] as JArray;
                    if (scopes == null) { scopes = new JArray(); npm["scopes"] = scopes; }
                    if (!scopes.Values<string>().Contains(RegistryScope))
                    {
                        scopes.Add(RegistryScope);
                        added.Add($"scope {RegistryScope} on existing registry {(string)npm["url"]}");
                    }
                }

                // 2) ONNX Runtime dependency
                var deps = root["dependencies"] as JObject;
                if (deps == null) { deps = new JObject(); root["dependencies"] = deps; }
                if (deps[OrtPackage] == null)
                {
                    deps[OrtPackage] = OrtVersion;
                    added.Add($"{OrtPackage} {OrtVersion}");
                }

                // 3) testables (so the package's tests show in the Test Runner)
                if (EditorPrefs.GetBool(AddTestablesPref, true))
                {
                    var testables = root["testables"] as JArray;
                    if (testables == null) { testables = new JArray(); root["testables"] = testables; }
                    if (!testables.Values<string>().Contains(PackageName))
                    {
                        testables.Add(PackageName);
                        added.Add($"testables: {PackageName}");
                    }
                }

                // 4) TextMeshPro: part of uGUI from Unity 2023.2 (pulled in by this package's com.unity.ugui dependency);
                //    older versions need the separate TextMeshPro package.
#if !UNITY_2023_2_OR_NEWER
                if (deps["com.unity.textmeshpro"] == null)
                {
                    deps["com.unity.textmeshpro"] = "3.0.6";
                    added.Add("com.unity.textmeshpro 3.0.6 (TextMeshPro, for word highlighting and subtitles)");
                }
#endif

                // 5) Upgrade from earlier package names (com.xrlp.offlinetts, then com.xrlab.offlinetts)
                foreach (var oldName in OldPackageNames)
                {
                    if (deps[oldName] != null)
                    {
                        deps.Remove(oldName);
                        added.Add($"removed old package {oldName} (replaced by {PackageName})");
                    }
                    if (root["testables"] is JArray oldTestables)
                    {
                        var stale = oldTestables.Where(t => (string)t == oldName).ToList();
                        foreach (var t in stale) oldTestables.Remove(t);
                        if (stale.Count > 0) added.Add($"removed {oldName} from testables");
                    }
                    string embeddedOld = Path.Combine(Directory.GetCurrentDirectory(), "Packages", oldName);
                    if (Directory.Exists(embeddedOld))
                        Debug.LogWarning($"[OfflineTTS] The old package folder Packages/{oldName} is still in this project. " +
                                         $"Close Unity and delete it: {PackageName} replaces it (both use the same script IDs).");
                }

                if (added.Count == 0)
                {
                    if (interactive)
                        EditorUtility.DisplayDialog("FutureCity Offline TTS", "Project setup is already complete.", "OK");
                    return false;
                }

                File.WriteAllText(ManifestPath, root.ToString(Formatting.Indented) + "\n");
                Debug.Log("[OfflineTTS] Project setup updated Packages/manifest.json:\n  + " + string.Join("\n  + ", added) +
                          "\nResolving packages… (Unity may recompile; the FutureCity ▸ Plugins ▸ OfflineTTS menu appears when it's done)");
                Client.Resolve();
                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"[OfflineTTS] Automatic setup failed: {e.Message}\n" +
                               "Add the scoped registry manually (see the package documentation) or run " +
                               "FutureCity ▸ Plugins ▸ OfflineTTS ▸ Setup ▸ Repair Project Setup.");
                return false;
            }
        }

        // ------------------------------------------------------------------ TextMeshPro essentials

        /// <summary>
        /// Imports "TMP Essential Resources" (default font, shaders, settings) if TextMeshPro is installed but they're
        /// missing. Without them TextMeshPro text is invisible, which would hide subtitles and word highlighting.
        /// Returns true if the resources are present (or were imported).
        /// </summary>
        public static bool EnsureTmpEssentials(bool interactive)
        {
            Type importer = null;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                importer = asm.GetType("TMPro.TMP_PackageResourceImporter");
                if (importer != null) break;
            }
            if (importer == null) return false;                                         // TextMeshPro not installed (yet)
            if (AssetDatabase.FindAssets("t:TMP_Settings").Length > 0) return true;     // essentials already imported

            var import = importer.GetMethod("ImportResources", new[] { typeof(bool), typeof(bool), typeof(bool) });
            if (import == null)
            {
                Debug.LogWarning("[OfflineTTS] Please import TextMeshPro essentials: Window ▸ TextMeshPro ▸ Import TMP Essential Resources.");
                return false;
            }
            Debug.Log("[OfflineTTS] Importing TextMeshPro Essential Resources (needed for subtitles and word highlighting)…");
            import.Invoke(null, new object[] { true, false, interactive });
            return true;
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Setup/Import TextMeshPro Essentials", priority = 903)]
        static void ImportTmpMenu()
        {
            if (!EnsureTmpEssentials(interactive: true))
                EditorUtility.DisplayDialog("FutureCity Offline TTS", "TextMeshPro isn't installed yet. Run Setup ▸ Repair Project Setup first.", "OK");
        }

        // ------------------------------------------------------------------ about / version

        [MenuItem("FutureCity/Plugins/OfflineTTS/About", priority = 1)]
        public static void ShowAbout()
        {
            var info = PackageInfo.FindForAssembly(typeof(TTSPackageInstaller).Assembly);
            string version = info != null ? info.version : "unknown";
            string source = info != null ? info.source.ToString() : "unknown";

            string ortVersion = "not installed";
            foreach (var p in PackageInfo.GetAllRegisteredPackages())
                if (p.name == OrtPackage) { ortVersion = p.version; break; }

            string models = Directory.Exists(Path.Combine(Application.streamingAssetsPath, "Supertonic", "onnx"))
                ? "found in StreamingAssets/Supertonic"
                : "not found in StreamingAssets/Supertonic (Download Supertonic 3 Models)";

            string message =
                $"FutureCity Offline TTS  {version}\n" +
                $"Installed from: {source}\n\n" +
                $"ONNX Runtime ({OrtPackage}): {ortVersion}\n" +
                $"Unity: {Application.unityVersion}\n" +
                $"Voice models: {models}\n\n" +
                "The documentation's 'Version and release history' section lists every release with upgrade notes.";

            int choice = EditorUtility.DisplayDialogComplex("About FutureCity Offline TTS", message,
                "Open documentation", "Close", "Open changelog");
            if (choice == 0) OpenDocumentation();
            else if (choice == 2) OpenChangelog();
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Changelog", priority = 2)]
        public static void OpenChangelog()
        {
            var info = PackageInfo.FindForAssembly(typeof(TTSPackageInstaller).Assembly);
            string file = info != null ? Path.Combine(info.resolvedPath, "CHANGELOG.md") : null;
            if (file != null && File.Exists(file))
                Application.OpenURL("file:///" + file.Replace('\\', '/'));
            else if (info != null && !string.IsNullOrEmpty(info.changelogUrl))
                Application.OpenURL(info.changelogUrl);
            else
                Debug.LogWarning("[OfflineTTS] Changelog not found.");
        }

        // ------------------------------------------------------------------ documentation (works offline)

        [MenuItem("FutureCity/Plugins/OfflineTTS/Documentation", priority = 0)]
        public static void OpenDocumentation()
        {
            var info = PackageInfo.FindForAssembly(typeof(TTSPackageInstaller).Assembly);
            string docsDir = info != null ? Path.Combine(info.resolvedPath, "Documentation~") : null;
            string html = docsDir != null ? Path.Combine(docsDir, "index.html") : null;

            if (html != null && File.Exists(html))
                Application.OpenURL("file:///" + html.Replace('\\', '/'));
            else if (info != null && !string.IsNullOrEmpty(info.documentationUrl))
                Application.OpenURL(info.documentationUrl);
            else
                Debug.LogWarning("[OfflineTTS] Documentation not found.");
        }
    }
}
