// FutureCity Offline TTS
// Narrates timed cues over a VideoPlayer (flat screens, 360° videos, in-headset training clips).
// All cues are generated before the video starts, so playback is instant and in sync.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Video;

namespace SaurabhFutureCity.OfflineTTS
{
    [Serializable]
    public class NarrationCue
    {
        [Tooltip("When to speak, in seconds from the start of the video (e.g. 12.5).\n" +
                 "Cues are sorted by time automatically.")]
        public double time;

        [Tooltip("What the narrator says at this time.")]
        [TextArea(2, 5)] public string text;

        [Tooltip("Optional voice just for this cue (e.g. a second narrator). (Use default) = the narrator's Voice.")]
        [TTSVoice(allowDefault: true)]
        public string voice;

        [Tooltip("Pause the video while this cue is spoken and resume when it ends.\n" +
                 "Good for explaining a freeze-frame; off = video keeps playing under the narration.")]
        public bool pauseVideoWhileSpeaking;

        [NonSerialized] public AudioClip clip;
        [NonSerialized] public bool fired;
    }

    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/TTS Video Narrator")]
    public class TTSVideoNarrator : MonoBehaviour
    {
        [Tooltip("The VideoPlayer to narrate over (flat screen, 360° sphere, any render mode).")]
        public VideoPlayer videoPlayer;

        [Tooltip("AudioSource the narration plays through. Created automatically if empty.\n" +
                 "2D (Spatial Blend 0) = narrator 'in your head'; 3D = voice comes from the screen's position.")]
        public AudioSource narrationSource;

        [Header("Voice")]
        [Tooltip("Narrator voice. Female 1–5 (F1–F5) or Male 1–5 (M1–M5). Individual cues can override it.")]
        [TTSVoice]
        public string voice = "M1";

        [Tooltip("Language the cue texts are written in.")]
        [TTSLanguage]
        public string language = "en";

        [Tooltip("Narration speaking rate (1.0 = natural). -1 = settings default.")]
        public float speed = -1f;

        [Tooltip("Fixed seed so the narration sounds the same every run (and is cached). -1 = random each run.")]
        public int seed = 7;

        [Header("Behaviour")]
        [Tooltip("Generate audio for ALL cues before the video starts, so every cue fires exactly on time.\n" +
                 "The VideoPlayer is stopped until preparation finishes (watch PrepareProgress / onReady for a loading UI).")]
        public bool prepareBeforePlay = true;

        [Tooltip("Start the video automatically once preparation is done. Off = call videoPlayer.Play() yourself.")]
        public bool playOnStart = true;

        [Tooltip("Volume of the video's own soundtrack while the narrator speaks (0 = mute, 1 = no change).\n" +
                 "Works when the VideoPlayer's Audio Output Mode is Direct.")]
        [Range(0f, 1f)] public float videoDuckVolume = 0.35f;

        [Tooltip("Timed narration lines. Seeking backwards re-arms cues; cues skipped by seeking far forward are not played.")]
        public List<NarrationCue> cues = new List<NarrationCue>();

        [Header("Events")]
        [Tooltip("Invoked when all cues have been generated and the video can start.")]
        public UnityEvent onReady = new UnityEvent();

        [Tooltip("Invoked with the cue index when a cue starts speaking (e.g. to show subtitles).")]
        public UnityEvent<int> onCueStarted = new UnityEvent<int>();

        public bool IsReady { get; private set; }
        public float PrepareProgress { get; private set; }

        double _lastTime;
        int _speakingCue = -1;
        bool _videoPausedByUs;
        bool _narrationPaused;
        float[] _originalVideoVolumes;

        async void Start()
        {
            if (narrationSource == null) narrationSource = gameObject.AddComponent<AudioSource>();
            narrationSource.playOnAwake = false;
            if (prepareBeforePlay && videoPlayer != null) { videoPlayer.playOnAwake = false; videoPlayer.Stop(); }

            try { await PrepareAsync(); }
            catch (Exception e) { Debug.LogError($"[TTSVideoNarrator] {e.Message}"); return; }

            if (playOnStart && videoPlayer != null) videoPlayer.Play();
        }

        /// <summary>Generates every cue up front. Safe to call again after editing cues.</summary>
        public async Task PrepareAsync()
        {
            IsReady = false;
            var tts = OfflineTTS.GetOrCreate();
            await tts.InitializeAsync();

            cues = cues.OrderBy(c => c.time).ToList();
            for (int i = 0; i < cues.Count; i++)
            {
                var c = cues[i];
                if (c.clip != null) Destroy(c.clip);
                var request = new TTSRequest
                {
                    voice = string.IsNullOrEmpty(c.voice) ? voice : c.voice,
                    language = language, speed = speed, seed = seed
                };
                c.clip = await tts.SynthesizeClipAsync(c.text, request, destroyCancellationToken);
                c.fired = false;
                PrepareProgress = (i + 1f) / cues.Count;
            }
            IsReady = true;
            onReady.Invoke();
        }

        void Update()
        {
            if (!IsReady || videoPlayer == null) return;

            // Speaking cue that paused the video: resume when narration ends.
            if (_speakingCue >= 0 && !_narrationPaused && !narrationSource.isPlaying)
            {
                _speakingCue = -1;
                RestoreVideoVolume();
                if (_videoPausedByUs) { _videoPausedByUs = false; videoPlayer.Play(); }
            }

            // Mirror pause/resume of the video onto the narration.
            if (!videoPlayer.isPlaying && !_videoPausedByUs)
            {
                if (narrationSource.isPlaying) { narrationSource.Pause(); _narrationPaused = true; }
                return;
            }
            if (_narrationPaused) { narrationSource.UnPause(); _narrationPaused = false; }

            double t = videoPlayer.time;

            // Seeking backwards (or looping) re-arms cues.
            if (t + 0.25 < _lastTime)
                foreach (var c in cues) if (c.time >= t) c.fired = false;
            _lastTime = t;

            for (int i = 0; i < cues.Count; i++)
            {
                var c = cues[i];
                if (c.fired || c.clip == null || t < c.time) continue;
                c.fired = true;
                // Skip cues we jumped far past (e.g. user scrubbed forward).
                if (t - c.time > Math.Max(1.0, c.clip.length)) continue;
                PlayCue(i);
                break;
            }
        }

        void PlayCue(int i)
        {
            var c = cues[i];
            narrationSource.Stop();
            _narrationPaused = false;
            narrationSource.clip = c.clip;
            narrationSource.Play();
            _speakingCue = i;
            DuckVideo();
            if (c.pauseVideoWhileSpeaking) { videoPlayer.Pause(); _videoPausedByUs = true; }
            onCueStarted.Invoke(i);
        }

        void DuckVideo()
        {
            if (videoPlayer.audioOutputMode != VideoAudioOutputMode.Direct) return;
            ushort n = videoPlayer.audioTrackCount;
            if (_originalVideoVolumes == null)
            {
                _originalVideoVolumes = new float[n];
                for (ushort k = 0; k < n; k++) _originalVideoVolumes[k] = videoPlayer.GetDirectAudioVolume(k);
            }
            for (ushort k = 0; k < n; k++) videoPlayer.SetDirectAudioVolume(k, _originalVideoVolumes[k] * videoDuckVolume);
        }

        void RestoreVideoVolume()
        {
            if (_originalVideoVolumes == null || videoPlayer.audioOutputMode != VideoAudioOutputMode.Direct) return;
            for (ushort k = 0; k < _originalVideoVolumes.Length; k++) videoPlayer.SetDirectAudioVolume(k, _originalVideoVolumes[k]);
        }

        void OnDestroy()
        {
            foreach (var c in cues) if (c.clip != null) Destroy(c.clip);
        }
    }
}
