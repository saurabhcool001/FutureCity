// FutureCity Offline TTS — subtitles for whatever is being spoken.
//
// Put it on a TextMeshPro text (screen-space UI, world-space panel, or 3D text). Whenever a TTS Speaker starts a
// line (live TTS, or a baked / recorded clip with word timings that it follows), this text shows that line and the
// current word is highlighted. Optionally limited to specific speakers, and hidden when nobody is talking.

using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS
{
    [RequireComponent(typeof(TMP_Text))]
    [DisallowMultipleComponent]
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/TTS Subtitle Display")]
    public class TTSSubtitleDisplay : MonoBehaviour
    {
        [Tooltip("Only show lines from these speakers. Empty = every TTS Speaker in the scene.")]
        [SerializeField] private List<TTSSpeaker> speakers = new List<TTSSpeaker>();

        [Tooltip("Show the speaker's GameObject name before the line (e.g. \"Site Manager: …\").")]
        [SerializeField] private bool showSpeakerName = false;

        [Tooltip("Clear the subtitle when the line ends.")]
        [SerializeField] private bool hideWhenSilent = true;

        [Tooltip("Seconds to keep the finished line on screen before clearing it.")]
        [Range(0f, 5f)]
        [SerializeField] private float hideDelay = 1.0f;

        [Tooltip("Text shown when nobody is speaking (e.g. \"Subtitles\"). Empty = nothing.")]
        [SerializeField] private string idleText = "";

        [Tooltip("Optional object shown only while a subtitle is visible (e.g. the subtitle's background panel).")]
        [SerializeField] private GameObject showWhileSpeaking;

        TMP_Text _text;
        TTSWordHighlighter _highlighter;
        TTSSpeaker _current;
        float _hideAt = -1f;

        /// <summary>The speaker whose line is shown now (null when idle).</summary>
        public TTSSpeaker CurrentSpeaker => _current;

        void Awake()
        {
            _text = GetComponent<TMP_Text>();
            _highlighter = GetComponent<TTSWordHighlighter>();
            if (_highlighter == null)
            {
                _highlighter = gameObject.AddComponent<TTSWordHighlighter>();
                _highlighter.listenTo = TTSWordHighlighter.ListenMode.BoundFromCode;
            }
        }

        void OnEnable()
        {
            TTSSpeaker.AnyLineStarted += OnLineStarted;
            TTSSpeaker.AnyLineEnded += OnLineEnded;
            ShowIdle();
        }

        void OnDisable()
        {
            TTSSpeaker.AnyLineStarted -= OnLineStarted;
            TTSSpeaker.AnyLineEnded -= OnLineEnded;
        }

        void OnLineStarted(TTSSpeaker speaker, string spokenText)
        {
            if (speaker == null || (speakers.Count > 0 && !speakers.Contains(speaker))) return;

            _current = speaker;
            _hideAt = -1f;
            _text.text = showSpeakerName ? $"{speaker.name}: {spokenText}" : spokenText;
            _text.ForceMeshUpdate();             // once per line, so the highlighter maps the new words right away
            _highlighter.Bind(speaker);
            if (showWhileSpeaking != null) showWhileSpeaking.SetActive(true);
        }

        void OnLineEnded(TTSSpeaker speaker)
        {
            if (speaker != _current || !hideWhenSilent) return;
            _hideAt = Time.unscaledTime + hideDelay;
        }

        void Update()
        {
            if (_hideAt < 0f || Time.unscaledTime < _hideAt) return;
            _hideAt = -1f;
            if (_current != null && _current.IsSpeaking) return;   // a new line from the same speaker already started
            _current = null;
            ShowIdle();
        }

        void ShowIdle()
        {
            if (_text == null) _text = GetComponent<TMP_Text>();
            _text.text = idleText ?? "";
            if (showWhileSpeaking != null) showWhileSpeaking.SetActive(!string.IsNullOrEmpty(idleText));
        }
    }
}
