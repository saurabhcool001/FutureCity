// FutureCity Offline TTS — automatic word highlighting for any project.
//
// Add ONE "TTS Auto Highlight" to the scene (or to a parent, to limit it to that part of the hierarchy).
// From then on, whenever an AudioSource plays a clip that has word timings (a TTS-baked WAV or a recording run
// through the Word Timing Generator), or a TTS Speaker speaks live:
//   1. a listen-only TTS Speaker is added to that AudioSource if it has none (it keeps the AudioSource's settings);
//   2. the TextMeshPro text showing that line is found (best word match) and gets a TTS Word Highlighter,
//      bound to that speaker.
// Nothing needs to change in your own scripts: play clips and set texts as you already do.
// Everything it adds can also be added by hand (see the documentation, "Highlighting without the auto component").

using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS
{
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/TTS Auto Highlight")]
    [DisallowMultipleComponent]
    public class TTSAutoHighlight : MonoBehaviour
    {
        public enum SearchScope
        {
            /// <summary>Every AudioSource and text in the loaded scenes.</summary>
            WholeScene,
            /// <summary>Only AudioSources and texts under this GameObject.</summary>
            ChildrenOfThisObject,
        }

        [Header("Where to look")]
        [Tooltip("• Whole Scene: watch every AudioSource and text in the loaded scenes (simplest: one per scene).\n" +
                 "• Children Of This Object: only inside this GameObject's hierarchy (e.g. one module or one UI root).")]
        [SerializeField] private SearchScope scope = SearchScope.WholeScene;

        [Tooltip("How often (seconds) to check for AudioSources that started a timed clip. 0.1 is quick and cheap.")]
        [Range(0.02f, 1f)]
        [SerializeField] private float scanInterval = 0.1f;

        [Tooltip("AudioSources to never touch (e.g. music, ambience, UI clicks).")]
        [SerializeField] private List<AudioSource> ignoreSources = new List<AudioSource>();

        [Header("Speakers")]
        [Tooltip("Add a listen-only TTS Speaker to any AudioSource that plays a clip with word timings and has none. " +
                 "It keeps the AudioSource's 3D settings (Configure Spatial Audio off) and only follows the clip.")]
        [SerializeField] private bool addSpeakersAutomatically = true;

        [Tooltip("Voice set on speakers this component adds (only used if something later asks them to speak live).")]
        [TTSVoice] [SerializeField] private string defaultVoice = "M1";

        [Header("Texts")]
        [Tooltip("Find the TextMeshPro text that shows the line being spoken (the best word match) and highlight it. " +
                 "Adds a TTS Word Highlighter if the text has none.")]
        [SerializeField] private bool findTextsAutomatically = true;

        [Tooltip("Optional: texts to prefer. If one of these matches the line, it's used even if another text matches better. " +
                 "Leave empty to search all texts in the scope.")]
        [SerializeField] private List<TMP_Text> preferredTexts = new List<TMP_Text>();

        [Tooltip("How much of the spoken line (0–1) must appear in a text for it to count as 'the text of this line'. " +
                 "Lower it if your on-screen text often differs from the spoken words.")]
        [Range(0.1f, 1f)]
        [SerializeField] private float minimumMatch = 0.5f;

        [Tooltip("Also highlight lines spoken by live TTS (not only baked / recorded clips).")]
        [SerializeField] private bool includeLiveTTS = true;

        [Tooltip("Ignore texts that are hidden (inactive or disabled).")]
        [SerializeField] private bool onlyVisibleTexts = true;

        [Header("Debug")]
        [Tooltip("Log what this component does (speaker added, which text was matched and how well). " +
                 "Turn on when highlighting doesn't appear, to see which step is missing.")]
        [SerializeField] private bool debugLog = false;

        float _nextScan, _nextSourceRefresh;
        readonly HashSet<AudioSource> _ignored = new HashSet<AudioSource>();
        readonly List<AudioSource> _sources = new List<AudioSource>();
        // Last clip checked per AudioSource: each clip is looked up once, not on every scan
        // (music / ambience without timings would otherwise be checked ~10 times a second).
        readonly Dictionary<AudioSource, AudioClip> _checked = new Dictionary<AudioSource, AudioClip>();

        void OnEnable()
        {
            TTSSpeaker.AnyLineStarted += OnLineStarted;
            _ignored.Clear();
            foreach (var s in ignoreSources) if (s != null) _ignored.Add(s);
        }

        void OnDisable() => TTSSpeaker.AnyLineStarted -= OnLineStarted;

        // ------------------------------------------------------------------ step 1: speakers

        void Update()
        {
            if (!addSpeakersAutomatically || Time.unscaledTime < _nextScan) return;
            _nextScan = Time.unscaledTime + scanInterval;

            // The list of AudioSources is refreshed once a second (finding objects is the expensive part).
            if (Time.unscaledTime >= _nextSourceRefresh)
            {
                _nextSourceRefresh = Time.unscaledTime + 1f;
                _sources.Clear();
                _sources.AddRange(Sources());
                _checked.Clear();
            }

            foreach (var source in _sources)
            {
                if (source == null || !source.isPlaying || source.clip == null || _ignored.Contains(source)) continue;
                if (_checked.TryGetValue(source, out var last) && last == source.clip) continue;   // already handled
                _checked[source] = source.clip;
                if (source.GetComponent<TTSSpeaker>() != null) continue;
                if (!TTSClipTimings.TryGet(source.clip, out _)) continue;   // only clips with word timings

                var speaker = TTSSpeaker.AddTo(source.gameObject, defaultVoice, configureSpatialAudio: false);
                speaker.followExternalClips = true;
                Log($"Added a listen-only TTS Speaker to '{Path(source.transform)}' (playing '{source.clip.name}').");
            }
        }

        IEnumerable<AudioSource> Sources()
        {
            if (scope == SearchScope.ChildrenOfThisObject) return GetComponentsInChildren<AudioSource>(false);
#if UNITY_2023_1_OR_NEWER
            return FindObjectsByType<AudioSource>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
#else
            return FindObjectsOfType<AudioSource>();
#endif
        }

        // ------------------------------------------------------------------ step 2: texts

        void OnLineStarted(TTSSpeaker speaker, string spokenText)
        {
            if (!findTextsAutomatically || speaker == null) return;
            if (!includeLiveTTS && !speaker.IsFollowingExternalClip) return;
            if (scope == SearchScope.ChildrenOfThisObject && !speaker.transform.IsChildOf(transform)
                && !InScopeText(spokenText)) return;

            TMP_Text best = null;
            float bestScore = 0f;

            foreach (var t in preferredTexts)
            {
                float score = Score(t, spokenText);
                if (score >= minimumMatch && score > bestScore) { best = t; bestScore = score; }
            }
            if (best == null)
            {
                foreach (var t in Texts())
                {
                    float score = Score(t, spokenText);
                    if (score > bestScore) { best = t; bestScore = score; }
                }
                if (bestScore < minimumMatch) best = null;
            }

            if (best == null)
            {
                Log($"No text matched the line \"{Short(spokenText)}\" (best match {bestScore:P0}, needs {minimumMatch:P0}).");
                return;
            }

            var highlighter = best.GetComponent<TTSWordHighlighter>();
            if (highlighter == null)
            {
                highlighter = best.gameObject.AddComponent<TTSWordHighlighter>();
                highlighter.listenTo = TTSWordHighlighter.ListenMode.AnySpeakerWithMatchingText;
                highlighter.minimumMatch = minimumMatch;
                Log($"Added a TTS Word Highlighter to '{Path(best.transform)}'.");
            }
            highlighter.Bind(speaker);
            Log($"'{Path(best.transform)}' follows '{speaker.name}' ({bestScore:P0} word match).");
        }

        bool InScopeText(string spokenText)
        {
            foreach (var t in Texts()) if (Score(t, spokenText) >= minimumMatch) return true;
            return false;
        }

        IEnumerable<TMP_Text> Texts()
        {
            if (scope == SearchScope.ChildrenOfThisObject) return GetComponentsInChildren<TMP_Text>(!onlyVisibleTexts);
#if UNITY_2023_1_OR_NEWER
            return FindObjectsByType<TMP_Text>(onlyVisibleTexts ? FindObjectsInactive.Exclude : FindObjectsInactive.Include, FindObjectsSortMode.None);
#else
            return FindObjectsOfType<TMP_Text>(!onlyVisibleTexts);
#endif
        }

        float Score(TMP_Text t, string spokenText)
        {
            if (t == null || (onlyVisibleTexts && !t.isActiveAndEnabled)) return 0f;
            return TTSText.MatchRatio(spokenText, t.text);
        }

        // ------------------------------------------------------------------ helpers

        void Log(string message)
        {
            if (debugLog) Debug.Log("[TTS Auto Highlight] " + message, this);
        }

        static string Path(Transform t)
        {
            string p = t.name;
            for (var c = t.parent; c != null; c = c.parent) p = c.name + "/" + p;
            return p;
        }

        static string Short(string s) => s == null ? "" : (s.Length > 50 ? s.Substring(0, 50) + "…" : s);
    }
}
