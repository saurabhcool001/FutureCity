// FutureCity Offline TTS — Play-mode test panel (PC / Editor).
// Drop on any GameObject, press Play, and use the on-screen panel. F1 toggles the panel.
// Uses IMGUI, so it needs no Canvas/EventSystem/XR rig and works with mouse + keyboard in the Game view.

using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace SaurabhFutureCity.OfflineTTS
{
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/TTS Test Bench")]
    public class TTSTestBench : MonoBehaviour
    {
        [Tooltip("Speaker used by the panel's Speak button. A test speaker is created in front of the camera if empty.")]
        public TTSSpeaker speaker;

        [Tooltip("Show the on-screen test panel in the Game view (PC / Editor testing only).")]
        public bool showPanel = true;

        [Tooltip("Key that shows/hides the panel. Works only when the legacy Input Manager is enabled " +
                 "(Project Settings ▸ Player ▸ Active Input Handling = Both or Input Manager).")]
        public KeyCode toggleKey = KeyCode.F1;

        [Tooltip("Text in the panel's text box when Play mode starts.")]
        [TextArea(3, 6)]
        public string text = "Welcome to the manual handling module. Before lifting, check the weight of the load, " +
                             "plan your route, and keep the load close to your waist.";

        [Header("Quick lines")]
        [Tooltip("One-click test sentences shown as buttons on the panel.")]
        public string[] quickLines =
        {
            "Hello! This is a fully offline voice running inside Unity.",
            "Warning. You are entering a hazardous area. Please wear your hard hat.",
            "Correct! Well done. Let's move on to the next question.",
            "That's not quite right. Remember to bend your knees and keep your back straight.",
        };

        string _voice = "F1";
        int _langIndex;
        float _speed = 1.05f;
        int _steps = 8;
        string _seedText = "42";
        bool _stream = true;
        bool _useCache = false;

        string _status = "Waiting for model…";
        readonly StringBuilder _log = new StringBuilder();
        Vector2 _logScroll, _textScroll;
        Rect _window = new Rect(20, 20, 470, 640);
        bool _busy;
        float[] _lastSamples;
        Stopwatch _speakTimer;

        OfflineTTS _tts;

        async void Start()
        {
            _langIndex = Math.Max(0, Array.IndexOf(TTSLanguages.All, "en"));
            _tts = OfflineTTS.GetOrCreate();

            if (speaker == null)
            {
                var go = new GameObject("TTS Test Speaker");
                go.transform.position = Camera.main != null
                    ? Camera.main.transform.position + Camera.main.transform.forward * 2f
                    : new Vector3(0, 1.6f, 2f);
                go.AddComponent<AudioSource>();
                speaker = go.AddComponent<TTSSpeaker>();
            }
            speaker.onSpeechStarted.AddListener(_ =>
            {
                if (_speakTimer == null) return;
                Log($"Speak: first audio after {_speakTimer.ElapsedMilliseconds} ms");
            });
            speaker.onSpeechFinished.AddListener(_ =>
            {
                if (_speakTimer == null) return;
                Log($"Speak: finished after {_speakTimer.Elapsed.TotalSeconds:0.00} s total");
                _speakTimer = null;
            });

            var sw = Stopwatch.StartNew();
            try
            {
                await _tts.InitializeAsync();
                _status = "Ready";
                Log($"Model loaded in {sw.Elapsed.TotalSeconds:0.00} s · {_tts.SampleRate} Hz · {Application.platform}");
                if (Application.isEditor && !Application.isMobilePlatform && _tts.Settings != null)
                    _steps = _tts.Settings.steps;
            }
            catch (Exception e)
            {
                _status = "Load failed — see Console";
                Log("ERROR: " + e.Message);
                Log("Tip: FutureCity ▸ Plugins ▸ OfflineTTS ▸ Download Supertonic 3 Models");
            }
        }

        void Update()
        {
#if ENABLE_LEGACY_INPUT_MANAGER
            // Projects using only the new Input System: toggle 'showPanel' in the Inspector instead.
            if (Input.GetKeyDown(toggleKey)) showPanel = !showPanel;
#endif
        }

        TTSRequest BuildRequest() => new TTSRequest
        {
            voice = _voice,
            language = TTSLanguages.All[_langIndex],
            speed = _speed,
            steps = _steps,
            seed = int.TryParse(_seedText, out var s) ? s : -1,
            useCache = _useCache,
        };

        // ------------------------------------------------------------------ actions

        void Speak(string line)
        {
            if (!_tts.IsReady) return;
            var r = BuildRequest();
            speaker.voice = r.voice;
            speaker.language = r.language;
            speaker.speed = r.speed;
            speaker.steps = r.steps;
            speaker.seed = r.seed;
            speaker.streamSentences = _stream;
            _speakTimer = Stopwatch.StartNew();
            Log($"Speak [{r.voice}/{r.language}, steps {r.steps}, {(_stream ? "streaming" : "full line")}]: \"{Short(line)}\"");
            speaker.Speak(line);
        }

        async Task GenerateTimed()
        {
            if (!_tts.IsReady || _busy) return;
            _busy = true;
            _status = "Generating…";
            try
            {
                var r = BuildRequest();
                var sw = Stopwatch.StartNew();
                _lastSamples = await _tts.SynthesizeSamplesAsync(text, r);
                double gen = sw.Elapsed.TotalSeconds;
                double audio = _lastSamples.Length / (double)_tts.SampleRate;
                Log($"Generated {audio:0.00} s of audio in {gen:0.00} s · RTF {gen / Math.Max(audio, 1e-6):0.000} " +
                    $"({audio / Math.Max(gen, 1e-6):0.0}x real-time) · steps {r.steps}");

                var src = speaker.Source;
                speaker.Stop();
                src.clip = _tts.ToClip(_lastSamples, "TestBench");
                src.Play();
                _status = "Ready";
            }
            catch (Exception e) { _status = "Error"; Log("ERROR: " + e.Message); }
            finally { _busy = false; }
        }

        void SaveWav()
        {
            if (_lastSamples == null || _lastSamples.Length == 0) { Log("Nothing to save — press 'Generate (timed)' first."); return; }
            string dir = Path.Combine(Application.persistentDataPath, "TTSTests");
            string path = Path.Combine(dir, $"tts_{_voice}_{DateTime.Now:yyyyMMdd_HHmmss}.wav");
            WavUtility.Save(path, _lastSamples, _tts.SampleRate);
            Log("Saved " + path);
            GUIUtility.systemCopyBuffer = path;
        }

        async Task Benchmark()
        {
            if (!_tts.IsReady || _busy) return;
            _busy = true;
            _status = "Benchmarking…";
            string[] sentences =
            {
                "Stop.",
                "Please put on your safety glasses before entering the workshop.",
                "When lifting a heavy object, stand close to the load, bend your knees, keep your back straight, " +
                "and lift smoothly using the strength of your legs rather than your back.",
            };
            int[] stepOptions = { 8, 5, 3 };
            Log("── Benchmark (no cache) ──");
            try
            {
                foreach (var steps in stepOptions)
                foreach (var sentence in sentences)
                {
                    var r = BuildRequest();
                    r.steps = steps; r.useCache = false; r.seed = 1;
                    var sw = Stopwatch.StartNew();
                    var samples = await _tts.SynthesizeSamplesAsync(sentence, r);
                    double gen = sw.Elapsed.TotalSeconds;
                    double audio = samples.Length / (double)_tts.SampleRate;
                    Log($"steps {steps} · {sentence.Length,3} chars · {audio:0.00}s audio · {gen * 1000:0} ms · {audio / Math.Max(gen, 1e-6):0.0}x RT");
                }
                Log("── done ──");
                _status = "Ready";
            }
            catch (Exception e) { _status = "Error"; Log("ERROR: " + e.Message); }
            finally { _busy = false; }
        }

        // ------------------------------------------------------------------ UI

        void OnGUI()
        {
            if (!showPanel) return;
            _window = GUILayout.Window(GetInstanceID(), _window, DrawWindow, "FutureCity Offline TTS — Test Bench (F1)");
        }

        void DrawWindow(int id)
        {
            bool ready = _tts != null && _tts.IsReady;
            GUILayout.Label($"Status: {_status}" + (!ready && _tts != null ? $"  ({_tts.LoadProgress:P0})" : ""));

            GUILayout.Label("Text");
            _textScroll = GUILayout.BeginScrollView(_textScroll, GUILayout.Height(80));
            text = GUILayout.TextArea(text, GUILayout.ExpandHeight(true));
            GUILayout.EndScrollView();

            GUILayout.Label("Voice");
            int vi = Math.Max(0, Array.IndexOf(ModelLocator.BuiltInVoices, _voice));
            vi = GUILayout.SelectionGrid(vi, ModelLocator.BuiltInVoices, 5);
            _voice = ModelLocator.BuiltInVoices[vi];

            GUILayout.BeginHorizontal();
            GUILayout.Label("Language", GUILayout.Width(70));
            if (GUILayout.Button("◀", GUILayout.Width(28))) _langIndex = (_langIndex + TTSLanguages.All.Length - 1) % TTSLanguages.All.Length;
            GUILayout.Label(TTSLanguages.All[_langIndex], GUILayout.Width(30));
            if (GUILayout.Button("▶", GUILayout.Width(28))) _langIndex = (_langIndex + 1) % TTSLanguages.All.Length;
            GUILayout.Space(20);
            GUILayout.Label("Seed", GUILayout.Width(36));
            _seedText = GUILayout.TextField(_seedText, GUILayout.Width(60));
            GUILayout.Label("(-1 = random)");
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label($"Speed {_speed:0.00}", GUILayout.Width(90));
            _speed = GUILayout.HorizontalSlider(_speed, 0.5f, 2f);
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label($"Steps {_steps}", GUILayout.Width(90));
            _steps = Mathf.RoundToInt(GUILayout.HorizontalSlider(_steps, 1, 16));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            _stream = GUILayout.Toggle(_stream, " Stream sentences");
            _useCache = GUILayout.Toggle(_useCache, " Use cache");
            GUILayout.EndHorizontal();

            GUI.enabled = ready;
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("▶ Speak", GUILayout.Height(30))) Speak(text);
            if (GUILayout.Button("■ Stop", GUILayout.Height(30))) { speaker.Stop(); }
            GUILayout.EndHorizontal();

            GUI.enabled = ready && !_busy;
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Generate (timed)")) _ = GenerateTimed();
            if (GUILayout.Button("Save last WAV")) SaveWav();
            if (GUILayout.Button("Benchmark")) _ = Benchmark();
            GUILayout.EndHorizontal();

            GUI.enabled = ready;
            GUILayout.Label("Quick lines");
            foreach (var l in quickLines)
                if (GUILayout.Button(Short(l, 60))) Speak(l);

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Clear cache")) { _tts.ClearCache(includeDisk: true); Log("Cache cleared."); }
            if (GUILayout.Button("Open output folder"))
            {
                string dir = Path.Combine(Application.persistentDataPath, "TTSTests");
                Directory.CreateDirectory(dir);
                Application.OpenURL("file://" + dir);
            }
            GUILayout.EndHorizontal();
            GUI.enabled = true;

            GUILayout.Label("Log");
            _logScroll = GUILayout.BeginScrollView(_logScroll, GUILayout.ExpandHeight(true));
            GUILayout.Label(_log.ToString());
            GUILayout.EndScrollView();

            GUI.DragWindow();
        }

        void Log(string message)
        {
            _log.AppendLine($"[{DateTime.Now:HH:mm:ss}] {message}");
            _logScroll.y = float.MaxValue;
            Debug.Log("[TTSTestBench] " + message);
        }

        static string Short(string s, int max = 40) => s.Length > max ? s.Substring(0, max) + "…" : s;
    }
}
