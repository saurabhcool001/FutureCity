// FutureCity Offline TTS — make any XRI interactable speak.
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace SaurabhFutureCity.OfflineTTS.XR
{
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/XR/Talk On Interact")]
    public class TTSXRTalkOnInteract : MonoBehaviour
    {
        public enum TriggerMode
        {
            /// <summary>Grip / select (also poke or ray select).</summary>
            Select,
            /// <summary>Trigger while the object is held.</summary>
            Activate,
            /// <summary>Hand or ray starts hovering.</summary>
            HoverEnter,
        }

        [Tooltip("The XRI interactable that triggers speech (XR Simple Interactable, XR Grab Interactable, …). " +
                 "Auto-filled from this GameObject.")]
        public XRBaseInteractable interactable;

        [Tooltip("The TTS Speaker that says the lines (usually on the same character). Auto-filled from this GameObject.")]
        public TTSSpeaker speaker;

        [Tooltip("What makes the character talk:\n" +
                 "• Select: grip button on it, ray select, or poke (for characters / buttons).\n" +
                 "• Activate: trigger button while the object is held (for grabbable items like a radio).\n" +
                 "• Hover Enter: as soon as a hand or ray points at it (good for hints; can be chatty).")]
        public TriggerMode trigger = TriggerMode.Select;

        [Tooltip("ON: say the lines in order, looping back to the first.\nOFF: pick a random line each time.")]
        public bool cycle = true;

        [Tooltip("Lines this object can say. Each interaction says the next (or a random) line.")]
        [TextArea(2, 4)]
        public string[] lines =
        {
            "Hello! I'm a test character. My voice is generated on this device, with no internet connection.",
        };

        int _index;

        void Reset()
        {
            interactable = GetComponent<XRBaseInteractable>();
            speaker = GetComponent<TTSSpeaker>();
        }

        void OnEnable()
        {
            if (interactable == null) interactable = GetComponent<XRBaseInteractable>();
            if (speaker == null) speaker = GetComponent<TTSSpeaker>();
            if (interactable == null) { Debug.LogWarning($"[TTSXRTalkOnInteract] No interactable on {name}"); return; }

            interactable.selectEntered.AddListener(OnSelect);
            interactable.activated.AddListener(OnActivate);
            interactable.hoverEntered.AddListener(OnHover);
        }

        void OnDisable()
        {
            if (interactable == null) return;
            interactable.selectEntered.RemoveListener(OnSelect);
            interactable.activated.RemoveListener(OnActivate);
            interactable.hoverEntered.RemoveListener(OnHover);
        }

        void OnSelect(SelectEnterEventArgs _) { if (trigger == TriggerMode.Select) SpeakNext(); }
        void OnActivate(ActivateEventArgs _) { if (trigger == TriggerMode.Activate) SpeakNext(); }
        void OnHover(HoverEnterEventArgs _) { if (trigger == TriggerMode.HoverEnter) SpeakNext(); }

        public void SpeakNext()
        {
            if (speaker == null || lines == null || lines.Length == 0) return;
            int i = cycle ? _index++ % lines.Length : Random.Range(0, lines.Length);
            speaker.Speak(lines[i]);
        }
    }
}
