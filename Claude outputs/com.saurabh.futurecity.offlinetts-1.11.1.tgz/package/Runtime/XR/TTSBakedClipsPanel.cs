// FutureCity Offline TTS — Playground: baked / recorded clips panel (world space, XR Interaction Toolkit 3.x).
//
// Lists AudioClips (e.g. everything baked with the Voice-over Baker) with PLAY buttons. Pressing one plays the clip on
// the target AudioSource exactly like an NPC voice script would (AudioSource.clip + Play), so you can check that the
// TTS Speaker on that AudioSource follows it and the subtitle highlights the words. Status is shown on the panel itself
// (works on the headset without logcat).

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit.UI;

namespace SaurabhFutureCity.OfflineTTS.XR
{
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/XR/Baked Clips Panel (Playground)")]
    public class TTSBakedClipsPanel : MonoBehaviour
    {
        [Tooltip("Clips to test (e.g. your baked WAVs). The playground scene fills this from the timing library; " +
                 "drag in more clips any time.")]
        public List<AudioClip> clips = new List<AudioClip>();

        [Tooltip("AudioSource the clips are played on, like an NPC voice script would (e.g. the NPC's NpcAudio object). " +
                 "It needs a TTS Speaker with Follow External Clips on for highlighting.")]
        public AudioSource playOn;

        [Tooltip("Clip buttons per page.")]
        [Range(3, 12)] public int clipsPerPage = 8;

        [Tooltip("Panel width in metres.")] public float width = 0.9f;
        [Tooltip("Panel height in metres.")] public float height = 1.1f;

        const float PixelsPerMetre = 1000f;
        Font _font;
        Text _status, _pageLabel, _log;
        readonly List<(Button button, Text label)> _rows = new List<(Button, Text)>();
        readonly Queue<string> _logLines = new Queue<string>();
        int _page;
        AudioClip _pending;          // clip just played, waiting to see if a speaker follows it
        float _pendingSince;

        void Start()
        {
            _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            clips.RemoveAll(c => c == null);
            BuildUI();
            EnsureEventSystem();
            TTSSpeaker.AnyLineStarted += OnLineStarted;
            TTSSpeaker.AnyLineEnded += OnLineEnded;
            RefreshPage();
            RefreshStatus();
            Log(playOn == null ? "No 'Play On' AudioSource set!" : $"Clips play on '{playOn.name}'.");
        }

        void OnDestroy()
        {
            TTSSpeaker.AnyLineStarted -= OnLineStarted;
            TTSSpeaker.AnyLineEnded -= OnLineEnded;
        }

        void Update()
        {
            // A clip with timings that no speaker followed within a moment → explain why on the panel.
            if (_pending != null && Time.unscaledTime - _pendingSince > 0.6f)
            {
                var speaker = playOn != null ? playOn.GetComponent<TTSSpeaker>() : null;
                bool hasTimings = TTSClipTimings.TryGet(_pending, out _);
                string why = !hasTimings ? "no word timings for this clip (bake with 'Save word timings')"
                           : speaker == null ? "no TTS Speaker on the Play On AudioSource"
                           : !speaker.followExternalClips ? "the TTS Speaker's Follow External Clips is off"
                           : "the speaker didn't pick it up";
                Log($"NOT HIGHLIGHTED  {_pending.name}: {why}.");
                _pending = null;
            }
        }

        // ------------------------------------------------------------------ actions

        void Play(AudioClip clip)
        {
            if (playOn == null || clip == null) { Log("Set 'Play On' to an AudioSource."); return; }
            playOn.Stop();
            playOn.clip = clip;
            playOn.Play();                       // same as an NPC voice script → the TTS Speaker should follow it
            _pending = clip;
            _pendingSince = Time.unscaledTime;
            Log($"Playing {clip.name}");
        }

        void OnLineStarted(TTSSpeaker speaker, string text)
        {
            if (speaker == null) return;
            if (speaker.IsFollowingExternalClip && _pending != null && playOn != null && speaker.Source == playOn)
            {
                Log($"OK  {_pending.name}: followed by '{speaker.name}', highlighting {speaker.CurrentLineWords.Count} words.");
                _pending = null;
            }
            else if (!speaker.IsFollowingExternalClip)
            {
                Log($"Live TTS on '{speaker.name}': \"{Short(text, 40)}\"");
            }
        }

        void OnLineEnded(TTSSpeaker speaker) { }

        void RefreshStatus()
        {
            var settings = TTSOverride.GlobalSettings;
            int known = TTSClipTimings.KnownClipCount;
            int withTimings = 0;
            foreach (var c in clips) if (TTSClipTimings.TryGet(c, out _)) withTimings++;
            _status.text = $"Settings: {(settings != null ? settings.name : "none")}   ·   timing libraries: {TTSClipTimings.LibraryCount}   ·   " +
                           $"timings known: {known}\nClips in this list with timings: {withTimings} / {clips.Count}";
            RefreshPage();
        }

        void RefreshPage()
        {
            int pages = Mathf.Max(1, Mathf.CeilToInt(clips.Count / (float)clipsPerPage));
            _page = Mathf.Clamp(_page, 0, pages - 1);
            _pageLabel.text = clips.Count == 0 ? "No clips: drag baked clips into 'Clips'" : $"Page {_page + 1} / {pages}   ({clips.Count} clips)";
            for (int i = 0; i < _rows.Count; i++)
            {
                int index = _page * clipsPerPage + i;
                var (button, label) = _rows[i];
                bool visible = index < clips.Count;
                button.gameObject.SetActive(visible);
                if (!visible) continue;
                var clip = clips[index];
                bool timed = TTSClipTimings.TryGet(clip, out var timing);
                label.text = timed ? $"PLAY   {clip.name}      [timings: {timing.words.Length} words]" : $"PLAY   {clip.name}      [NO TIMINGS]";
                label.color = timed ? Color.white : new Color(1f, 0.6f, 0.55f);
                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(() => Play(clip));
            }
        }

        void Log(string message)
        {
            Debug.Log("[TTS Playground] " + message, this);
            _logLines.Enqueue(message);
            while (_logLines.Count > 6) _logLines.Dequeue();
            if (_log != null) _log.text = string.Join("\n", _logLines);
        }

        static string Short(string s, int max) => string.IsNullOrEmpty(s) ? "" : (s.Length > max ? s.Substring(0, max) + "…" : s);

        // ------------------------------------------------------------------ UI

        void BuildUI()
        {
            var canvasGo = new GameObject("Baked Clips Canvas", typeof(RectTransform));
            canvasGo.transform.SetParent(transform, false);
            var canvas = canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = Camera.main;
            canvasGo.AddComponent<CanvasScaler>().dynamicPixelsPerUnit = 2f;
            canvasGo.AddComponent<TrackedDeviceGraphicRaycaster>();
            var rt = (RectTransform)canvasGo.transform;
            rt.sizeDelta = new Vector2(width * PixelsPerMetre, height * PixelsPerMetre);
            rt.localScale = Vector3.one / PixelsPerMetre;
            canvasGo.AddComponent<Image>().color = new Color(0.08f, 0.09f, 0.12f, 0.94f);

            var col = canvasGo.AddComponent<VerticalLayoutGroup>();
            col.padding = new RectOffset(24, 24, 20, 20);
            col.spacing = 8;
            col.childControlWidth = col.childControlHeight = true;
            col.childForceExpandWidth = true;
            col.childForceExpandHeight = false;

            Label(rt, "Baked clips", 34, FontStyle.Bold, 44, Color.white);
            _status = Label(rt, "", 18, FontStyle.Normal, 50, new Color(0.55f, 0.85f, 1f));

            for (int i = 0; i < clipsPerPage; i++)
            {
                var b = ButtonRow(rt, "", 56, out var label);
                label.alignment = TextAnchor.MiddleLeft;
                _rows.Add((b, label));
            }

            var nav = new GameObject("Nav", typeof(RectTransform));
            nav.transform.SetParent(rt, false);
            var h = nav.AddComponent<HorizontalLayoutGroup>();
            h.spacing = 8; h.childControlWidth = h.childControlHeight = true; h.childForceExpandWidth = false;
            nav.AddComponent<LayoutElement>().minHeight = 56;
            var navRt = (RectTransform)nav.transform;
            ButtonCell(navRt, "<  Prev", 140, () => { _page--; RefreshPage(); });
            _pageLabel = Label(navRt, "", 20, FontStyle.Normal, 56, Color.white, flex: true);
            ButtonCell(navRt, "Next  >", 140, () => { _page++; RefreshPage(); });

            var actions = new GameObject("Actions", typeof(RectTransform));
            actions.transform.SetParent(rt, false);
            var a = actions.AddComponent<HorizontalLayoutGroup>();
            a.spacing = 8; a.childControlWidth = a.childControlHeight = true; a.childForceExpandWidth = true;
            actions.AddComponent<LayoutElement>().minHeight = 56;
            var actRt = (RectTransform)actions.transform;
            ButtonCell(actRt, "STOP", 0, () => { if (playOn != null) playOn.Stop(); _pending = null; Log("Stopped."); }, new Color(0.6f, 0.2f, 0.2f));
            ButtonCell(actRt, "Refresh status", 0, RefreshStatus);

            _log = Label(rt, "", 17, FontStyle.Normal, 140, new Color(0.85f, 0.85f, 0.85f));
            _log.alignment = TextAnchor.UpperLeft;
        }

        Text Label(RectTransform parent, string text, int size, FontStyle style, float minHeight, Color color, bool flex = false)
        {
            var go = new GameObject("Label", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            t.font = _font; t.fontSize = size; t.fontStyle = style; t.color = color;
            t.alignment = TextAnchor.MiddleCenter;
            t.horizontalOverflow = HorizontalWrapMode.Wrap; t.verticalOverflow = VerticalWrapMode.Truncate;
            t.raycastTarget = false; t.text = text;
            var le = go.AddComponent<LayoutElement>();
            le.minHeight = minHeight;
            if (flex) le.flexibleWidth = 1;
            return t;
        }

        Button ButtonRow(RectTransform parent, string label, float h, out Text text)
        {
            var go = new GameObject("Clip Button", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            go.AddComponent<Image>().color = new Color(0.22f, 0.25f, 0.32f);
            var btn = go.AddComponent<Button>();
            go.AddComponent<LayoutElement>().minHeight = h;
            text = Stretched((RectTransform)go.transform, label, 22);
            return btn;
        }

        void ButtonCell(RectTransform parent, string label, float width, Action onClick, Color? color = null)
        {
            var go = new GameObject("Button", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            go.AddComponent<Image>().color = color ?? new Color(0.22f, 0.25f, 0.32f);
            var btn = go.AddComponent<Button>();
            btn.onClick.AddListener(() => onClick());
            var le = go.AddComponent<LayoutElement>();
            le.minHeight = 56;
            if (width > 0) le.minWidth = le.preferredWidth = width; else le.flexibleWidth = 1;
            Stretched((RectTransform)go.transform, label, 22);
        }

        Text Stretched(RectTransform parent, string text, int size)
        {
            var go = new GameObject("Text", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            t.font = _font; t.fontSize = size; t.fontStyle = FontStyle.Bold; t.color = Color.white;
            t.alignment = TextAnchor.MiddleCenter; t.raycastTarget = false; t.text = text;
            var rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(16, 0); rt.offsetMax = new Vector2(-16, 0);
            return t;
        }

        static void EnsureEventSystem()
        {
#if UNITY_2023_1_OR_NEWER
            var es = FindFirstObjectByType<EventSystem>();
#else
            var es = FindObjectOfType<EventSystem>();
#endif
            if (es == null) es = new GameObject("EventSystem", typeof(EventSystem)).GetComponent<EventSystem>();
            if (es.GetComponent<XRUIInputModule>() == null)
            {
                foreach (var m in es.GetComponents<BaseInputModule>()) Destroy(m);
                es.gameObject.AddComponent<XRUIInputModule>();
            }
        }
    }
}
