// FutureCity Offline TTS — removes the XR simulator in player builds or when a real headset is running
// (e.g. Quest Link in the Editor), so the same test scene works with and without a headset.
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS.XR
{
    [DefaultExecutionOrder(-1000)]
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/XR/Simulator Auto Disable")]
    public class TTSSimulatorAutoDisable : MonoBehaviour
    {
        void Awake()
        {
            bool headset = UnityEngine.XR.XRSettings.isDeviceActive;
            if (!Application.isEditor || headset)
            {
                Debug.Log($"[OfflineTTS] Removing XR simulator ({(headset ? "headset detected" : "player build")}).");
                Destroy(gameObject);
            }
        }
    }
}
