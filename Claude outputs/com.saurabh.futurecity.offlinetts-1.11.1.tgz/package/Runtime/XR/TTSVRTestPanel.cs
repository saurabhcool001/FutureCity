// FutureCity Offline TTS — world-space test panel for VR (XR Interaction Toolkit 3.x).
// Builds its own uGUI canvas at runtime (no prefab, no TextMeshPro import needed).
//
// Left column : pick a character, pick a female/male voice, type text (VR keyboard or PC keyboard), SPEAK.
// Right column: language, quality, speed, toggles, voice preview, timing + benchmark, log.
// Point a controller ray at it and pull the trigger (or poke with hands) to press buttons.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit.UI;
using Debug = UnityEngine.Debug;

namespace SaurabhFutureCity.OfflineTTS.XR
{
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/XR/VR Test Panel")]
    public class TTSVRTestPanel : MonoBehaviour
    {
        [Tooltip("Characters (TTS Speakers) the panel can select, re-voice and make talk. " +
                 "Empty = every TTS Speaker found in the scene.")]
        public TTSSpeaker[] characters;
        [Tooltip("Show a floating 'name · voice' tag above each character; it turns yellow on the character the panel controls.")]
        public bool showNameTags = true;

        [Tooltip("Preset sentences you can cycle through on the panel ('Say test line' / 'Use as text').")]
        [TextArea(2, 4)]
        public string[] testLines =
        {
            "Hello! This voice is generated on the headset, completely offline.",
            "Before lifting, check the weight of the load and plan your route.",
            "Warning. You are entering a hazardous area. Please wear your hard hat.",
            "Correct! Well done. Let's move on to the next question.",
            "When lifting a heavy object, stand close to the load, bend your knees, keep your back straight, " +
            "and lift smoothly using the strength of your legs.",
        };

        [Header("Panel size (metres)")]
        [Tooltip("Panel width in metres (world space).")]
        public float width = 1.4f;
        [Tooltip("Panel height in metres (world space).")]
        public float height = 1.1f;

        static readonly string[] FemaleVoices = { "F1", "F2", "F3", "F4", "F5" };
        static readonly string[] MaleVoices = { "M1", "M2", "M3", "M4", "M5" };
        static readonly string[] NumberWords = { "one", "two", "three", "four", "five" };

        OfflineTTS _tts;
        int _charIndex, _langIndex, _lineIndex;
        int _steps;
        float _speed = 1.05f;
        bool _stream = true, _spatialize = true, _cache, _shift;
        bool _busy, _previewing;
        Stopwatch _speakTimer;

        InputField _input;
        Text _status, _charLabel, _langLabel, _stepsLabel, _speedLabel, _lineLabel, _log;
        Text _streamLabel, _spatialLabel, _cacheLabel, _shiftLabel;
        readonly Dictionary<string, Image> _voiceButtons = new Dictionary<string, Image>();
        readonly List<(Text label, char c)> _letterKeys = new List<(Text, char)>();
        readonly List<(Transform tag, Text text, TTSSpeaker speaker, float height)> _tags = new List<(Transform, Text, TTSSpeaker, float)>();
        readonly Queue<string> _logLines = new Queue<string>();
        Font _font;

        static readonly Color ButtonColor = new Color(0.22f, 0.25f, 0.32f);
        static readonly Color FemaleColor = new Color(0.55f, 0.25f, 0.45f);
        static readonly Color MaleColor = new Color(0.2f, 0.35f, 0.6f);
        static readonly Color SelectedColor = new Color(0.95f, 0.75f, 0.2f);
        const float PixelsPerMetre = 1000f;

        TTSSpeaker Target => characters != null && characters.Length > 0 ? characters[_charIndex] : null;

        // ------------------------------------------------------------------ lifecycle

        async void Start()
        {
            _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            _langIndex = Math.Max(0, Array.IndexOf(TTSLanguages.All, "en"));
            if (characters == null || characters.Length == 0)
            {
#if UNITY_2023_1_OR_NEWER
                characters = FindObjectsByType<TTSSpeaker>(FindObjectsSortMode.None);
#else
                characters = FindObjectsOfType<TTSSpeaker>();
#endif
            }

            BuildUI();
            EnsureEventSystem();
            if (showNameTags) BuildNameTags();

            _tts = OfflineTTS.GetOrCreate();
            _steps = _tts.Settings != null ? _tts.Settings.DefaultParams.Steps : 8;

            foreach (var c in characters)
            {
                var speaker = c;
                speaker.onSpeechStarted.AddListener(_ => { if (_speakTimer != null && speaker == Target) Log($"First audio after {_speakTimer.ElapsedMilliseconds} ms"); });
                speaker.onSpeechFinished.AddListener(_ => { if (speaker == Target) _speakTimer = null; });
                speaker.onError.AddListener(e => Log("ERROR: " + e));
            }
            RefreshLabels();

            var sw = Stopwatch.StartNew();
            SetStatus("Loading model…");
            try
            {
                await _tts.InitializeAsync();
                SetStatus($"Ready · {Application.platform}");
                Log($"Model loaded in {sw.Elapsed.TotalSeconds:0.0} s");
            }
            catch (Exception e)
            {
                SetStatus("Model load FAILED");
                Log("ERROR: " + e.Message);
            }
        }

        void Update()
        {
            if (_tts != null && !_tts.IsReady && _status != null)
                _status.text = $"Loading model… {_tts.LoadProgress:P0}";

            var cam = Camera.main;
            foreach (var (tag, text, speaker, h) in _tags)
            {
                if (speaker == null) continue;
                tag.position = speaker.transform.position + Vector3.up * h;
                if (cam != null) tag.rotation = Quaternion.LookRotation(tag.position - cam.transform.position);
                bool talking = speaker.IsSpeaking;
                text.text = $"{speaker.name.Split('-')[0].Trim()}  ·  {VoiceDisplayName(speaker.voice)}{(talking ? "  (speaking)" : "")}";
                text.color = speaker == Target ? SelectedColor : Color.white;
            }
        }

        // ------------------------------------------------------------------ actions

        void ApplySettings(TTSSpeaker s)
        {
            s.language = TTSLanguages.All[_langIndex];
            s.steps = _steps;
            s.speed = _speed;
            s.streamSentences = _stream;
        }

        void SpeakTyped()
        {
            string text = _input != null ? _input.text.Trim() : "";
            if (text.Length == 0) { text = testLines[_lineIndex]; Log("Text box empty - speaking the test line."); }
            Speak(text);
        }

        void Speak(string text)
        {
            if (!Ready() || Target == null) return;
            _previewing = false;
            ApplySettings(Target);
            _speakTimer = Stopwatch.StartNew();
            Log($"{Target.name.Split('-')[0].Trim()} ({Target.voice}): \"{Short(text, 40)}\"");
            Target.Speak(text);
        }

        void SelectVoice(string voice)
        {
            if (Target == null) return;
            Target.voice = voice;
            RefreshLabels();
            Log($"{Target.name.Split('-')[0].Trim()} → {VoiceDisplayName(voice)}");
        }

        async void PreviewAllVoices()
        {
            if (!Ready() || Target == null || _previewing) return;
            _previewing = true;
            var target = Target;
            string original = target.voice;
            ApplySettings(target);
            Log("Previewing all 10 voices…");
            try
            {
                foreach (var v in Concat(FemaleVoices, MaleVoices))
                {
                    if (!_previewing || target != Target) break;
                    target.voice = v;
                    RefreshLabels();
                    bool finished = await target.SpeakAsync($"Hello, I am {SpokenVoiceName(v)}. Please check the load before lifting.");
                    if (!finished) break;
                }
            }
            finally
            {
                _previewing = false;
                target.voice = original;
                RefreshLabels();
            }
        }

        void StopAll()
        {
            _previewing = false;
            foreach (var c in characters) if (c != null) c.Stop();
        }

        async void GenerateTimed()
        {
            if (!Ready() || _busy || Target == null) return;
            _busy = true;
            try
            {
                string text = _input != null && _input.text.Trim().Length > 0 ? _input.text.Trim() : testLines[_lineIndex];
                var r = new TTSRequest
                {
                    voice = Target.voice, language = TTSLanguages.All[_langIndex],
                    steps = _steps, speed = _speed, seed = Target.seed, useCache = false,
                };
                var sw = Stopwatch.StartNew();
                var samples = await _tts.SynthesizeSamplesAsync(text, r);
                double gen = sw.Elapsed.TotalSeconds, audio = samples.Length / (double)_tts.SampleRate;
                Log($"{audio:0.0}s audio in {gen:0.00}s → {audio / Math.Max(gen, 1e-6):0.0}x real-time");

                string path = Path.Combine(Application.persistentDataPath, "TTSTests", $"vr_{r.voice}_{DateTime.Now:HHmmss}.wav");
                WavUtility.Save(path, samples, _tts.SampleRate);
                Log("Saved " + Path.GetFileName(path));

                Target.Stop();
                Target.Source.clip = _tts.ToClip(samples, "VRTest");
                Target.Source.Play();
            }
            catch (Exception e) { Log("ERROR: " + e.Message); }
            finally { _busy = false; }
        }

        async void Benchmark()
        {
            if (!Ready() || _busy || Target == null) return;
            _busy = true;
            Log("Benchmark…");
            try
            {
                foreach (var steps in new[] { 8, 5, 3 })
                {
                    var r = new TTSRequest { voice = Target.voice, language = "en", steps = steps, speed = _speed, seed = 1, useCache = false };
                    var sw = Stopwatch.StartNew();
                    var s = await _tts.SynthesizeSamplesAsync(testLines[1], r);
                    double gen = sw.Elapsed.TotalSeconds, audio = s.Length / (double)_tts.SampleRate;
                    Log($"{steps} steps: {gen * 1000:0} ms · {audio / Math.Max(gen, 1e-6):0.0}x RT");
                }
            }
            catch (Exception e) { Log("ERROR: " + e.Message); }
            finally { _busy = false; }
        }

        void ToggleSpatial()
        {
            _spatialize = !_spatialize;
            foreach (var s in characters)
                if (s != null && s.Source != null) { s.Source.spatialize = _spatialize; s.Source.spatialBlend = _spatialize ? 1f : 0f; }
            Log(_spatialize ? "3D spatial audio ON" : "3D audio OFF (2D, both ears)");
            RefreshLabels();
        }

        void TypeChar(char c)
        {
            if (_input == null) return;
            if (char.IsLetter(c) && _shift) { c = char.ToUpperInvariant(c); _shift = false; RefreshKeyCase(); }
            if (_input.text.Length < _input.characterLimit || _input.characterLimit == 0) _input.text += c;
        }

        void Backspace()
        {
            if (_input != null && _input.text.Length > 0) _input.text = _input.text.Substring(0, _input.text.Length - 1);
        }

        bool Ready()
        {
            if (_tts != null && _tts.IsReady) return true;
            Log("Model not ready yet");
            return false;
        }

        // ------------------------------------------------------------------ UI construction

        void BuildUI()
        {
            var canvasGo = new GameObject("TTS VR Test Canvas", typeof(RectTransform));
            canvasGo.transform.SetParent(transform, false);
            var canvas = canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = Camera.main;
            canvasGo.AddComponent<CanvasScaler>().dynamicPixelsPerUnit = 2f;
            canvasGo.AddComponent<TrackedDeviceGraphicRaycaster>();

            var rt = (RectTransform)canvasGo.transform;
            rt.sizeDelta = new Vector2(width * PixelsPerMetre, height * PixelsPerMetre);
            rt.localScale = Vector3.one / PixelsPerMetre;
            canvasGo.AddComponent<Image>().color = new Color(0.08f, 0.09f, 0.12f, 0.94f);

            var columns = canvasGo.AddComponent<HorizontalLayoutGroup>();
            columns.padding = new RectOffset(24, 24, 20, 20);
            columns.spacing = 24;
            columns.childControlWidth = columns.childControlHeight = true;
            columns.childForceExpandWidth = false;
            columns.childForceExpandHeight = true;

            var left = Column(rt, 0.58f);
            var right = Column(rt, 0.42f);

            // ---- left: who speaks, which voice, what text
            Label(left, "FutureCity Offline TTS - VR Test", 36, FontStyle.Bold, 46);
            _status = Label(left, "Starting…", 24, FontStyle.Normal, 32, new Color(0.55f, 0.85f, 1f));

            Row(left, r =>
            {
                Label(r, "Character", 24, FontStyle.Normal, 64, width: 140);
                Button(r, "<", () => { _charIndex = Wrap(_charIndex - 1, characters.Length); RefreshLabels(); }, 80);
                _charLabel = Label(r, "", 28, FontStyle.Bold, 64, flex: true);
                Button(r, ">", () => { _charIndex = Wrap(_charIndex + 1, characters.Length); RefreshLabels(); }, 80);
            });

            VoiceRow(left, "Female", FemaleVoices, FemaleColor);
            VoiceRow(left, "Male", MaleVoices, MaleColor);

            _input = InputBox(left, 150);

            BuildKeyboard(left);

            Row(left, r =>
            {
                Button(r, "SPEAK", SpeakTyped, 0, new Color(0.18f, 0.55f, 0.3f), flex: true, h: 90, fontSize: 34);
                Button(r, "STOP", StopAll, 0, new Color(0.6f, 0.2f, 0.2f), flex: true, h: 90, fontSize: 34);
            }, 90);

            // ---- right: settings + diagnostics
            Label(right, "Settings", 30, FontStyle.Bold, 46);
            Stepper(right, () => { _langIndex = Wrap(_langIndex - 1, TTSLanguages.All.Length); RefreshLabels(); },
                           () => { _langIndex = Wrap(_langIndex + 1, TTSLanguages.All.Length); RefreshLabels(); }, out _langLabel);
            Stepper(right, () => { _steps = Mathf.Clamp(_steps - 1, 1, 16); RefreshLabels(); },
                           () => { _steps = Mathf.Clamp(_steps + 1, 1, 16); RefreshLabels(); }, out _stepsLabel);
            Stepper(right, () => { _speed = Mathf.Clamp(_speed - 0.1f, 0.5f, 2f); RefreshLabels(); },
                           () => { _speed = Mathf.Clamp(_speed + 0.1f, 0.5f, 2f); RefreshLabels(); }, out _speedLabel);

            Row(right, r =>
            {
                _streamLabel = Button(r, "", () => { _stream = !_stream; RefreshLabels(); }, 0, flex: true, fontSize: 22);
                _spatialLabel = Button(r, "", ToggleSpatial, 0, flex: true, fontSize: 22);
                _cacheLabel = Button(r, "", () => { _cache = !_cache; RefreshLabels(); }, 0, flex: true, fontSize: 22);
            });

            Row(right, r =>
            {
                Button(r, "<", () => { _lineIndex = Wrap(_lineIndex - 1, testLines.Length); RefreshLabels(); }, 70);
                _lineLabel = Label(r, "", 20, FontStyle.Italic, 80, flex: true);
                Button(r, ">", () => { _lineIndex = Wrap(_lineIndex + 1, testLines.Length); RefreshLabels(); }, 70);
            }, 80);
            Row(right, r =>
            {
                Button(r, "Say test line", () => Speak(testLines[_lineIndex]), 0, flex: true, fontSize: 22);
                Button(r, "Use as text", () => { if (_input != null) _input.text = testLines[_lineIndex]; }, 0, flex: true, fontSize: 22);
            });
            Row(right, r => Button(r, "Preview all 10 voices", PreviewAllVoices, 0, new Color(0.35f, 0.3f, 0.55f), flex: true, fontSize: 24));
            Row(right, r =>
            {
                Button(r, "Timed + save WAV", GenerateTimed, 0, flex: true, fontSize: 22);
                Button(r, "Benchmark", Benchmark, 0, flex: true, fontSize: 22);
            });

            _log = Label(right, "", 20, FontStyle.Normal, 220, new Color(0.8f, 0.8f, 0.8f));
            _log.alignment = TextAnchor.UpperLeft;
            _log.GetComponent<LayoutElement>().flexibleHeight = 1;
        }

        void VoiceRow(RectTransform parent, string label, string[] voices, Color color)
        {
            Row(parent, r =>
            {
                Label(r, label, 24, FontStyle.Normal, 64, width: 140);
                foreach (var v in voices)
                {
                    var voice = v;
                    var text = Button(r, v, () => SelectVoice(voice), 0, color, flex: true, fontSize: 28);
                    _voiceButtons[v] = text.transform.parent.GetComponent<Image>();
                }
            }, 64);
        }

        void Stepper(RectTransform parent, Action minus, Action plus, out Text label)
        {
            Text l = null;
            Row(parent, r =>
            {
                Button(r, "-", minus, 80);
                l = Label(r, "", 26, FontStyle.Normal, 64, flex: true);
                Button(r, "+", plus, 80);
            }, 64);
            label = l;
        }

        void BuildKeyboard(RectTransform parent)
        {
            string[] rows = { "1234567890", "qwertyuiop", "asdfghjkl'", "zxcvbnm,.?" };
            foreach (var row in rows)
            {
                Row(parent, r =>
                {
                    foreach (var ch in row)
                    {
                        char c = ch;
                        var t = Button(r, c.ToString(), () => TypeChar(c), 0, flex: true, h: 58, fontSize: 28);
                        if (char.IsLetter(c)) _letterKeys.Add((t, c));
                    }
                }, 58);
            }
            Row(parent, r =>
            {
                _shiftLabel = Button(r, "Shift", () => { _shift = !_shift; RefreshKeyCase(); }, 150, h: 58, fontSize: 24);
                Button(r, "!", () => TypeChar('!'), 70, h: 58, fontSize: 28);
                Button(r, "space", () => TypeChar(' '), 0, flex: true, h: 58, fontSize: 24);
                Button(r, "Del", Backspace, 100, h: 58, fontSize: 28);
                Button(r, "Clear", () => { if (_input != null) _input.text = ""; }, 110, new Color(0.45f, 0.3f, 0.2f), h: 58, fontSize: 24);
            }, 58);
        }

        void RefreshKeyCase()
        {
            foreach (var (label, c) in _letterKeys) label.text = _shift ? char.ToUpperInvariant(c).ToString() : c.ToString();
            if (_shiftLabel != null) _shiftLabel.text = _shift ? "SHIFT" : "Shift";
        }

        void RefreshLabels()
        {
            if (_charLabel == null) return;
            var t = Target;
            _charLabel.text = t != null ? $"{t.name.Split('-')[0].Trim()}" : "(no characters)";
            foreach (var kv in _voiceButtons)
            {
                bool selected = t != null && t.voice == kv.Key;
                kv.Value.color = selected ? SelectedColor : (kv.Key.StartsWith("F") ? FemaleColor : MaleColor);
            }
            _langLabel.text = $"Language  {TTSLanguages.All[_langIndex]}";
            _stepsLabel.text = $"Quality steps  {_steps}";
            _speedLabel.text = $"Speed  {_speed:0.0}";
            _lineLabel.text = $"\"{Short(testLines[_lineIndex], 60)}\"";
            _streamLabel.text = _stream ? "Stream ON" : "Stream OFF";
            _spatialLabel.text = _spatialize ? "3D audio ON" : "3D audio OFF";
            _cacheLabel.text = _cache ? "Cache ON" : "Cache OFF";
        }

        void BuildNameTags()
        {
            foreach (var c in characters)
            {
                if (c == null) continue;
                var r = c.GetComponentInChildren<Renderer>();
                float h = r != null ? r.bounds.max.y - c.transform.position.y + 0.12f : 0.4f;

                var go = new GameObject($"Name Tag ({c.name})", typeof(RectTransform));
                go.transform.SetParent(transform, true);
                var canvas = go.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.WorldSpace;
                var rt = (RectTransform)go.transform;
                rt.sizeDelta = new Vector2(700, 80);
                rt.localScale = Vector3.one / PixelsPerMetre;
                var text = StretchedText(rt, "", 40, FontStyle.Bold, TextAnchor.MiddleCenter);
                _tags.Add((go.transform, text, c, h));
            }
        }

        void SetStatus(string s) { if (_status != null) _status.text = s; }

        void Log(string message)
        {
            Debug.Log("[TTSVRTestPanel] " + message);
            _logLines.Enqueue(message);
            while (_logLines.Count > 9) _logLines.Dequeue();
            if (_log != null) _log.text = string.Join("\n", _logLines);
        }

        // ------------------------------------------------------------------ naming helpers

        public static string VoiceDisplayName(string v)
        {
            if (string.IsNullOrEmpty(v) || v.Length < 2) return v;
            string gender = v[0] == 'F' ? "Female" : v[0] == 'M' ? "Male" : null;
            return gender != null ? $"{gender} {v.Substring(1)}" : v;
        }

        static string SpokenVoiceName(string v)
        {
            if (v.Length == 2 && char.IsDigit(v[1]))
            {
                int n = v[1] - '1';
                string gender = v[0] == 'F' ? "female voice" : "male voice";
                if (n >= 0 && n < NumberWords.Length) return $"{gender} {NumberWords[n]}";
            }
            return v;
        }

        static IEnumerable<string> Concat(string[] a, string[] b) { foreach (var x in a) yield return x; foreach (var x in b) yield return x; }
        static int Wrap(int i, int n) => n <= 0 ? 0 : (i % n + n) % n;
        static string Short(string s, int max) => s.Length > max ? s.Substring(0, max) + "…" : s;

        // ------------------------------------------------------------------ uGUI builders

        RectTransform Column(RectTransform parent, float flex)
        {
            var go = new GameObject("Column", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var v = go.AddComponent<VerticalLayoutGroup>();
            v.spacing = 10;
            v.childControlWidth = v.childControlHeight = true;
            v.childForceExpandWidth = true;
            v.childForceExpandHeight = false;
            go.AddComponent<LayoutElement>().flexibleWidth = flex;
            return (RectTransform)go.transform;
        }

        void Row(RectTransform parent, Action<RectTransform> build, float minHeight = 64)
        {
            var go = new GameObject("Row", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var h = go.AddComponent<HorizontalLayoutGroup>();
            h.spacing = 8;
            h.childForceExpandWidth = false;
            h.childForceExpandHeight = true;
            h.childControlWidth = h.childControlHeight = true;
            go.AddComponent<LayoutElement>().minHeight = minHeight;
            build((RectTransform)go.transform);
        }

        Text Label(RectTransform parent, string text, int size, FontStyle style, float minHeight,
                   Color? color = null, bool flex = false, float width = 0)
        {
            var go = new GameObject("Label", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            t.font = _font;
            t.fontSize = size;
            t.fontStyle = style;
            t.color = color ?? Color.white;
            t.alignment = TextAnchor.MiddleCenter;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Truncate;
            t.raycastTarget = false;
            t.text = text;
            var le = go.AddComponent<LayoutElement>();
            le.minHeight = minHeight;
            if (width > 0) le.minWidth = le.preferredWidth = width;
            if (flex) le.flexibleWidth = 1;
            return t;
        }

        Text StretchedText(RectTransform parent, string text, int size, FontStyle style, TextAnchor anchor, float pad = 0)
        {
            var go = new GameObject("Text", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            t.font = _font;
            t.fontSize = size;
            t.fontStyle = style;
            t.alignment = anchor;
            t.color = Color.white;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Truncate;
            t.raycastTarget = false;
            t.text = text;
            var rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(pad, pad); rt.offsetMax = new Vector2(-pad, -pad);
            return t;
        }

        Text Button(RectTransform parent, string label, Action onClick, float width,
                    Color? color = null, bool flex = false, float h = 64, int fontSize = 26)
        {
            var go = new GameObject("Button", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var img = go.AddComponent<Image>();
            img.color = color ?? ButtonColor;
            var btn = go.AddComponent<Button>();
            var colors = btn.colors;
            colors.highlightedColor = new Color(1.25f, 1.25f, 1.25f);
            colors.pressedColor = new Color(0.7f, 0.7f, 0.7f);
            btn.colors = colors;
            btn.onClick.AddListener(() => onClick());

            var le = go.AddComponent<LayoutElement>();
            le.minHeight = h;
            if (width > 0) le.minWidth = le.preferredWidth = width;
            if (flex) le.flexibleWidth = 1;

            return StretchedText((RectTransform)go.transform, label, fontSize, FontStyle.Bold, TextAnchor.MiddleCenter);
        }

        InputField InputBox(RectTransform parent, float h)
        {
            var go = new GameObject("Text Input", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var img = go.AddComponent<Image>();
            img.color = new Color(0.95f, 0.95f, 0.97f);
            var le = go.AddComponent<LayoutElement>();
            le.minHeight = h;

            var rt = (RectTransform)go.transform;
            var text = StretchedText(rt, "", 28, FontStyle.Normal, TextAnchor.UpperLeft, 14);
            text.color = new Color(0.08f, 0.08f, 0.1f);
            text.supportRichText = false;
            var placeholder = StretchedText(rt, "Type what the character should say…  (VR keyboard below, or your PC keyboard in the Editor)",
                26, FontStyle.Italic, TextAnchor.UpperLeft, 14);
            placeholder.color = new Color(0.45f, 0.45f, 0.5f);

            var field = go.AddComponent<InputField>();
            field.textComponent = text;
            field.placeholder = placeholder;
            field.lineType = InputField.LineType.MultiLineNewline;
            field.characterLimit = 500;
            // On Quest/Android, focusing the field would try to open the phone keyboard; use the VR keyboard instead.
            field.readOnly = Application.isMobilePlatform;
            field.shouldHideMobileInput = true;
            return field;
        }

        static void EnsureEventSystem()
        {
#if UNITY_2023_1_OR_NEWER
            var es = FindFirstObjectByType<EventSystem>();
#else
            var es = FindObjectOfType<EventSystem>();
#endif
            if (es == null) es = new GameObject("EventSystem", typeof(EventSystem)).GetComponent<EventSystem>();
            if (es.GetComponent<XRUIInputModule>() == null)
            {
                foreach (var m in es.GetComponents<BaseInputModule>()) Destroy(m);
                es.gameObject.AddComponent<XRUIInputModule>();
            }
        }
    }
}
