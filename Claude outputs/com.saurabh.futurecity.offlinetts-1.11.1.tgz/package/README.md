# FutureCity Offline TTS

Fully offline, on-device neural **text-to-speech for Unity**: Supertonic 3 on ONNX Runtime.
It supports 31 languages and 10 voices (5 female, 5 male), runs on Quest / Pico / Android XR, PC VR and desktop,
and needs no cloud or API keys.

> **Renamed in 1.9.0:** formerly `com.xrlp.offlinetts` / `XRLP.OfflineTTS`. See *Migrating from com.xrlp.offlinetts* in the documentation.

## Install (Package Manager)

1. **Window ▸ Package Manager ▸ + ▸ Install package from git URL…**
2. Paste:
   ```
   https://github.com/YOUR-ACCOUNT/com.saurabh.futurecity.offlinetts.git#v1.11.1
   ```
3. Wait a few seconds. On first import the package **adds the ONNX Runtime npm registry, the
   `com.github.asus4.onnxruntime` dependency and `testables` to your `Packages/manifest.json` automatically**
   and re-resolves. You don't need to edit the manifest by hand.
4. **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Download Supertonic 3 Models** (≈ 400 MB, once per project).
5. **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Run Diagnostics**: you should hear a test line.

You can also install from disk (folder or `.tgz` tarball); the same automatic setup runs.

## Use

```csharp
using SaurabhFutureCity.OfflineTTS;

public class Hello : MonoBehaviour
{
    public TTSSpeaker speaker;          // on the character, next to its AudioSource
    async void Start()
    {
        bool finished = await speaker.SpeakAsync("Please put on your safety glasses.");
    }
}
```

* **TTS Speaker** has Voice and Language dropdowns, and every field has a detailed tooltip.
* **TTS Video Narrator** speaks timed cues over a VideoPlayer.
* **Highlighting for baked and recorded clips**: the Baker saves word timings, and the Word Timing Generator makes them for human voice-over.
* **TTS Subtitle Display**: TextMeshPro subtitles with word highlighting, ready-made for screen or VR (TextMeshPro is installed with the plugin).
* **TTS Auto Highlight**: add one to a scene and highlighting sets itself up for every clip and text. Manual and code setups are documented too.
* **Batch Add TTS Speakers** adds or updates TTS Speakers on every matching object in a prefab (e.g. all `NpcAudio` objects) in one click.
* **Voice-over Baker** turns scripts into WAV files (default output `Assets/Features/TTS/TTS_Baked`).
* **TTS Word Highlighter** highlights and pops the word being spoken in TextMeshPro text; customise it globally, per group (TTS Override) or per text.
* **TTS Override** changes any global setting (voice, highlight on/off, colour, zoom…) on specific objects only.
* **Test scenes** for PC and VR (XR Interaction Toolkit 3.x): type text, pick a female or male voice, press Speak.

## Testing the plugin

**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create Plugin Test Scene (Playground)**: live TTS, baked clips and highlighted subtitles in one scene, for the Editor or an APK.

## Documentation

Current version, release dates, requirements and upgrade notes: *Version and release history* in the docs, or **FutureCity ▸ Plugins ▸ OfflineTTS ▸ About** in Unity.

Full documentation is in [`Documentation~/index.md`](Documentation~/index.md). In Unity, use
**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Documentation** (works offline) or *View documentation* in the Package Manager.

## Licence

See `LICENSE.md` and `THIRD_PARTY_NOTICES.md`. The Supertonic 3 model weights (downloaded separately) are licensed
under OpenRAIL-M.
