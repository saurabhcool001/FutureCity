// FutureCity Offline TTS — EditMode tests. Window ▸ General ▸ Test Runner ▸ EditMode ▸ Run All.
// Engine tests are skipped (Ignored) if the models haven't been downloaded yet.

using System;
using System.IO;
using NUnit.Framework;
using UnityEngine;
using Object = UnityEngine.Object;
using SaurabhFutureCity.OfflineTTS.Editor;

namespace SaurabhFutureCity.OfflineTTS.Tests
{
    public class TextTests
    {
        [Test]
        public void Prepare_WrapsLanguageTags_AndAddsPeriod()
        {
            Assert.AreEqual("<en>Hello world.</en>", TextPreprocessor.Prepare("Hello   world", "en"));
        }

        [Test]
        public void Prepare_NormalisesQuotesAndDashes()
        {
            Assert.AreEqual("<en>Say \"hi\" - now.</en>", TextPreprocessor.Prepare("Say \u201Chi\u201D \u2014 now.", "en"));
        }

        [Test]
        public void Prepare_RejectsUnsupportedLanguage()
        {
            Assert.Throws<ArgumentException>(() => TextPreprocessor.Prepare("Hello", "xx"));
        }

        [Test]
        public void Chunk_DoesNotSplitDecimalsOrTitles()
        {
            var chunks = TextPreprocessor.Chunk("Dr. Smith said the load is 3.5 kg. Lift it now!", 300);
            Assert.AreEqual(1, chunks.Count);
            Assert.AreEqual("Dr. Smith said the load is 3.5 kg. Lift it now!", chunks[0]);
        }

        [Test]
        public void Chunk_RespectsMaxLength()
        {
            var chunks = TextPreprocessor.Chunk("One two three. Four five six. Seven eight nine. Ten eleven twelve.", 30);
            Assert.Greater(chunks.Count, 1);
            foreach (var c in chunks) Assert.LessOrEqual(c.Length, 30, c);
        }

        [Test]
        public void Wav_RoundTrip()
        {
            string path = Path.Combine(Path.GetTempPath(), "futurecity_tts_test.wav");
            var input = new[] { 0f, 0.5f, -0.5f, 0.25f };
            WavUtility.Save(path, input, 44100);
            Assert.IsTrue(WavUtility.TryLoad(path, out var output, out int sr));
            Assert.AreEqual(44100, sr);
            Assert.AreEqual(input.Length, output.Length);
            for (int i = 0; i < input.Length; i++) Assert.AreEqual(input[i], output[i], 1e-3f);
            File.Delete(path);
        }
    }

    public class ClipTimingTests
    {
        [Test]
        public void Registry_FindsTimingByClip()
        {
            var clip = AudioClip.Create("timing_test", 44100, 1, 44100, false);
            var timing = ScriptableObject.CreateInstance<TTSClipTiming>();
            timing.clip = clip;
            timing.text = "Check the load";
            timing.words = new[] { new TTSWordTiming(0, 0f, 0.3f), new TTSWordTiming(1, 0.3f, 0.5f), new TTSWordTiming(2, 0.5f, 0.9f) };
            var library = ScriptableObject.CreateInstance<TTSClipTimingLibrary>();
            library.Add(timing);

            TTSClipTimings.Register(library);
            Assert.IsTrue(TTSClipTimings.TryGet(clip, out var found));
            Assert.AreSame(timing, found);
            Assert.AreEqual(1, WordTimingEstimator.FindWordAt(found.words, 0.4f));

            Object.DestroyImmediate(timing); Object.DestroyImmediate(library); Object.DestroyImmediate(clip);
        }

        [Test]
        public void Library_ReplacesTimingForSameClip()
        {
            var clip = AudioClip.Create("timing_test2", 4410, 1, 44100, false);
            var a = ScriptableObject.CreateInstance<TTSClipTiming>(); a.clip = clip;
            var b = ScriptableObject.CreateInstance<TTSClipTiming>(); b.clip = clip;
            var library = ScriptableObject.CreateInstance<TTSClipTimingLibrary>();
            library.Add(a); library.Add(b);
            Assert.AreEqual(1, library.timings.Count);
            Assert.AreSame(b, library.timings[0]);
            Object.DestroyImmediate(a); Object.DestroyImmediate(b); Object.DestroyImmediate(library); Object.DestroyImmediate(clip);
        }
    }

    public class EngineTests
    {
        static SupertonicEngine _engine;
        static VoiceStyle _voice;
        static string Root => TTSModelSetup.StreamingRoot();

        [OneTimeSetUp]
        public void Setup()
        {
            if (!TTSModelSetup.ModelsPresent())
                Assert.Ignore("Supertonic models not found — run FutureCity ▸ Plugins ▸ OfflineTTS ▸ Download Supertonic 3 Models.");
            _engine = new SupertonicEngine(ModelLocator.OnnxDir(Root), EngineOptions.Default);
            _voice = VoiceStyle.FromFile(ModelLocator.VoicePath(Root, "F1"));
        }

        [OneTimeTearDown]
        public void TearDown() { _engine?.Dispose(); _engine = null; }

        static SynthesisParams P(int seed = 1, int steps = 5) =>
            new SynthesisParams { Steps = steps, Speed = 1.05f, ChunkSilence = 0.3f, Seed = seed };

        [Test]
        public void Synthesize_ProducesAudibleSpeech()
        {
            var samples = _engine.Synthesize("Please wear your safety helmet.", "en", _voice, P());
            float seconds = samples.Length / (float)_engine.SampleRate;
            float peak = 0f;
            foreach (var s in samples) peak = Mathf.Max(peak, Mathf.Abs(s));

            Assert.That(seconds, Is.InRange(0.8f, 6f), $"duration {seconds:0.00}s");
            Assert.Greater(peak, 0.01f, "output is near-silent");
        }

        [Test]
        public void Synthesize_SameSeed_IsDeterministic()
        {
            var a = _engine.Synthesize("Repeatable output.", "en", _voice, P(seed: 7));
            var b = _engine.Synthesize("Repeatable output.", "en", _voice, P(seed: 7));
            Assert.AreEqual(a.Length, b.Length);
            for (int i = 0; i < a.Length; i += 97) Assert.AreEqual(a[i], b[i], 1e-4f);
        }

        [Test]
        public void Synthesize_LongText_IsChunked()
        {
            string text = string.Concat(System.Linq.Enumerable.Repeat("Keep the load close to your body while you walk. ", 8));
            int chunks = 0;
            foreach (var c in _engine.SynthesizeChunks(text, "en", _voice, P())) { chunks++; Assert.Greater(c.Length, 0); }
            Assert.Greater(chunks, 1);
        }

        [Test]
        public void Speed_ChangesDuration()
        {
            var slow = _engine.Synthesize("This sentence checks speaking speed.", "en", _voice, new SynthesisParams { Steps = 3, Speed = 0.8f, Seed = 1 });
            var fast = _engine.Synthesize("This sentence checks speaking speed.", "en", _voice, new SynthesisParams { Steps = 3, Speed = 1.4f, Seed = 1 });
            Assert.Greater(slow.Length, fast.Length);
        }

        [Test]
        public void AllBuiltInVoices_Load()
        {
            foreach (var v in ModelLocator.BuiltInVoices)
            {
                string path = ModelLocator.VoicePath(Root, v);
                if (!File.Exists(path)) continue;
                var style = VoiceStyle.FromFile(path);
                Assert.Greater(style.Ttl.Length, 0, v);
                Assert.Greater(style.Dp.Length, 0, v);
            }
        }
    }
}
