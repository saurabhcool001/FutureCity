# Third-party notices

## Supertonic (inference code)
Portions of `Runtime/Core/TextPreprocessor.cs` and `Runtime/Core/SupertonicEngine.cs` are adapted from the
Supertonic C# reference implementation — MIT License, Copyright (c) 2025–2026 Supertone Inc.
https://github.com/supertone-inc/supertonic

## Supertonic 3 model weights (NOT included in this package)
Downloaded separately into StreamingAssets. Licensed under the OpenRAIL-M license by Supertone Inc. —
review its use-based restrictions before shipping (a copy is downloaded alongside the models as `LICENSE`).
https://huggingface.co/supertone-oss-archive/supertonic-3

## ONNX Runtime for Unity (dependency)
com.github.asus4.onnxruntime — MIT License, Koki Ibukuro. Bundles Microsoft ONNX Runtime (MIT).
https://github.com/asus4/onnxruntime-unity

## Newtonsoft.Json (dependency)
com.unity.nuget.newtonsoft-json — MIT License.
