# License

This package is part of the FutureCity project. Choose a licence (for example MIT) before publishing it.

Third-party components keep their own licences. See THIRD_PARTY_NOTICES.md.
The Supertonic 3 model weights are NOT included in this package and are licensed separately under OpenRAIL-M.
