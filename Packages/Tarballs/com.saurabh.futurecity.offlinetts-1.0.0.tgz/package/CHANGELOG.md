# Changelog
All notable changes to FutureCity Offline TTS. Versions follow [Semantic Versioning](https://semver.org/).

## [1.0.0] - 2026-11-17
First FutureCity release, trimmed to what the project needs.

### Included
- On-device speech: Supertonic 3 engine on ONNX Runtime, `OfflineTTS` service, `TTSSettings`, model locator,
  memory and disk cache, sentence streaming.
- `TTSSpeaker`: speaks through an AudioSource, with per-word events for highlighting.
- `TTSWordHighlighter` (TextMeshPro): highlights the word being spoken. `TTSOverride` changes the look or voice per object.
- Baked clips: `TTSClipTiming` / `TTSClipTimingLibrary` keep highlighting working for pre-generated WAVs.
- Editor: model download, settings asset, "Add TTS Service To Scene", Voice-over Baker, timing library repair,
  diagnostics without Play mode, first-run project setup (ONNX Runtime registry and dependency).

### Removed (compared with the package this was based on)
- XR test panels and test scenes, test bench, video narration, subtitle display, auto highlight, batch speaker
  setup, the recorded-voice timing generator, samples, tests and the documentation builder.
- Automatic removal of earlier package names. Remove any older copy of this package before installing.
