# FutureCity Offline TTS — Documentation

Offline neural text-to-speech (Supertonic 3 on ONNX Runtime) trimmed for FutureCity: AI and narrator speech,
spoken-word highlighting in TextMeshPro, and pre-generated (baked) voice-over.

## 1. Install
1. Package Manager ▸ **+** ▸ **Add package from tarball…** and pick the `.tgz`.
2. On first import the package adds the `com.github.asus4` npm registry and `com.github.asus4.onnxruntime` to
   `Packages/manifest.json`, then the Package Manager resolves. Until ONNX Runtime is installed the rest of the
   package doesn't compile (define constraint `FUTURECITY_ORT`), so there are no errors in between.
3. If setup was skipped: **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Setup ▸ Repair Project Setup**.
4. Remove any older copy of this package first: it uses the same script IDs.

## 2. Models
**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Download Supertonic 3 Models** saves the model files to
`Assets/StreamingAssets/Supertonic` (with their OpenRAIL-M `LICENSE`). They ship inside your build.

## 3. Settings and service
- **Create or Locate Settings Asset** makes (or finds) the `TTSSettings` asset: default voice and language,
  steps (quality vs speed), threads, caching, the global word-highlight look, and timing libraries for baked clips.
- **Add TTS Service To Scene** adds the `OfflineTTS` service. It loads the model once and serves every speaker.
  `OfflineTTS.GetOrCreate()` also makes one at runtime if none exists.

## 4. Speaking
Add `TTSSpeaker` (it needs an AudioSource). Set its voice (F1–F5, M1–M5), language and speed.

```csharp
speaker.Speak("Good evening, council.");                 // fire and forget
bool finished = await speaker.SpeakAsync(line, ct);      // false if interrupted or cancelled
speaker.Stop();
```

Events: `onSpeechStarted`, `onSpeechFinished`, `onWordChanged`, and the static `TTSSpeaker.AnyLineStarted`,
`AnyLineEnded`, `AnyWordChanged`. Long text is spoken sentence by sentence while the rest is generated.
`PrewarmAsync(lines)` generates lines ahead of time so they start instantly.

## 5. Word highlighting
Add `TTSWordHighlighter` to a TextMeshPro text (UI or 3D). **Listen To**:
- **Any Speaker With Matching Text**: follows whoever says what the text shows (no setup).
- **Specific Speakers**: only the listed speakers.
- **Bound From Code**: only the speaker passed to `Bind(speaker)`.

The look (colour, pop, zoom) comes from the settings asset. A `TTSOverride` on an object or its parents changes
the look or the speech settings for that part of the scene, for example to switch highlighting off.

## 6. Baked voice-over
**FutureCity ▸ Plugins ▸ OfflineTTS ▸ Voice-over Baker** turns lines into WAV files plus `TTSClipTiming` assets
(word timings). When a speaker's AudioSource plays a baked clip, highlighting follows it like live speech.
**Repair Timing Library** relinks timing assets to the settings asset. This also runs before every build.

Bake fixed lines (for example every line CIVIC can say) so headsets don't spend time generating them.

## 7. Performance on headsets
- Lower **Mobile Steps** in the settings for faster generation; 4–6 is a good start on Quest.
- Keep **Disk Cache** on. Repeated lines are generated once per device.
- Bake or prewarm the lines you know in advance.

## 8. Troubleshooting
- **Nothing compiles / menu missing:** ONNX Runtime isn't installed yet. Run **Setup ▸ Repair Project Setup**.
- **No sound:** check the models exist (Download Supertonic 3 Models) and the scene has an `OfflineTTS` service.
- **Highlighting doesn't follow:** the text must contain the spoken words. Or set **Listen To** to *Bound From
  Code* and call `Bind(speaker)`.
- **Invisible text:** **Setup ▸ Import TextMeshPro Essentials**.
