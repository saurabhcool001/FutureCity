// FutureCity Offline TTS
// Android stores StreamingAssets inside the APK/OBB (not a real folder), and ONNX Runtime needs real file
// paths, so on Android the model files are copied once to persistentDataPath. Everywhere else they are
// read in place.

using System;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace SaurabhFutureCity.OfflineTTS
{
    public static class ModelLocator
    {
        public const string OnnxSubfolder = "onnx";
        public const string VoiceSubfolder = "voice_styles";
        public static readonly string[] BuiltInVoices = { "F1", "F2", "F3", "F4", "F5", "M1", "M2", "M3", "M4", "M5" };

        /// <summary>Returns a real on-disk root folder containing onnx/ and voice_styles/. Main thread only.</summary>
        public static async Task<string> ResolveRootAsync(TTSSettings s, IProgress<float> progress = null)
        {
            switch (s.location)
            {
                case ModelLocation.AbsolutePath:
                    return s.modelFolder;
                case ModelLocation.PersistentDataPath:
                    return Path.Combine(Application.persistentDataPath, s.modelFolder);
            }

            string source = Path.Combine(Application.streamingAssetsPath, s.modelFolder);
            if (!NeedsUnpacking) return source;

            string target = Path.Combine(Application.persistentDataPath, s.modelFolder, s.modelVersion);
            string marker = Path.Combine(target, ".complete");
            if (File.Exists(marker)) return target;

            // Files to unpack: model files + any voice listed in the manifest (written by the editor at build time),
            // falling back to the 10 built-in voices.
            var voices = await ReadVoiceManifestAsync(source) ?? BuiltInVoices;
            int total = SupertonicEngine.RequiredFiles.Length + voices.Length, done = 0;

            foreach (var f in SupertonicEngine.RequiredFiles)
            {
                await CopyAsync($"{source}/{OnnxSubfolder}/{f}", Path.Combine(target, OnnxSubfolder, f), required: true);
                progress?.Report(++done / (float)total);
            }
            foreach (var v in voices)
            {
                await CopyAsync($"{source}/{VoiceSubfolder}/{v}.json", Path.Combine(target, VoiceSubfolder, v + ".json"), required: false);
                progress?.Report(++done / (float)total);
            }

            File.WriteAllText(marker, DateTime.UtcNow.ToString("o"));
            return target;
        }

        static bool NeedsUnpacking =>
            Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.WebGLPlayer;

        public static string OnnxDir(string root) => Path.Combine(root, OnnxSubfolder);
        public static string VoicePath(string root, string voice) => Path.Combine(root, VoiceSubfolder, voice + ".json");

        static async Task<string[]> ReadVoiceManifestAsync(string source)
        {
            using (var req = UnityWebRequest.Get($"{source}/{VoiceSubfolder}/voices.txt"))
            {
                await SendAsync(req);
                if (req.result != UnityWebRequest.Result.Success) return null;
                var lines = req.downloadHandler.text.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                return lines.Length > 0 ? lines : null;
            }
        }

        static async Task CopyAsync(string url, string dest, bool required)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(dest));
            string tmp = dest + ".tmp";
            using (var req = new UnityWebRequest(url, UnityWebRequest.kHttpVerbGET))
            {
                req.downloadHandler = new DownloadHandlerFile(tmp) { removeFileOnAbort = true };
                await SendAsync(req);
                if (req.result != UnityWebRequest.Result.Success)
                {
                    if (required) throw new IOException($"[OfflineTTS] Could not unpack {url}: {req.error}");
                    return;
                }
            }
            if (File.Exists(dest)) File.Delete(dest);
            File.Move(tmp, dest);
        }

        static Task SendAsync(UnityWebRequest req)
        {
            var tcs = new TaskCompletionSource<bool>();
            req.SendWebRequest().completed += _ => tcs.TrySetResult(true);
            return tcs.Task;
        }
    }
}
