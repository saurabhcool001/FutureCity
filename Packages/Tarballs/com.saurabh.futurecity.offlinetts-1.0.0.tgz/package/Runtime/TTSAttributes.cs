// FutureCity Offline TTS — Inspector dropdown attributes (drawn by the Editor assembly).
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS
{
    /// <summary>Shows a string field as a voice dropdown (Female F1–F5, Male M1–M5, plus any extra voice files).</summary>
    public class TTSVoiceAttribute : PropertyAttribute
    {
        /// <summary>Adds a "(Use default)" entry that stores an empty string.</summary>
        public readonly bool allowDefault;
        public TTSVoiceAttribute(bool allowDefault = false) => this.allowDefault = allowDefault;
    }

    /// <summary>Shows a string field as a language dropdown ("English (en)", …).</summary>
    public class TTSLanguageAttribute : PropertyAttribute
    {
        /// <summary>Adds a "(Use default)" entry that stores an empty string.</summary>
        public readonly bool allowDefault;
        public TTSLanguageAttribute(bool allowDefault = false) => this.allowDefault = allowDefault;
    }
}
