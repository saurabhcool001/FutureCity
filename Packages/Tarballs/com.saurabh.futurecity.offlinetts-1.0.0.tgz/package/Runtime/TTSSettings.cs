// FutureCity Offline TTS
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS
{
    public enum ModelLocation
    {
        /// <summary>Models shipped in Assets/StreamingAssets/&lt;folder&gt;. On Android they are unpacked once to persistentDataPath.</summary>
        StreamingAssets,
        /// <summary>Models already present in Application.persistentDataPath/&lt;folder&gt; (e.g. downloaded by your own content system).</summary>
        PersistentDataPath,
        /// <summary>An absolute folder on disk (PC tools, kiosks, editor-only workflows).</summary>
        AbsolutePath,
    }

    [CreateAssetMenu(menuName = "FutureCity/Plugins/OfflineTTS/Settings", fileName = "OfflineTTSSettings")]
    public class TTSSettings : ScriptableObject
    {
        [Header("Model files")]
        [Tooltip("Where the Supertonic model files are loaded from at runtime.\n\n" +
                 "• StreamingAssets (recommended): files in Assets/StreamingAssets/<Model Folder>. Shipped inside the build. " +
                 "On Android/Quest they are copied once to persistent storage on first launch.\n" +
                 "• PersistentDataPath: files you download/copy yourself to Application.persistentDataPath/<Model Folder> " +
                 "(keeps the APK small).\n" +
                 "• AbsolutePath: <Model Folder> is a full disk path (PC tools, kiosks).")]
        public ModelLocation location = ModelLocation.StreamingAssets;

        [Tooltip("Folder that contains the 'onnx' and 'voice_styles' sub-folders.\n" +
                 "Relative to StreamingAssets / persistentDataPath, or a full path when Location = AbsolutePath.\n" +
                 "Default: Supertonic  →  Assets/StreamingAssets/Supertonic")]
        public string modelFolder = "Supertonic";

        [Tooltip("A label for the model files you ship. Change it whenever you replace the model files so that:\n" +
                 "• Android extracts the new files again, and\n" +
                 "• the on-device audio cache from the old model is ignored.")]
        public string modelVersion = "supertonic-3";

        [Header("Defaults")]
        [Tooltip("Voice used when a speaker or request doesn't specify one.\nFemale: F1–F5, Male: M1–M5.")]
        [TTSVoice]
        public string defaultVoice = "F1";

        [Tooltip("Language used when a speaker or request doesn't specify one. The text must be written in this language.")]
        [TTSLanguage]
        public string defaultLanguage = "en";

        [Tooltip("Quality on PC / desktop: number of denoising steps per sentence.\n" +
                 "8 = reference quality. Higher is slightly cleaner but slower; lower is faster but can sound rougher.\n" +
                 "Generation time grows roughly linearly with steps.")]
        [Range(1, 16)] public int steps = 8;

        [Tooltip("Speaking rate. 1.0 = model's natural pace, 1.05 = reference default, < 1 slower, > 1 faster.\n" +
                 "Changes timing only, not pitch.")]
        [Range(0.5f, 2f)] public float speed = 1.05f;

        [Tooltip("Pause inserted between sentences when long text is split into chunks, in seconds.")]
        [Range(0f, 1.5f)] public float chunkSilence = 0.3f;

        [Header("Performance")]
        [Tooltip("CPU threads used for speech generation on PC / Editor.\n0 = automatic (all cores). Usually leave at 0.")]
        public int desktopThreads = 0;

        [Tooltip("CPU threads used on Android / standalone headsets (Quest, Pico).\n" +
                 "The headset also needs CPU for rendering: 2–3 keeps frame rate stable, 4 generates faster but may drop frames.")]
        public int mobileThreads = 3;

        [Tooltip("Quality steps on Android / standalone headsets (overrides 'Steps' there).\n" +
                 "5 is a good balance on Quest; 3–4 for faster replies; 0 = use the same value as 'Steps'.")]
        [Range(0, 16)] public int mobileSteps = 5;

        [Tooltip("Experimental: use Android's NNAPI hardware acceleration. Falls back to CPU if unavailable.\n" +
                 "On Quest the CPU path is usually as fast or faster — leave off unless you've measured a gain.")]
        public bool useNnapiOnAndroid = false;

        [Tooltip("After loading, generate one tiny phrase in the background so the first real line isn't slower than the rest.\n" +
                 "Adds a moment to load time; recommended.")]
        public bool warmUpOnLoad = true;

        [Header("Caching")]
        [Tooltip("How many generated lines to keep in memory. Repeating a cached line plays instantly with no CPU cost.\n" +
                 "Each entry holds the line's audio (≈ 0.17 MB per second of speech). 0 = disable memory cache.")]
        public int memoryCacheEntries = 64;

        [Tooltip("Also save generated lines as WAV files in persistentDataPath/TTSCache so they're instant on the next launch.\n" +
                 "Cache keys include text, voice, language, steps, speed and seed — change any of them and the line is regenerated.")]
        public bool diskCache = true;

        [Header("Word Highlight (global defaults)")]
        [Tooltip("Default look of the 'current word' highlight in TextMeshPro texts that have a TTS Word Highlighter.\n" +
                 "Override any of these on specific objects (e.g. a few cards) with a TTS Override component.")]
        public TTSHighlightSettings wordHighlight = TTSHighlightSettings.Default;

        [Header("Baked & recorded clips")]
        [Tooltip("Word timings for baked TTS WAVs and human recordings. While such a clip plays on an AudioSource that has a " +
                 "TTS Speaker, the spoken word is highlighted just like live TTS.\n" +
                 "The Voice-over Baker and Word Timing Generator create a library and add it here automatically.")]
        public TTSClipTimingLibrary[] timingLibraries = new TTSClipTimingLibrary[0];

        public SynthesisParams DefaultParams
        {
            get
            {
                var p = SynthesisParams.Default;
                p.Steps = (Application.isMobilePlatform && mobileSteps > 0) ? mobileSteps : steps;
                p.Speed = speed;
                p.ChunkSilence = chunkSilence;
                return p;
            }
        }

        public EngineOptions EngineOptions => new EngineOptions
        {
            Threads = Application.isMobilePlatform ? mobileThreads : desktopThreads,
            UseNnapi = useNnapiOnAndroid && Application.platform == RuntimePlatform.Android,
            DisableThreadSpinning = true,
        };

        static TTSSettings _loaded;
        static float _nextScanTime;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { _loaded = null; _nextScanTime = 0f; }

        /// <summary>
        /// The project's settings asset if it's loaded (in builds it's preloaded automatically at build time).
        /// Prefers one named "OfflineTTSSettings". Null if none is loaded.
        /// </summary>
        public static TTSSettings FindLoaded()
        {
            if (_loaded != null) return _loaded;
            // Scanning loaded objects is expensive: when nothing was found, don't scan again for a second.
            if (Time.realtimeSinceStartup < _nextScanTime) return null;
            _nextScanTime = Time.realtimeSinceStartup + 1f;
            var all = Resources.FindObjectsOfTypeAll<TTSSettings>();
            foreach (var s in all) if (s != null && s.name == "OfflineTTSSettings") return _loaded = s;
            foreach (var s in all) if (s != null && !s.name.EndsWith("(default)")) return _loaded = s;
            return null;
        }

        public static TTSSettings CreateDefault()
        {
            var s = CreateInstance<TTSSettings>();
            s.name = "OfflineTTSSettings (default)";
            return s;
        }
    }
}
