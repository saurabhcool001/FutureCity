// FutureCity Offline TTS — a group of clip word timings (referenced by the settings asset).
using System.Collections.Generic;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS
{
    [CreateAssetMenu(menuName = "FutureCity/Plugins/OfflineTTS/Clip Timing Library", fileName = "TTSTimingLibrary")]
    public class TTSClipTimingLibrary : ScriptableObject
    {
        [Tooltip("Clip timings available at runtime. The Voice-over Baker and Word Timing Generator add entries automatically.")]
        public List<TTSClipTiming> timings = new List<TTSClipTiming>();

        public void Add(TTSClipTiming timing)
        {
            if (timing == null) return;
            timings.RemoveAll(t => t == null || (t != timing && t.clip != null && t.clip == timing.clip));
            if (!timings.Contains(timing)) timings.Add(timing);
        }
    }
}
