// FutureCity Offline TTS — highlights the word currently being spoken in a TextMeshPro text.
//
// Add it to any TextMeshPro (UI or 3D) text. While a TTS Speaker says the same text, the current word
// is recoloured and pops/zooms in. The look comes from the settings asset (Word Highlight section) and
// can be changed per object with a TTS Override component (e.g. turn it off on a few cards only).
//
// Spoken words are matched to on-screen words in order, ignoring punctuation and case, so it keeps
// working when the screen shows rich-text formatting. Words that are spoken differently from what is
// shown (e.g. "5 kg" spoken as "five kilograms") simply aren't highlighted; following words re-sync.

using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS
{
    [RequireComponent(typeof(TMP_Text))]
    [DisallowMultipleComponent]
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/TTS Word Highlighter (TextMeshPro)")]
    public class TTSWordHighlighter : MonoBehaviour
    {
        public enum ListenMode
        {
            /// <summary>Any TTS Speaker whose spoken line matches this text (no setup needed).</summary>
            AnySpeakerWithMatchingText,
            /// <summary>Only the speakers listed in Speakers.</summary>
            SpecificSpeakers,
            /// <summary>Only the speaker given to Bind() from code (e.g. a dialogue integration).</summary>
            BoundFromCode,
        }

        [Tooltip("Which speakers drive this highlighter.\n" +
                 "• Any Speaker With Matching Text: whoever is saying what this text shows (easiest; no setup).\n" +
                 "• Specific Speakers: only the speakers in the list below.\n" +
                 "• Bound From Code: only the speaker passed to Bind() (used by dialogue integrations).")]
        public ListenMode listenTo = ListenMode.AnySpeakerWithMatchingText;

        [Tooltip("Speakers to follow when Listen To = Specific Speakers.")]
        public TTSSpeaker[] speakers;

        [Tooltip("For 'Any Speaker With Matching Text': how many of the spoken words must be found in this text (0–1) " +
                 "before the highlighter follows that speaker. Lower it if your screen text differs a lot from the spoken text.")]
        [Range(0.1f, 1f)] public float minimumMatch = 0.6f;

        [Tooltip("Log what this highlighter does: which speaker it follows and why, and how many spoken words it found in " +
                 "this text (0 matched words = the clip's text differs from what's on screen).")]
        public bool debugLog = false;

        [Header("Look — this text only")]
        [Tooltip("Customise the highlight for THIS text. Tick a setting to override it here; unticked settings use the " +
                 "value from TTS Override components above this object, or the global settings asset (Word Highlight).\n" +
                 "Order (last wins): settings asset → TTS Override on parents → these values.")]
        public TTSHighlightOverrides look = new TTSHighlightOverrides();

        /// <summary>The look actually used for this text: global settings, then parent TTS Overrides, then <see cref="look"/>.</summary>
        public TTSHighlightSettings EffectiveSettings
        {
            get
            {
                var s = TTSOverride.ResolveHighlight(transform);
                look?.Apply(ref s);
                return s;
            }
        }

        TMP_Text _text;
        TTSSpeaker _speaker;
        TTSSpeaker _bound;

        readonly List<(int first, int last, string norm)> _displayWords = new List<(int, int, string)>();
        int[] _map = System.Array.Empty<int>();          // spoken word index -> display word index (-1 = none)
        Vector3[][] _baseVertices;
        Color32[][] _baseColors;
        bool _meshDirty = true, _mapDirty = true, _modified, _caching;

        float _previewUntil = -1f, _previewStart, _previewWordSeconds = 0.35f;
        int _currentDisplayWord = -1;
        int _maxSpokenDisplayWord = -1;
        float _wordChangeTime;

        /// <summary>The speaker this highlighter is currently following (null if none).</summary>
        public TTSSpeaker ActiveSpeaker => _speaker;

        void Awake() => _text = GetComponent<TMP_Text>();

        void OnEnable()
        {
            TMPro_EventManager.TEXT_CHANGED_EVENT.Add(OnTextChanged);
            TTSSpeaker.AnyLineStarted += OnAnyLineStarted;
            TTSSpeaker.AnyLineEnded += OnAnyLineEnded;
            _meshDirty = _mapDirty = true;
        }

        void OnDisable()
        {
            TMPro_EventManager.TEXT_CHANGED_EVENT.Remove(OnTextChanged);
            TTSSpeaker.AnyLineStarted -= OnAnyLineStarted;
            TTSSpeaker.AnyLineEnded -= OnAnyLineEnded;
            Restore();
            _speaker = null;
        }

        /// <summary>
        /// Follow this speaker (pass null to stop). Used by integrations that know who is talking,
        /// e.g. a dialogue box binding the current NPC. Works in every Listen To mode.
        /// </summary>
        public void Bind(TTSSpeaker speaker)
        {
            _bound = speaker;
            if (speaker == null) { if (_speaker != null && listenTo == ListenMode.BoundFromCode) Follow(null); return; }
            Follow(speaker);
        }

        void OnAnyLineStarted(TTSSpeaker speaker, string text)
        {
            bool accept = speaker == _bound
                || (listenTo == ListenMode.SpecificSpeakers && speakers != null && System.Array.IndexOf(speakers, speaker) >= 0)
                || (listenTo == ListenMode.AnySpeakerWithMatchingText && MatchRatio(text) >= minimumMatch);
            if (accept)
            {
                Log($"Following '{speaker.name}' for \"{Short(text)}\" " +
                    (speaker == _bound ? "(bound)" : $"({TTSText.MatchRatio(text, _text != null ? _text.text : ""):P0} word match)"));
                Follow(speaker);
            }
            else if (debugLog && listenTo == ListenMode.AnySpeakerWithMatchingText)
                Log($"Ignored '{speaker.name}': only {MatchRatio(text):P0} of \"{Short(text)}\" is in this text (needs {minimumMatch:P0}).");
        }

        void OnAnyLineEnded(TTSSpeaker speaker)
        {
            if (speaker == _speaker) { Restore(); _currentDisplayWord = -1; }
        }

        void Follow(TTSSpeaker speaker)
        {
            _speaker = speaker;
            _mapDirty = true;
            _currentDisplayWord = -1;
            _maxSpokenDisplayWord = -1;
            Restore();
        }

        void OnTextChanged(Object obj)
        {
            if (obj != _text || _caching) return;
            _meshDirty = true;
            _mapDirty = true;
        }

        /// <summary>
        /// Play mode: walk through this text's words without speech so you can tune the look
        /// (also available as a button in the Inspector).
        /// </summary>
        public void PreviewHighlight(float secondsPerWord = 0.35f)
        {
            if (_text == null) _text = GetComponent<TMP_Text>();
            _meshDirty = true;
            CacheMesh();
            CollectDisplayWords();
            _previewWordSeconds = Mathf.Max(0.05f, secondsPerWord);
            _previewStart = Time.unscaledTime;
            _previewUntil = _previewStart + _displayWords.Count * _previewWordSeconds;
            _currentDisplayWord = -1;
            _maxSpokenDisplayWord = -1;
        }

        public void StopPreview() { _previewUntil = -1f; Restore(); }

        public bool IsPreviewing => _previewUntil > 0f;

        void LateUpdate()
        {
            if (_text == null) return;

            if (_previewUntil > 0f)
            {
                if (Time.unscaledTime >= _previewUntil) { StopPreview(); return; }
                var fx = EffectiveSettings;
                if (!fx.enabled) { Restore(); return; }
                if (_meshDirty) { CacheMesh(); CollectDisplayWords(); }
                int w = (int)((Time.unscaledTime - _previewStart) / _previewWordSeconds);
                if (w != _currentDisplayWord)
                {
                    _currentDisplayWord = w;
                    _wordChangeTime = Time.unscaledTime;
                    if (w > _maxSpokenDisplayWord) _maxSpokenDisplayWord = w;
                }
                Apply(fx);
                return;
            }

            bool speaking = _speaker != null && _speaker.IsSpeaking && _speaker.CurrentLineText != null;
            if (!speaking) { Restore(); return; }

            var settings = EffectiveSettings;
            if (!settings.enabled) { Restore(); return; }

            if (_meshDirty) CacheMesh();
            if (_mapDirty) BuildMap();

            int spoken = _speaker.CurrentWordIndex;
            int display = spoken >= 0 && spoken < _map.Length ? _map[spoken] : -1;
            if (display != _currentDisplayWord)
            {
                _currentDisplayWord = display;
                _wordChangeTime = Time.unscaledTime;
                if (display > _maxSpokenDisplayWord) _maxSpokenDisplayWord = display;
            }

            Apply(settings);
        }

        // ------------------------------------------------------------------ matching

        void CollectDisplayWords()
        {
            _displayWords.Clear();
            var info = _text.textInfo;
            int start = -1;
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i <= info.characterCount; i++)
            {
                char c = i < info.characterCount ? info.characterInfo[i].character : ' ';
                if (char.IsWhiteSpace(c) || c == '\u200B')
                {
                    if (start >= 0)
                    {
                        string norm = TTSText.NormalizeWord(sb.ToString());
                        if (norm.Length > 0) _displayWords.Add((start, i - 1, norm));
                        start = -1; sb.Clear();
                    }
                    continue;
                }
                if (start < 0) start = i;
                sb.Append(c);
            }
        }

        void BuildMap()
        {
            _mapDirty = false;
            CollectDisplayWords();
            var words = _speaker != null ? _speaker.CurrentLineWords : null;
            if (words == null || words.Count == 0) { _map = System.Array.Empty<int>(); return; }

            _map = new int[words.Count];
            int d = 0, matched = 0;
            for (int s = 0; s < words.Count; s++)
            {
                _map[s] = -1;
                string n = TTSText.NormalizeWord(words[s]);
                // Until the first word is found, search the whole text (there may be a prefix such as a speaker name);
                // after that, look a few words ahead so later words stay in order.
                int limit = matched == 0 ? _displayWords.Count : Mathf.Min(_displayWords.Count, d + 6);
                for (int k = d; k < limit; k++)
                {
                    if (_displayWords[k].norm == n) { _map[s] = k; d = k + 1; matched++; break; }
                }
            }
            if (matched == 0)
                Log($"None of the {words.Count} spoken words were found in this text, so nothing can be highlighted. " +
                    "The clip's text must use the same wording as the text on screen.");
            else
                Log($"Matched {matched} of {words.Count} spoken words to this text.");
        }

        float MatchRatio(string spokenText) => _text == null ? 0f : TTSText.MatchRatio(spokenText, _text.text);

        // ------------------------------------------------------------------ mesh effects

        void CacheMesh()
        {
            _meshDirty = false;
            var info = _text.textInfo;
            // Only force a rebuild when TMP hasn't generated this text's mesh yet. Forcing it every time the text
            // changes can make layout groups rebuild again, which re-fires TEXT_CHANGED → another rebuild … every frame.
            bool meshMissing = info == null || info.meshInfo == null || info.meshInfo.Length == 0 ||
                               (info.characterCount == 0 && !string.IsNullOrEmpty(_text.text));
            if (meshMissing)
            {
                _caching = true;
                try { _text.ForceMeshUpdate(); }   // fires TEXT_CHANGED; ignored while caching
                finally { _caching = false; }
                info = _text.textInfo;
            }
            _baseVertices = new Vector3[info.meshInfo.Length][];
            _baseColors = new Color32[info.meshInfo.Length][];
            for (int m = 0; m < info.meshInfo.Length; m++)
            {
                _baseVertices[m] = info.meshInfo[m].vertices != null ? (Vector3[])info.meshInfo[m].vertices.Clone() : null;
                _baseColors[m] = info.meshInfo[m].colors32 != null ? (Color32[])info.meshInfo[m].colors32.Clone() : null;
            }
            _modified = false;
        }

        void Restore()
        {
            if (!_modified || _text == null || _baseVertices == null) return;
            var info = _text.textInfo;
            for (int m = 0; m < info.meshInfo.Length && m < _baseVertices.Length; m++)
            {
                if (_baseVertices[m] != null && info.meshInfo[m].vertices != null && info.meshInfo[m].vertices.Length == _baseVertices[m].Length)
                    System.Array.Copy(_baseVertices[m], info.meshInfo[m].vertices, _baseVertices[m].Length);
                if (_baseColors[m] != null && info.meshInfo[m].colors32 != null && info.meshInfo[m].colors32.Length == _baseColors[m].Length)
                    System.Array.Copy(_baseColors[m], info.meshInfo[m].colors32, _baseColors[m].Length);
            }
            _text.UpdateVertexData(TMP_VertexDataUpdateFlags.Colors32 | TMP_VertexDataUpdateFlags.Vertices);
            _modified = false;
        }

        void Apply(TTSHighlightSettings s)
        {
            if (_baseVertices == null) return;
            var info = _text.textInfo;

            // Start from the untouched mesh every frame.
            for (int m = 0; m < info.meshInfo.Length && m < _baseVertices.Length; m++)
            {
                if (_baseVertices[m] == null || info.meshInfo[m].vertices == null || info.meshInfo[m].vertices.Length != _baseVertices[m].Length)
                {
                    _meshDirty = true; // TMP rebuilt the mesh under us; recache next frame
                    return;
                }
                System.Array.Copy(_baseVertices[m], info.meshInfo[m].vertices, _baseVertices[m].Length);
                System.Array.Copy(_baseColors[m], info.meshInfo[m].colors32, _baseColors[m].Length);
            }

            if (s.tintSpokenWords)
            {
                int lastSpoken = _currentDisplayWord >= 0 ? _currentDisplayWord - 1 : _maxSpokenDisplayWord;
                for (int w = 0; w <= lastSpoken && w < _displayWords.Count; w++)
                    Tint(info, _displayWords[w], s.spokenWordColor);
            }

            if (_currentDisplayWord >= 0 && _currentDisplayWord < _displayWords.Count)
            {
                var word = _displayWords[_currentDisplayWord];
                if (s.applyColor) Tint(info, word, s.highlightColor);
                Pop(info, word, s);
            }

            _text.UpdateVertexData(TMP_VertexDataUpdateFlags.Colors32 | TMP_VertexDataUpdateFlags.Vertices);
            _modified = true;
        }

        static void Tint(TMP_TextInfo info, (int first, int last, string norm) word, Color color)
        {
            for (int i = word.first; i <= word.last && i < info.characterCount; i++)
            {
                var ch = info.characterInfo[i];
                if (!ch.isVisible) continue;
                var colors = info.meshInfo[ch.materialReferenceIndex].colors32;
                Color32 c = color;
                for (int v = 0; v < 4; v++)
                {
                    c.a = colors[ch.vertexIndex + v].a; // keep fades / transparency
                    colors[ch.vertexIndex + v] = c;
                }
            }
        }

        void Pop(TMP_TextInfo info, (int first, int last, string norm) word, TTSHighlightSettings s)
        {
            float amount = PopAmount(s);
            if (amount <= 0.0001f) return;

            // Word bounds and size (centre of the whole word so it zooms as one piece).
            Vector3 min = new Vector3(float.MaxValue, float.MaxValue), max = new Vector3(float.MinValue, float.MinValue);
            float pointSize = 0f;
            for (int i = word.first; i <= word.last && i < info.characterCount; i++)
            {
                var ch = info.characterInfo[i];
                if (!ch.isVisible) continue;
                min = Vector3.Min(min, ch.bottomLeft);
                max = Vector3.Max(max, ch.topRight);
                pointSize = Mathf.Max(pointSize, ch.pointSize);
            }
            if (min.x == float.MaxValue) return;

            Vector3 centre = (min + max) * 0.5f;
            float scale = 1f + (s.zoomScale - 1f) * amount;
            Vector3 lift = new Vector3(0f, s.lift * pointSize * amount, 0f);

            for (int i = word.first; i <= word.last && i < info.characterCount; i++)
            {
                var ch = info.characterInfo[i];
                if (!ch.isVisible) continue;
                var verts = info.meshInfo[ch.materialReferenceIndex].vertices;
                for (int v = 0; v < 4; v++)
                {
                    int vi = ch.vertexIndex + v;
                    verts[vi] = centre + (verts[vi] - centre) * scale + lift;
                }
            }
        }

        /// <summary>0..1(+overshoot) zoom amount for the current word based on time since it started.</summary>
        float PopAmount(TTSHighlightSettings s)
        {
            float duration = Mathf.Max(0.02f, s.popDuration);
            float t = (Time.unscaledTime - _wordChangeTime) / duration;
            if (s.holdZoomWhileSpoken) return EaseOutBack(Mathf.Clamp01(t), s.bounce);

            // Pop up in one duration, settle back down in the next.
            if (t <= 1f) return EaseOutBack(t, s.bounce);
            return 1f - Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(t - 1f));
        }

        void Log(string message)
        {
            if (debugLog) Debug.Log($"[TTSWordHighlighter:{name}] {message}", this);
        }

        static string Short(string s) => string.IsNullOrEmpty(s) ? "" : (s.Length > 50 ? s.Substring(0, 50) + "…" : s);

        static float EaseOutBack(float t, float bounce)
        {
            float c1 = 1.70158f * bounce;
            float c3 = c1 + 1f;
            float x = t - 1f;
            return 1f + c3 * x * x * x + c1 * x * x;
        }
    }
}
