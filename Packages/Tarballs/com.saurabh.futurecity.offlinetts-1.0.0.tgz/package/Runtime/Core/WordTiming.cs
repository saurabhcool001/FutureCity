// FutureCity Offline TTS — estimates when each word is spoken.
//
// The voice model produces audio for a whole sentence and doesn't report word timestamps, so word
// timing is estimated: the sentence's speaking time is shared out by word length (with extra room
// after commas and full stops), then each word boundary is snapped to the quietest moment nearby
// in the actual audio, which is where real word gaps are. Accurate enough for "follow along"
// highlighting; not meant for phoneme-level lip sync.

using System;
using System.Collections.Generic;

namespace SaurabhFutureCity.OfflineTTS
{
    /// <summary>When one word is spoken, in seconds from the start of its AudioClip.</summary>
    [Serializable]
    public struct TTSWordTiming
    {
        /// <summary>Index of the word in the whole line (as returned by <see cref="TTSText.Words"/>).</summary>
        public int wordIndex;
        public float start;
        public float end;

        public TTSWordTiming(int wordIndex, float start, float end)
        {
            this.wordIndex = wordIndex; this.start = start; this.end = end;
        }
    }

    public static class WordTimingEstimator
    {
        const float FrameSeconds = 0.01f;
        const float SnapWindowSeconds = 0.07f;

        /// <summary>
        /// Timings for one chunk (sentence) of audio.
        /// </summary>
        /// <param name="words">Words of this chunk, in order.</param>
        /// <param name="samples">Audio containing the chunk.</param>
        /// <param name="offset">First sample of the chunk inside <paramref name="samples"/>.</param>
        /// <param name="count">Number of samples belonging to the chunk.</param>
        /// <param name="firstWordIndex">Line-level index of the first word.</param>
        public static TTSWordTiming[] EstimateChunk(IList<string> words, float[] samples, int offset, int count,
                                                    int sampleRate, int firstWordIndex)
        {
            if (words == null || words.Count == 0 || samples == null || count <= 0) return Array.Empty<TTSWordTiming>();

            float[] rms = FrameRms(samples, offset, count, sampleRate, out int frameLen);
            float threshold = SilenceThreshold(rms);

            // Trim leading/trailing silence so words map onto actual speech.
            int firstLoud = 0, lastLoud = rms.Length - 1;
            while (firstLoud < rms.Length && rms[firstLoud] < threshold) firstLoud++;
            while (lastLoud > firstLoud && rms[lastLoud] < threshold) lastLoud--;
            if (firstLoud >= rms.Length) { firstLoud = 0; lastLoud = rms.Length - 1; }

            double baseTime = offset / (double)sampleRate;
            double speechStart = firstLoud * FrameSeconds;
            double speechEnd = Math.Max(speechStart + 0.05, (lastLoud + 1) * FrameSeconds);

            // Weights: word length plus a pause allowance after punctuation.
            var wordWeight = new double[words.Count];
            var gapWeight = new double[words.Count];
            double total = 0;
            for (int i = 0; i < words.Count; i++)
            {
                string w = words[i];
                int letters = 0;
                foreach (char c in w) if (char.IsLetterOrDigit(c)) letters++;
                wordWeight[i] = Math.Max(1, letters) + 0.6;          // + small per-word onset cost
                char last = w[w.Length - 1];
                gapWeight[i] = (i == words.Count - 1) ? 0
                    : (last == ',' || last == ';' || last == ':') ? 2.5
                    : (last == '.' || last == '!' || last == '?') ? 4.0
                    : 0.3;
                total += wordWeight[i] + gapWeight[i];
            }

            double secPerWeight = (speechEnd - speechStart) / total;
            var result = new TTSWordTiming[words.Count];
            double t = speechStart;
            for (int i = 0; i < words.Count; i++)
            {
                double start = t;
                double end = start + wordWeight[i] * secPerWeight;
                t = end + gapWeight[i] * secPerWeight;
                result[i] = new TTSWordTiming(firstWordIndex + i, (float)start, (float)end);
            }

            // Snap each boundary to the quietest frame nearby (real word gaps are quiet).
            int window = Math.Max(1, (int)(SnapWindowSeconds / FrameSeconds));
            for (int i = 0; i < result.Length - 1; i++)
            {
                double boundary = (result[i].end + result[i + 1].start) * 0.5;
                int centre = Clamp((int)(boundary / FrameSeconds), 0, rms.Length - 1);
                int best = centre;
                for (int f = Math.Max(0, centre - window); f <= Math.Min(rms.Length - 1, centre + window); f++)
                    if (rms[f] < rms[best]) best = f;
                float snapped = (float)(best * FrameSeconds + FrameSeconds * 0.5);
                float lo = result[i].start + 0.03f, hi = result[i + 1].end - 0.03f;
                if (lo < hi) snapped = Math.Max(lo, Math.Min(hi, snapped));
                result[i].end = snapped;
                result[i + 1].start = snapped;
            }

            for (int i = 0; i < result.Length; i++)
            {
                result[i].start += (float)baseTime;
                result[i].end += (float)baseTime;
            }
            return result;
        }

        /// <summary>
        /// Timings for a whole line of audio (several sentences joined with silence, e.g. a cached line).
        /// Sentence boundaries are found from the inserted silences, then each sentence is estimated separately.
        /// </summary>
        public static TTSWordTiming[] EstimateLine(string text, float[] samples, int sampleRate,
                                                   float chunkSilence, int maxChunkLength)
        {
            if (samples == null || samples.Length == 0) return Array.Empty<TTSWordTiming>();
            var chunks = TextPreprocessor.Chunk(text, maxChunkLength);
            if (chunks.Count <= 1 || chunkSilence <= 0.05f)
            {
                var all = TTSText.Words(text);
                return EstimateChunk(all, samples, 0, samples.Length, sampleRate, 0);
            }

            float[] rms = FrameRms(samples, 0, samples.Length, sampleRate, out _);
            float threshold = SilenceThreshold(rms);
            int minRun = Math.Max(3, (int)(chunkSilence * 0.6f / FrameSeconds));

            // Silent runs long enough to be the gaps inserted between sentences.
            var runs = new List<(int start, int length)>();
            int runStart = -1;
            for (int f = 0; f <= rms.Length; f++)
            {
                bool silent = f < rms.Length && rms[f] < threshold;
                if (silent && runStart < 0) runStart = f;
                else if (!silent && runStart >= 0)
                {
                    if (f - runStart >= minRun && runStart > 0 && f < rms.Length) runs.Add((runStart, f - runStart));
                    runStart = -1;
                }
            }

            var result = new List<TTSWordTiming>();
            int wordIndex = 0;
            if (runs.Count >= chunks.Count - 1)
            {
                runs.Sort((a, b) => b.length.CompareTo(a.length));
                var cuts = runs.GetRange(0, chunks.Count - 1);
                cuts.Sort((a, b) => a.start.CompareTo(b.start));

                int segStart = 0;
                for (int c = 0; c < chunks.Count; c++)
                {
                    int segEnd = c < cuts.Count
                        ? (int)((cuts[c].start + cuts[c].length * 0.5f) * FrameSeconds * sampleRate)
                        : samples.Length;
                    segEnd = Clamp(segEnd, segStart + 1, samples.Length);
                    var words = TTSText.Words(chunks[c]);
                    result.AddRange(EstimateChunk(words, samples, segStart, segEnd - segStart, sampleRate, wordIndex));
                    wordIndex += words.Count;
                    segStart = segEnd;
                }
                return result.ToArray();
            }

            // Couldn't find the sentence gaps: estimate the whole line in one go.
            return EstimateChunk(TTSText.Words(text), samples, 0, samples.Length, sampleRate, 0);
        }

        /// <summary>Index into <paramref name="timings"/> of the word being spoken at <paramref name="time"/>, or -1.</summary>
        public static int FindWordAt(TTSWordTiming[] timings, float time)
        {
            if (timings == null || timings.Length == 0) return -1;
            if (time < timings[0].start) return -1;
            int lo = 0, hi = timings.Length - 1;
            while (lo < hi)
            {
                int mid = (lo + hi + 1) / 2;
                if (timings[mid].start <= time) lo = mid; else hi = mid - 1;
            }
            return time <= timings[lo].end + 0.15f ? lo : -1;
        }

        static float[] FrameRms(float[] samples, int offset, int count, int sampleRate, out int frameLen)
        {
            frameLen = Math.Max(1, (int)(sampleRate * FrameSeconds));
            int frames = Math.Max(1, (count + frameLen - 1) / frameLen);
            var rms = new float[frames];
            for (int f = 0; f < frames; f++)
            {
                int a = offset + f * frameLen, b = Math.Min(offset + count, a + frameLen);
                double sum = 0;
                for (int i = a; i < b; i++) sum += samples[i] * samples[i];
                rms[f] = b > a ? (float)Math.Sqrt(sum / (b - a)) : 0f;
            }
            return rms;
        }

        static float SilenceThreshold(float[] rms)
        {
            var sorted = (float[])rms.Clone();
            Array.Sort(sorted);
            float loud = sorted[(int)(sorted.Length * 0.9f)];
            return Math.Max(0.004f, loud * 0.08f);
        }

        static int Clamp(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);
    }
}
