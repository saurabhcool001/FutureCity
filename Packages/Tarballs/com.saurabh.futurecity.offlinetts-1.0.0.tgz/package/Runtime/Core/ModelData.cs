// FutureCity Offline TTS
// Loaders for Supertonic model metadata: tts.json, unicode_indexer.json and voice style JSON files.

using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SaurabhFutureCity.OfflineTTS
{
    /// <summary>Acoustic config read from onnx/tts.json.</summary>
    public sealed class ModelConfig
    {
        public int SampleRate;
        public int BaseChunkSize;
        public int ChunkCompressFactor;
        public int LatentDim;

        public static ModelConfig FromJson(string json)
        {
            var root = JObject.Parse(json);
            return new ModelConfig
            {
                SampleRate = (int)root["ae"]["sample_rate"],
                BaseChunkSize = (int)root["ae"]["base_chunk_size"],
                ChunkCompressFactor = (int)root["ttl"]["chunk_compress_factor"],
                LatentDim = (int)root["ttl"]["latent_dim"],
            };
        }
    }

    /// <summary>Maps UTF-16 code units to model token ids (onnx/unicode_indexer.json).</summary>
    public sealed class UnicodeIndexer
    {
        readonly long[] _table;

        public UnicodeIndexer(long[] table) => _table = table ?? throw new ArgumentNullException(nameof(table));

        public static UnicodeIndexer FromJson(string json) => new UnicodeIndexer(JsonConvert.DeserializeObject<long[]>(json));

        /// <summary>Encodes prepared text (already wrapped in language tags). Unknown characters map to 0.</summary>
        public long[] Encode(string preparedText)
        {
            var ids = new long[preparedText.Length];
            for (int i = 0; i < preparedText.Length; i++)
            {
                int c = preparedText[i];
                ids[i] = c < _table.Length ? _table[c] : 0;
            }
            return ids;
        }
    }

    /// <summary>A speaker identity (style vectors). Supertonic ships M1–M5 and F1–F5.</summary>
    [Serializable]
    public sealed class VoiceStyle
    {
        public string Name;
        public float[] Ttl;
        public long[] TtlShape;
        public float[] Dp;
        public long[] DpShape;

        public static VoiceStyle FromJson(string name, string json)
        {
            var root = JObject.Parse(json);
            var style = new VoiceStyle { Name = name };
            (style.Ttl, style.TtlShape) = ReadTensor(root["style_ttl"]);
            (style.Dp, style.DpShape) = ReadTensor(root["style_dp"]);
            return style;
        }

        public static VoiceStyle FromFile(string path) =>
            FromJson(Path.GetFileNameWithoutExtension(path), File.ReadAllText(path));

        /// <summary>
        /// Linear blend between two voices (t = 0 → a, t = 1 → b). Handy for creating extra
        /// distinct NPC voices from the 10 presets without any extra model data.
        /// </summary>
        public static VoiceStyle Blend(VoiceStyle a, VoiceStyle b, float t, string name = null)
        {
            if (a.Ttl.Length != b.Ttl.Length || a.Dp.Length != b.Dp.Length)
                throw new ArgumentException("Voice styles have different shapes and cannot be blended.");

            var r = new VoiceStyle
            {
                Name = name ?? $"{a.Name}_{b.Name}_{t:0.00}",
                TtlShape = (long[])a.TtlShape.Clone(),
                DpShape = (long[])a.DpShape.Clone(),
                Ttl = new float[a.Ttl.Length],
                Dp = new float[a.Dp.Length],
            };
            for (int i = 0; i < r.Ttl.Length; i++) r.Ttl[i] = a.Ttl[i] + (b.Ttl[i] - a.Ttl[i]) * t;
            for (int i = 0; i < r.Dp.Length; i++) r.Dp[i] = a.Dp[i] + (b.Dp[i] - a.Dp[i]) * t;
            return r;
        }

        static (float[] data, long[] shape) ReadTensor(JToken token)
        {
            if (token == null) throw new InvalidDataException("Voice style JSON is missing style_ttl / style_dp.");
            var shape = token["dims"].ToObject<long[]>();
            var flat = new List<float>();
            Flatten(token["data"], flat);
            return (flat.ToArray(), shape);
        }

        static void Flatten(JToken t, List<float> into)
        {
            if (t is JArray arr) { foreach (var child in arr) Flatten(child, into); }
            else into.Add(t.Value<float>());
        }
    }
}
