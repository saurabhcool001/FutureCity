// FutureCity Offline TTS — text helpers shared by speech, word timing and word highlighting.
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace SaurabhFutureCity.OfflineTTS
{
    public static class TTSText
    {
        // <b>, </color>, <color=#FF0000>, <size=120%>, <sprite name="x">, <br> …
        static readonly Regex RichTextTag = new Regex(@"<\/?[a-zA-Z#][^<>]*>", RegexOptions.Compiled);
        static readonly Regex Whitespace = new Regex(@"\s+", RegexOptions.Compiled);

        /// <summary>
        /// Turns on-screen text into text that should be spoken: removes rich-text / TMP tags
        /// (&lt;b&gt;, &lt;color=…&gt;, &lt;s&gt;…), turns &lt;br&gt; into a pause, collapses whitespace.
        /// </summary>
        public static string ToSpeakable(string displayed)
        {
            if (string.IsNullOrEmpty(displayed)) return string.Empty;
            string s = Regex.Replace(displayed, @"<br\s*/?>", ". ", RegexOptions.IgnoreCase);
            s = RichTextTag.Replace(s, string.Empty);
            s = s.Replace("\u00A0", " ");
            return Whitespace.Replace(s, " ").Trim();
        }

        /// <summary>
        /// Splits text into words exactly the way word timing and highlighting expect:
        /// whitespace-separated tokens that contain at least one letter or digit.
        /// </summary>
        public static List<string> Words(string text)
        {
            var words = new List<string>();
            if (string.IsNullOrEmpty(text)) return words;
            var sb = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsWhiteSpace(c)) { Flush(sb, words); continue; }
                sb.Append(c);
            }
            Flush(sb, words);
            return words;
        }

        static void Flush(StringBuilder sb, List<string> words)
        {
            if (sb.Length == 0) return;
            string token = sb.ToString();
            sb.Clear();
            foreach (char c in token)
                if (char.IsLetterOrDigit(c)) { words.Add(token); return; }
        }

        /// <summary>
        /// Share (0–1) of the spoken words that also appear in the displayed text, ignoring case, punctuation and
        /// rich-text tags. Used to decide which on-screen text belongs to a spoken line.
        /// </summary>
        public static float MatchRatio(string spokenText, string displayedText)
        {
            var spoken = Words(ToSpeakable(spokenText));
            if (spoken.Count == 0 || string.IsNullOrEmpty(displayedText)) return 0f;
            var shown = new HashSet<string>();
            foreach (var w in Words(ToSpeakable(displayedText))) shown.Add(NormalizeWord(w));
            int hits = 0;
            foreach (var w in spoken) if (shown.Contains(NormalizeWord(w))) hits++;
            return hits / (float)spoken.Count;
        }

        /// <summary>Lower-case letters and digits only — used to match spoken words to on-screen words.</summary>
        public static string NormalizeWord(string word)
        {
            if (string.IsNullOrEmpty(word)) return string.Empty;
            var sb = new StringBuilder(word.Length);
            foreach (char c in word) if (char.IsLetterOrDigit(c)) sb.Append(char.ToLowerInvariant(c));
            return sb.ToString();
        }
    }
}
