// FutureCity Offline TTS
// Minimal 16-bit PCM mono WAV encoder/decoder (used for baking, disk cache and video voice-overs).

using System;
using System.IO;
using System.Text;

namespace SaurabhFutureCity.OfflineTTS
{
    public static class WavUtility
    {
        public static byte[] Encode(float[] samples, int sampleRate)
        {
            using (var ms = new MemoryStream(44 + samples.Length * 2))
            {
                Write(ms, samples, sampleRate);
                return ms.ToArray();
            }
        }

        public static void Save(string path, float[] samples, int sampleRate)
        {
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            using (var fs = File.Create(path)) Write(fs, samples, sampleRate);
        }

        public static void Write(Stream stream, float[] samples, int sampleRate)
        {
            const short channels = 1, bits = 16;
            int dataSize = samples.Length * 2;
            using (var w = new BinaryWriter(stream, Encoding.ASCII, leaveOpen: true))
            {
                w.Write(Encoding.ASCII.GetBytes("RIFF"));
                w.Write(36 + dataSize);
                w.Write(Encoding.ASCII.GetBytes("WAVE"));
                w.Write(Encoding.ASCII.GetBytes("fmt "));
                w.Write(16);
                w.Write((short)1);
                w.Write(channels);
                w.Write(sampleRate);
                w.Write(sampleRate * channels * bits / 8);
                w.Write((short)(channels * bits / 8));
                w.Write(bits);
                w.Write(Encoding.ASCII.GetBytes("data"));
                w.Write(dataSize);
                foreach (var s in samples)
                {
                    float c = s < -1f ? -1f : (s > 1f ? 1f : s);
                    w.Write((short)(c * 32767f));
                }
            }
        }

        /// <summary>Reads a 16-bit PCM mono WAV written by this utility (used by the disk cache).</summary>
        public static bool TryLoad(string path, out float[] samples, out int sampleRate)
        {
            samples = null; sampleRate = 0;
            try
            {
                using (var r = new BinaryReader(File.OpenRead(path)))
                {
                    if (Encoding.ASCII.GetString(r.ReadBytes(4)) != "RIFF") return false;
                    r.ReadInt32();
                    if (Encoding.ASCII.GetString(r.ReadBytes(4)) != "WAVE") return false;

                    short channels = 0, bits = 0;
                    while (r.BaseStream.Position < r.BaseStream.Length)
                    {
                        string id = Encoding.ASCII.GetString(r.ReadBytes(4));
                        int size = r.ReadInt32();
                        if (id == "fmt ")
                        {
                            r.ReadInt16();
                            channels = r.ReadInt16();
                            sampleRate = r.ReadInt32();
                            r.ReadInt32(); r.ReadInt16();
                            bits = r.ReadInt16();
                            if (size > 16) r.ReadBytes(size - 16);
                        }
                        else if (id == "data")
                        {
                            if (channels != 1 || bits != 16) return false;
                            int count = size / 2;
                            samples = new float[count];
                            for (int i = 0; i < count; i++) samples[i] = r.ReadInt16() / 32768f;
                            return true;
                        }
                        else r.ReadBytes(size);
                    }
                }
            }
            catch (Exception) { }
            return false;
        }

        /// <summary>Applies a short fade in/out to avoid clicks at chunk boundaries.</summary>
        public static void ApplyEdgeFade(float[] samples, int sampleRate, float seconds = 0.005f)
        {
            int n = Math.Min(samples.Length / 2, (int)(sampleRate * seconds));
            for (int i = 0; i < n; i++)
            {
                float g = (float)i / n;
                samples[i] *= g;
                samples[samples.Length - 1 - i] *= g;
            }
        }
    }
}
