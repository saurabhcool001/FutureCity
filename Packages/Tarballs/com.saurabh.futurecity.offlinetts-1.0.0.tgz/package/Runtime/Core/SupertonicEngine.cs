// FutureCity Offline TTS
// Supertonic 3 inference pipeline on ONNX Runtime (CPU, optional NNAPI on Android).
// Pipeline: duration predictor -> text encoder -> N-step flow-matching vector estimator -> vocoder.
// Adapted from the MIT-licensed Supertonic C# reference implementation (c) Supertone Inc.
// Pure C# (no UnityEngine) so it can run on any worker thread.

using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Microsoft.ML.OnnxRuntime;

namespace SaurabhFutureCity.OfflineTTS
{
    public struct EngineOptions
    {
        /// <summary>Intra-op threads. 0 = ONNX Runtime default (all cores). On Quest/Pico, 2–4 keeps the render thread healthy.</summary>
        public int Threads;
        /// <summary>Try the Android NNAPI execution provider (falls back to CPU if unavailable). Off by default — CPU is usually faster on XR2.</summary>
        public bool UseNnapi;
        /// <summary>Stop worker threads from busy-spinning between ops. Strongly recommended on standalone headsets.</summary>
        public bool DisableThreadSpinning;

        public static EngineOptions Default => new EngineOptions { Threads = 0, UseNnapi = false, DisableThreadSpinning = true };
    }

    [Serializable]
    public struct SynthesisParams
    {
        /// <summary>Denoising steps. 8 = reference quality. 4–6 is noticeably faster with small quality loss.</summary>
        public int Steps;
        /// <summary>Speaking rate multiplier (1.05 is the reference default).</summary>
        public float Speed;
        /// <summary>Silence inserted between sentence chunks, in seconds.</summary>
        public float ChunkSilence;
        /// <summary>Random seed for the initial noise. Same seed + text + voice = identical audio (useful for baking). -1 = random.</summary>
        public int Seed;

        public static SynthesisParams Default => new SynthesisParams { Steps = 8, Speed = 1.05f, ChunkSilence = 0.3f, Seed = -1 };
    }

    public sealed class SupertonicEngine : IDisposable
    {
        public const string DurationPredictorFile = "duration_predictor.onnx";
        public const string TextEncoderFile = "text_encoder.onnx";
        public const string VectorEstimatorFile = "vector_estimator.onnx";
        public const string VocoderFile = "vocoder.onnx";
        public const string ConfigFile = "tts.json";
        public const string IndexerFile = "unicode_indexer.json";

        public static readonly string[] RequiredFiles =
            { DurationPredictorFile, TextEncoderFile, VectorEstimatorFile, VocoderFile, ConfigFile, IndexerFile };

        readonly InferenceSession _dp, _textEnc, _vectorEst, _vocoder;
        readonly ModelConfig _cfg;
        readonly UnicodeIndexer _indexer;
        readonly object _runLock = new object();
        bool _disposed;

        public int SampleRate => _cfg.SampleRate;

        /// <param name="onnxDir">Folder containing the four .onnx files, tts.json and unicode_indexer.json.</param>
        public SupertonicEngine(string onnxDir, EngineOptions options)
        {
            foreach (var f in RequiredFiles)
                if (!File.Exists(Path.Combine(onnxDir, f)))
                    throw new FileNotFoundException($"Supertonic model file missing: {f}", Path.Combine(onnxDir, f));

            _cfg = ModelConfig.FromJson(File.ReadAllText(Path.Combine(onnxDir, ConfigFile)));
            _indexer = UnicodeIndexer.FromJson(File.ReadAllText(Path.Combine(onnxDir, IndexerFile)));

            using (var opts = CreateSessionOptions(options))
            {
                _dp = new InferenceSession(Path.Combine(onnxDir, DurationPredictorFile), opts);
                _textEnc = new InferenceSession(Path.Combine(onnxDir, TextEncoderFile), opts);
                _vectorEst = new InferenceSession(Path.Combine(onnxDir, VectorEstimatorFile), opts);
                _vocoder = new InferenceSession(Path.Combine(onnxDir, VocoderFile), opts);
            }
        }

        static SessionOptions CreateSessionOptions(EngineOptions o)
        {
            var opts = new SessionOptions
            {
                GraphOptimizationLevel = GraphOptimizationLevel.ORT_ENABLE_ALL,
                ExecutionMode = ExecutionMode.ORT_SEQUENTIAL,
            };
            if (o.Threads > 0) opts.IntraOpNumThreads = o.Threads;
            opts.InterOpNumThreads = 1;
            if (o.DisableThreadSpinning)
            {
                opts.AddSessionConfigEntry("session.intra_op.allow_spinning", "0");
                opts.AddSessionConfigEntry("session.inter_op.allow_spinning", "0");
            }
            if (o.UseNnapi)
            {
                try { opts.AppendExecutionProvider_Nnapi(); }
                catch (Exception) { /* Not Android, or NNAPI not present: stay on CPU. */ }
            }
            return opts;
        }

        /// <summary>Synthesises the whole text (all chunks joined with silence). Mono float PCM at SampleRate.</summary>
        public float[] Synthesize(string text, string lang, VoiceStyle voice, SynthesisParams p, CancellationToken ct = default)
        {
            var all = new List<float>();
            int silence = Math.Max(0, (int)(p.ChunkSilence * SampleRate));
            bool first = true;
            foreach (var chunk in SynthesizeChunks(text, lang, voice, p, ct))
            {
                if (!first && silence > 0) all.AddRange(new float[silence]);
                all.AddRange(chunk);
                first = false;
            }
            return all.ToArray();
        }

        /// <summary>
        /// Lazily synthesises sentence-sized chunks. Enumerate on a worker thread and start playing the first
        /// chunk while the rest are generated — this is what keeps perceived latency low on headsets.
        /// </summary>
        public IEnumerable<float[]> SynthesizeChunks(string text, string lang, VoiceStyle voice, SynthesisParams p, CancellationToken ct = default)
        {
            foreach (var (_, wav) in SynthesizeChunksWithText(text, lang, voice, p, ct)) yield return wav;
        }

        /// <summary>Like <see cref="SynthesizeChunks"/> but also returns the text of each chunk (for word timing).</summary>
        public IEnumerable<(string text, float[] samples)> SynthesizeChunksWithText(string text, string lang, VoiceStyle voice,
                                                                                 SynthesisParams p, CancellationToken ct = default)
        {
            if (voice == null) throw new ArgumentNullException(nameof(voice));
            var rng = p.Seed >= 0 ? new Random(p.Seed) : new Random();
            foreach (var chunk in TextPreprocessor.Chunk(text, TTSLanguages.MaxChunkLength(lang)))
            {
                ct.ThrowIfCancellationRequested();
                var wav = InferChunk(chunk, lang, voice, p, rng, ct);
                if (wav.Length > 0) yield return (chunk, wav);
            }
        }

        float[] InferChunk(string chunk, string lang, VoiceStyle voice, SynthesisParams p, Random rng, CancellationToken ct)
        {
            string prepared = TextPreprocessor.Prepare(chunk, lang);
            if (prepared.Length == 0) return Array.Empty<float>();

            int steps = Math.Max(1, p.Steps);
            float speed = p.Speed <= 0 ? 1.05f : p.Speed;

            long[] ids = _indexer.Encode(prepared);
            int len = ids.Length;
            var mask = new float[len];
            for (int i = 0; i < len; i++) mask[i] = 1f;

            lock (_runLock)
            {
                if (_disposed) throw new ObjectDisposedException(nameof(SupertonicEngine));

                using (var runOptions = new RunOptions())
                using (ct.Register(() => runOptions.Terminate = true))
                using (var textIds = OrtValue.CreateTensorValueFromMemory(ids, new long[] { 1, len }))
                using (var textMask = OrtValue.CreateTensorValueFromMemory(mask, new long[] { 1, 1, len }))
                using (var styleTtl = OrtValue.CreateTensorValueFromMemory(voice.Ttl, voice.TtlShape))
                using (var styleDp = OrtValue.CreateTensorValueFromMemory(voice.Dp, voice.DpShape))
                {
                    // 1) Duration
                    float duration;
                    using (var dpOut = _dp.Run(runOptions,
                               new[] { "text_ids", "style_dp", "text_mask" },
                               new[] { textIds, styleDp, textMask },
                               new[] { "duration" }))
                    {
                        duration = dpOut[0].GetTensorDataAsSpan<float>()[0] / speed;
                    }

                    // 2) Text embedding
                    float[] textEmb;
                    long[] textEmbShape;
                    using (var encOut = _textEnc.Run(runOptions,
                               new[] { "text_ids", "style_ttl", "text_mask" },
                               new[] { textIds, styleTtl, textMask },
                               new[] { "text_emb" }))
                    {
                        textEmb = encOut[0].GetTensorDataAsSpan<float>().ToArray();
                        textEmbShape = encOut[0].GetTensorTypeAndShape().Shape;
                    }

                    // 3) Initial noisy latent
                    long wavLen = Math.Max(1, (long)(duration * _cfg.SampleRate));
                    int chunkSize = _cfg.BaseChunkSize * _cfg.ChunkCompressFactor;
                    int latentLen = (int)((wavLen + chunkSize - 1) / chunkSize);
                    int latentDim = _cfg.LatentDim * _cfg.ChunkCompressFactor;

                    var xt = new float[latentDim * latentLen];
                    for (int i = 0; i < xt.Length; i++) xt[i] = Gaussian(rng);

                    var latentMask = new float[latentLen];
                    for (int i = 0; i < latentLen; i++) latentMask[i] = 1f;

                    var latentShape = new long[] { 1, latentDim, latentLen };
                    var totalStep = new[] { (float)steps };
                    var currentStep = new float[1];

                    // 4) Flow-matching denoising loop
                    using (var textEmbVal = OrtValue.CreateTensorValueFromMemory(textEmb, textEmbShape))
                    using (var latentMaskVal = OrtValue.CreateTensorValueFromMemory(latentMask, new long[] { 1, 1, latentLen }))
                    using (var totalStepVal = OrtValue.CreateTensorValueFromMemory(totalStep, new long[] { 1 }))
                    {
                        var names = new[] { "noisy_latent", "text_emb", "style_ttl", "text_mask", "latent_mask", "total_step", "current_step" };
                        var outNames = new[] { "denoised_latent" };
                        for (int step = 0; step < steps; step++)
                        {
                            ct.ThrowIfCancellationRequested();
                            currentStep[0] = step;
                            using (var xtVal = OrtValue.CreateTensorValueFromMemory(xt, latentShape))
                            using (var curVal = OrtValue.CreateTensorValueFromMemory(currentStep, new long[] { 1 }))
                            using (var outVals = _vectorEst.Run(runOptions, names,
                                       new[] { xtVal, textEmbVal, styleTtl, textMask, latentMaskVal, totalStepVal, curVal },
                                       outNames))
                            {
                                outVals[0].GetTensorDataAsSpan<float>().CopyTo(xt);
                            }
                        }
                    }

                    // 5) Vocoder
                    using (var latentVal = OrtValue.CreateTensorValueFromMemory(xt, latentShape))
                    using (var vocOut = _vocoder.Run(runOptions, new[] { "latent" }, new[] { latentVal }, new[] { "wav_tts" }))
                    {
                        var span = vocOut[0].GetTensorDataAsSpan<float>();
                        int n = (int)Math.Min(span.Length, wavLen);
                        return span.Slice(0, n).ToArray();
                    }
                }
            }
        }

        static float Gaussian(Random rng)
        {
            double u1 = 1.0 - rng.NextDouble();
            double u2 = 1.0 - rng.NextDouble();
            return (float)(Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Cos(2.0 * Math.PI * u2));
        }

        public void Dispose()
        {
            lock (_runLock)
            {
                if (_disposed) return;
                _disposed = true;
                _dp?.Dispose();
                _textEnc?.Dispose();
                _vectorEst?.Dispose();
                _vocoder?.Dispose();
            }
        }
    }
}
