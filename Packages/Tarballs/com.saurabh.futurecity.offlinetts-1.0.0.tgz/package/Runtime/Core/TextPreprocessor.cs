// FutureCity Offline TTS
// Text normalisation + chunking for Supertonic 3.
// Adapted from the MIT-licensed Supertonic C# reference implementation (c) Supertone Inc.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SaurabhFutureCity.OfflineTTS
{
    /// <summary>Languages supported by Supertonic 3 (ISO 639-1 codes).</summary>
    public static class TTSLanguages
    {
        public static readonly string[] All =
        {
            "en", "ko", "ja", "ar", "bg", "cs", "da", "de", "el", "es", "et", "fi", "fr", "hi", "hr", "hu",
            "id", "it", "lt", "lv", "nl", "pl", "pt", "ro", "ru", "sk", "sl", "sv", "tr", "uk", "vi"
        };

        public static bool IsSupported(string lang) => Array.IndexOf(All, lang) >= 0;

        static readonly string[] Names =
        {
            "English", "Korean", "Japanese", "Arabic", "Bulgarian", "Czech", "Danish", "German", "Greek", "Spanish",
            "Estonian", "Finnish", "French", "Hindi", "Croatian", "Hungarian", "Indonesian", "Italian", "Lithuanian",
            "Latvian", "Dutch", "Polish", "Portuguese", "Romanian", "Russian", "Slovak", "Slovenian", "Swedish",
            "Turkish", "Ukrainian", "Vietnamese"
        };

        /// <summary>"English" for "en"; returns the code itself if unknown.</summary>
        public static string DisplayName(string lang)
        {
            int i = Array.IndexOf(All, lang);
            return i >= 0 ? Names[i] : lang;
        }

        /// <summary>Recommended max characters per chunk. CJK scripts are denser, so they get shorter chunks.</summary>
        public static int MaxChunkLength(string lang) => (lang == "ko" || lang == "ja") ? 120 : 300;
    }

    public static class TextPreprocessor
    {
        static readonly (string from, string to)[] CharReplacements =
        {
            ("\u2013", "-"), ("\u2011", "-"), ("\u2014", "-"), ("_", " "),
            ("\u201C", "\""), ("\u201D", "\""), ("\u2018", "'"), ("\u2019", "'"),
            ("\u00B4", "'"), ("`", "'"), ("[", " "), ("]", " "), ("|", " "),
            ("/", " "), ("#", " "), ("\u2192", " "), ("\u2190", " "),
        };

        static readonly (string from, string to)[] ExpressionReplacements =
        {
            ("@", " at "), ("e.g.,", "for example, "), ("i.e.,", "that is, "),
        };

        static readonly Regex SpecialSymbols = new Regex(@"[♥☆♡©\\]", RegexOptions.Compiled);
        static readonly Regex SpaceBeforePunct = new Regex(@" ([,\.!\?;:'])", RegexOptions.Compiled);
        static readonly Regex MultiSpace = new Regex(@"\s+", RegexOptions.Compiled);
        static readonly Regex EndsWithPunct = new Regex("[.!?;:,'\"\u201C\u201D\u2018\u2019)\\]}…。」』】〉》›»]$", RegexOptions.Compiled);
        static readonly Regex ParagraphSplit = new Regex(@"\n\s*\n+", RegexOptions.Compiled);
        static readonly Regex SentenceSplit = new Regex(
            @"(?<!Mr\.|Mrs\.|Ms\.|Dr\.|Prof\.|Sr\.|Jr\.|Ph\.D\.|etc\.|e\.g\.|i\.e\.|vs\.|Inc\.|Ltd\.|Co\.|Corp\.|St\.|Ave\.|Blvd\.)(?<!\b[A-Z]\.)(?:(?<=[.!?])\s+|(?<=[。！？])\s*)",
            RegexOptions.Compiled);

        /// <summary>Normalises raw text and wraps it in language tags, ready for the unicode indexer.</summary>
        public static string Prepare(string text, string lang)
        {
            if (!TTSLanguages.IsSupported(lang))
                throw new ArgumentException($"Unsupported language '{lang}'. Supported: {string.Join(", ", TTSLanguages.All)}");

            try { text = text.Normalize(NormalizationForm.FormKD); }
            catch (Exception) { /* Some stripped runtimes lack normalisation tables; continue un-normalised. */ }

            text = RemoveEmoji(text);

            foreach (var (from, to) in CharReplacements) text = text.Replace(from, to);
            text = SpecialSymbols.Replace(text, "");
            foreach (var (from, to) in ExpressionReplacements) text = text.Replace(from, to);

            text = SpaceBeforePunct.Replace(text, "$1");
            while (text.Contains("\"\"")) text = text.Replace("\"\"", "\"");
            while (text.Contains("''")) text = text.Replace("''", "'");

            text = MultiSpace.Replace(text, " ").Trim();
            if (text.Length == 0) return string.Empty;

            if (!EndsWithPunct.IsMatch(text)) text += ".";

            return $"<{lang}>{text}</{lang}>";
        }

        /// <summary>Splits long text into sentence-aligned chunks no longer than maxLen characters (where possible).</summary>
        public static List<string> Chunk(string text, int maxLen)
        {
            var chunks = new List<string>();
            if (string.IsNullOrWhiteSpace(text)) return chunks;

            var paragraphs = ParagraphSplit.Split(text.Trim())
                .Select(p => p.Trim())
                .Where(p => p.Length > 0);

            foreach (var paragraph in paragraphs)
            {
                var current = new StringBuilder();
                foreach (var raw in SentenceSplit.Split(paragraph))
                {
                    var sentence = raw.Trim();
                    if (sentence.Length == 0) continue;

                    // A single sentence longer than maxLen gets split on commas / spaces.
                    foreach (var piece in SplitOversized(sentence, maxLen))
                    {
                        if (current.Length > 0 && current.Length + piece.Length + 1 > maxLen)
                        {
                            chunks.Add(current.ToString());
                            current.Clear();
                        }
                        if (current.Length > 0 && !IsCjkTerminal(current[current.Length - 1])) current.Append(' ');
                        current.Append(piece);
                    }
                }
                if (current.Length > 0) chunks.Add(current.ToString());
            }
            return chunks;
        }

        static bool IsCjkTerminal(char c) => c == '。' || c == '！' || c == '？' || c == '、';

        static IEnumerable<string> SplitOversized(string sentence, int maxLen)
        {
            if (sentence.Length <= maxLen) { yield return sentence; yield break; }

            var remaining = sentence;
            while (remaining.Length > maxLen)
            {
                int cut = remaining.LastIndexOfAny(new[] { ',', ';', ':' }, maxLen - 1);
                if (cut < maxLen / 3) cut = remaining.LastIndexOf(' ', maxLen - 1);
                if (cut <= 0) cut = maxLen - 1;
                yield return remaining.Substring(0, cut + 1).Trim();
                remaining = remaining.Substring(cut + 1).Trim();
            }
            if (remaining.Length > 0) yield return remaining;
        }

        static string RemoveEmoji(string text)
        {
            var sb = new StringBuilder(text.Length);
            for (int i = 0; i < text.Length; i++)
            {
                int cp;
                if (char.IsHighSurrogate(text[i]) && i + 1 < text.Length && char.IsLowSurrogate(text[i + 1]))
                {
                    cp = char.ConvertToUtf32(text[i], text[i + 1]);
                    i++;
                }
                else cp = text[i];

                bool emoji = (cp >= 0x1F300 && cp <= 0x1FAFF) || (cp >= 0x2600 && cp <= 0x27BF) ||
                             (cp >= 0x1F1E6 && cp <= 0x1F1FF);
                if (emoji) continue;

                if (cp > 0xFFFF) sb.Append(char.ConvertFromUtf32(cp));
                else sb.Append((char)cp);
            }
            return sb.ToString();
        }
    }
}
