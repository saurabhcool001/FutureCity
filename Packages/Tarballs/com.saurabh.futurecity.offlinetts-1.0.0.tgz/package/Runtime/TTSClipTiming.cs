// FutureCity Offline TTS — word timings for baked or human-recorded AudioClips.
//
// A TTSClipTiming says when each word of a clip is spoken. It's created by the Voice-over Baker (for
// TTS-baked WAVs) or the Word Timing Generator (for any recording + its script). Timings are grouped in a
// TTSClipTimingLibrary, which the settings asset references, so they're available at runtime and in builds.
//
// At runtime, a TTS Speaker on an AudioSource follows any clip that has timings, whoever plays it
// (an NPC voice script, a dialogue system, Timeline…), and drives word highlighting exactly like live TTS.

using System;
using System.Collections.Generic;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS
{
    [CreateAssetMenu(menuName = "FutureCity/Plugins/OfflineTTS/Clip Word Timing", fileName = "NewClipTiming")]
    public class TTSClipTiming : ScriptableObject
    {
        public enum TimingSource { BakedTTS, EstimatedFromRecording, Manual }

        [Tooltip("The audio clip these timings belong to (a baked TTS WAV or a human recording).")]
        public AudioClip clip;

        [Tooltip("What is said in the clip, word for word. Word highlighting matches these words to the on-screen text, " +
                 "so it should be the same wording as the text the user sees (punctuation and capitals don't matter).")]
        [TextArea(2, 6)] public string text;

        [Tooltip("When each word is spoken, in seconds from the start of the clip. Word indices refer to the words of Text.")]
        public TTSWordTiming[] words = Array.Empty<TTSWordTiming>();

        [Tooltip("How these timings were made. Baked TTS timings come from the generator; recording timings are estimated " +
                 "from the audio and the text (accurate enough to follow along).")]
        public TimingSource source = TimingSource.BakedTTS;

        [Tooltip("Name of the clip, stored so timings can be matched by name when the clip is loaded from Addressables or " +
                 "AssetBundles (a separate copy at runtime). Filled automatically.")]
        public string clipName;

        [Tooltip("Length of the clip in seconds, used to tell apart clips that share a name. Filled automatically.")]
        public float clipLength;

        public float Duration => clip != null ? clip.length : (words.Length > 0 ? words[words.Length - 1].end : 0f);

        /// <summary>The clip's name: from the reference when it's loaded, otherwise the stored name.</summary>
        public string ClipKey => clip != null ? clip.name : clipName;

        /// <summary>Copies the clip's name and length into the stored fields (Editor tools call this when saving).</summary>
        public void StoreClipIdentity()
        {
            if (clip == null) return;
            clipName = clip.name;
            clipLength = clip.length;
        }

#if UNITY_EDITOR
        void OnValidate() => StoreClipIdentity();
#endif
    }

    /// <summary>Runtime lookup: AudioClip → word timings.</summary>
    public static class TTSClipTimings
    {
        static readonly Dictionary<AudioClip, TTSClipTiming> Map = new Dictionary<AudioClip, TTSClipTiming>();
        // Name → timings. Addressables / AssetBundles load their own copy of a clip, which never equals the clip the
        // timing asset references, so clips are also matched by name (and length, if several share a name).
        static readonly Dictionary<string, List<TTSClipTiming>> ByName = new Dictionary<string, List<TTSClipTiming>>();
        static readonly HashSet<TTSClipTimingLibrary> Libraries = new HashSet<TTSClipTimingLibrary>();
        static TTSSettings _registeredSettings;
        static readonly HashSet<AudioClip> _warnedNotInLibrary = new HashSet<AudioClip>();
        // Clips already looked up without success. Misses are common (music, ambience, UI sounds) and are asked about
        // repeatedly, so they must be cheap: cleared whenever new timings are registered.
        static readonly HashSet<AudioClip> _knownMissing = new HashSet<AudioClip>();
        static float _nextLoadedScan;

        /// <summary>
        /// Editor only (set by the Editor assembly): finds a timing asset for a clip that isn't in any linked library,
        /// so it still works in Play mode, with a warning that it won't be found in builds until the library is repaired.
        /// </summary>
        public static Func<AudioClip, TTSClipTiming> EditorFallback;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { Map.Clear(); ByName.Clear(); Libraries.Clear(); _registeredSettings = null; _warnedNotInLibrary.Clear(); _knownMissing.Clear(); _nextLoadedScan = 0f; }

        /// <summary>Number of clips with known word timings (for status displays).</summary>
        public static int KnownClipCount { get { EnsureGlobalLibraries(); return Map.Count; } }

        /// <summary>Number of timing libraries registered (for status displays).</summary>
        public static int LibraryCount => Libraries.Count;

        /// <summary>Forget cached "no timings" answers (call after creating timings at runtime outside Register).</summary>
        public static void ClearMissCache() => _knownMissing.Clear();

        /// <summary>Make a single timing available.</summary>
        public static void Register(TTSClipTiming timing)
        {
            if (timing == null) return;
            if (timing.clip != null) { Map[timing.clip] = timing; _knownMissing.Remove(timing.clip); }

            string key = timing.ClipKey;
            if (string.IsNullOrEmpty(key)) return;
            if (!ByName.TryGetValue(key, out var list)) ByName[key] = list = new List<TTSClipTiming>();
            if (!list.Contains(timing)) list.Add(timing);
            _knownMissing.Clear();   // a clip (copy) with this name may have been marked missing before
        }

        /// <summary>Make every timing in a library available.</summary>
        public static void Register(TTSClipTimingLibrary library)
        {
            if (library == null) return;
            Libraries.Add(library);
            foreach (var t in library.timings) Register(t);
            _knownMissing.Clear();
        }

        /// <summary>Timings for this clip, if any library or registration provides them.</summary>
        public static bool TryGet(AudioClip clip, out TTSClipTiming timing)
        {
            timing = null;
            if (clip == null) return false;
            EnsureGlobalLibraries();
            if (Map.TryGetValue(clip, out timing) && timing != null) return true;
            if (_knownMissing.Contains(clip)) return false;              // fast path for clips without timings

            // Same clip loaded as a different object (Addressables / AssetBundles): match by name (+ length).
            if (TryGetByName(clip, out timing)) { Map[clip] = timing; return true; }

            // Any timing library that's loaded (preloaded at build time, or referenced by a scene) counts, even if the
            // settings asset in use doesn't link it. Scanning loaded objects is expensive, so at most every 2 s.
            if (Time.realtimeSinceStartup >= _nextLoadedScan)
            {
                _nextLoadedScan = Time.realtimeSinceStartup + 2f;
                bool foundNew = false;
                foreach (var lib in Resources.FindObjectsOfTypeAll<TTSClipTimingLibrary>())
                    if (lib != null && !Libraries.Contains(lib)) { Register(lib); foundNew = true; }
                if (foundNew)
                {
                    if (Map.TryGetValue(clip, out timing) && timing != null) return true;
                    if (TryGetByName(clip, out timing)) { Map[clip] = timing; return true; }
                }
            }

            // Libraries can gain entries after registration (e.g. while editing): refresh once on a miss.
            foreach (var lib in Libraries)
                if (lib != null)
                    foreach (var t in lib.timings)
                        if (t != null && t.clip == clip) { Map[clip] = t; timing = t; return true; }

            if (EditorFallback != null)
            {
                timing = EditorFallback(clip);
                if (timing != null)
                {
                    Map[clip] = timing;
                    if (_warnedNotInLibrary.Add(clip))
                        Debug.LogWarning($"[OfflineTTS] Word timings for '{clip.name}' were found, but they're not in a timing library " +
                                         "linked in the settings asset. It works in the Editor, but NOT in builds. " +
                                         "Fix: FutureCity ▸ Plugins ▸ OfflineTTS ▸ Repair Timing Library.");
                    return true;
                }
            }
            _knownMissing.Add(clip);
            return false;
        }

        static bool TryGetByName(AudioClip clip, out TTSClipTiming timing)
        {
            timing = null;
            if (string.IsNullOrEmpty(clip.name) || !ByName.TryGetValue(clip.name, out var list) || list.Count == 0) return false;

            float best = float.MaxValue;
            foreach (var t in list)
            {
                if (t == null) continue;
                float stored = t.clip != null ? t.clip.length : t.clipLength;
                // Unknown length on either side: accept by name. Otherwise prefer the closest length (within 5%).
                float diff = (stored <= 0f || clip.length <= 0f) ? 0f : Mathf.Abs(stored - clip.length);
                if (stored > 0f && clip.length > 0f && diff > Mathf.Max(0.1f, clip.length * 0.05f)) continue;
                if (diff < best) { best = diff; timing = t; }
            }
            return timing != null;
        }

        static void EnsureGlobalLibraries()
        {
            var settings = TTSOverride.GlobalSettings;
            if (settings == null || settings == _registeredSettings) return;
            _registeredSettings = settings;
            if (settings.timingLibraries != null)
                foreach (var lib in settings.timingLibraries) Register(lib);
        }
    }
}
