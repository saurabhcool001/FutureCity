// FutureCity Offline TTS
// Scene service that owns the model, voice cache and line cache. Inference runs on a worker thread;
// all AudioClip work happens on the main thread.

using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.ML.OnnxRuntime;
using UnityEngine;
using UnityEngine.Events;

namespace SaurabhFutureCity.OfflineTTS
{
    /// <summary>Per-request overrides. Any empty / negative field falls back to the speaker or settings default.</summary>
    [Serializable]
    public class TTSRequest
    {
        [Tooltip("Voice for this request. Empty = settings default.")]
        [TTSVoice(allowDefault: true)]
        public string voice;

        [Tooltip("Language of the text. Empty = settings default.")]
        [TTSLanguage(allowDefault: true)]
        public string language;

        [Tooltip("Quality steps (1–16). -1 = settings default (8 on PC, 'Mobile Steps' on headsets).")]
        public int steps = -1;

        [Tooltip("Speaking rate (0.5–2). -1 = settings default.")]
        public float speed = -1f;

        [Tooltip("Random seed. The same seed + text + voice gives exactly the same audio every time. -1 = random each time.")]
        public int seed = -1;

        [Tooltip("Reuse previously generated audio for identical requests (memory + disk cache).")]
        public bool useCache = true;
    }

    /// <summary>A piece of generated speech: the clip, the text it says, and when each word is spoken.</summary>
    public class TTSClipInfo
    {
        public AudioClip clip;
        /// <summary>Text of this piece (a sentence when streaming, the whole line otherwise).</summary>
        public string text;
        public int chunkIndex;
        /// <summary>Word timings in seconds from the start of <see cref="clip"/>; indices refer to the whole line.</summary>
        public TTSWordTiming[] words;
    }

    [DefaultExecutionOrder(-500)]
    public class OfflineTTS : MonoBehaviour
    {
        public static OfflineTTS Instance { get; private set; }

        [Tooltip("Settings asset (model location, default voice/language, quality, performance, caching).\n" +
                 "Create or find it with FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create or Locate Settings Asset.\n" +
                 "Empty = built-in defaults.")]
        [SerializeField] TTSSettings settings;

        [Tooltip("Start loading the model as soon as this object wakes up (recommended: put the service in your first scene).\n" +
                 "If off, call InitializeAsync() yourself, e.g. behind a loading screen.")]
        [SerializeField] bool initializeOnAwake = true;

        [Tooltip("Keep the service alive across scene loads so the model is loaded only once per app session.")]
        [SerializeField] bool dontDestroyOnLoad = true;

        [Tooltip("Voices to load while the model loads (each is a small file). Voices not listed load on first use.")]
        [TTSVoice] [SerializeField] string[] preloadVoices = { "F1", "M1" };

        [Header("Events")]
        [Tooltip("Invoked once the model has loaded and speech can be generated.")]
        public UnityEvent onReady = new UnityEvent();
        [Tooltip("Invoked with an error message if the model fails to load (e.g. model files missing).")]
        public UnityEvent<string> onError = new UnityEvent<string>();

        public TTSSettings Settings => settings;
        public bool IsReady => _engine != null;
        public int SampleRate => _engine?.SampleRate ?? 44100;
        public float LoadProgress { get; private set; }

        SupertonicEngine _engine;
        string _root;
        Task _initTask;
        readonly Dictionary<string, VoiceStyle> _voices = new Dictionary<string, VoiceStyle>();
        readonly LinkedList<(string key, float[] samples)> _lru = new LinkedList<(string, float[])>();
        readonly Dictionary<string, LinkedListNode<(string key, float[] samples)>> _lruIndex =
            new Dictionary<string, LinkedListNode<(string, float[])>>();
        readonly CancellationTokenSource _lifetime = new CancellationTokenSource();

        string CacheDir => Path.Combine(Application.persistentDataPath, "TTSCache", settings.modelVersion);

        // Supports "Enter Play Mode Options" with domain reload disabled (fast iteration in the Editor).
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() => Instance = null;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            if (settings == null) settings = TTSSettings.FindLoaded();      // project asset (preloaded in builds)
            if (settings == null) settings = TTSSettings.CreateDefault();
            if (settings.timingLibraries != null)
                foreach (var lib in settings.timingLibraries) TTSClipTimings.Register(lib);
            if (dontDestroyOnLoad && transform.parent == null) DontDestroyOnLoad(gameObject);
            if (initializeOnAwake) _ = InitializeAsync();
        }

        void OnDestroy()
        {
            if (Instance != this) return;
            Instance = null;
            _lifetime.Cancel();
            var engine = _engine;
            _engine = null;
            // Dispose off the main thread: it waits for any in-flight inference to finish.
            if (engine != null) Task.Run(() => engine.Dispose());
        }

        /// <summary>Finds the scene instance or creates one with default settings.</summary>
        public static OfflineTTS GetOrCreate()
        {
            if (Instance != null) return Instance;
#if UNITY_2023_1_OR_NEWER
            var existing = FindFirstObjectByType<OfflineTTS>();
#else
            var existing = FindObjectOfType<OfflineTTS>();
#endif
            if (existing != null) return existing;
            return new GameObject("[OfflineTTS]").AddComponent<OfflineTTS>();
        }

        // ------------------------------------------------------------------ initialisation

        public Task InitializeAsync() => _initTask ??= InitializeInternalAsync();

        async Task InitializeInternalAsync()
        {
            try
            {
                var progress = new Progress<float>(p => LoadProgress = p * 0.5f);
                _root = await ModelLocator.ResolveRootAsync(settings, progress);

                string onnxDir = ModelLocator.OnnxDir(_root);
                var options = settings.EngineOptions;
                var engine = await Task.Run(() => new SupertonicEngine(onnxDir, options));
                LoadProgress = 0.9f;

                foreach (var v in preloadVoices) await GetVoiceAsync(v);

                if (settings.warmUpOnLoad)
                {
                    var warmVoice = await GetVoiceAsync(settings.defaultVoice);
                    var p = settings.DefaultParams; p.Steps = 1;
                    await Task.Run(() => engine.Synthesize("Hi.", "en", warmVoice, p));
                }

                _engine = engine;
                LoadProgress = 1f;
                Debug.Log($"[OfflineTTS] Ready ({Application.platform}, {options.Threads} threads, root: {_root})");
                onReady.Invoke();
            }
            catch (Exception e)
            {
                _initTask = null; // allow retry
                Debug.LogError($"[OfflineTTS] Initialisation failed: {e}");
                onError.Invoke(e.Message);
                throw;
            }
        }

        public async Task<VoiceStyle> GetVoiceAsync(string voiceName)
        {
            if (string.IsNullOrEmpty(voiceName)) voiceName = settings.defaultVoice;
            if (_voices.TryGetValue(voiceName, out var v)) return v;
            if (_root == null) await InitializeAsync();

            string path = ModelLocator.VoicePath(_root, voiceName);
            if (!File.Exists(path)) throw new FileNotFoundException($"[OfflineTTS] Voice '{voiceName}' not found", path);
            v = await Task.Run(() => VoiceStyle.FromFile(path));
            _voices[voiceName] = v;
            return v;
        }

        /// <summary>Registers a custom/blended voice under a name usable by speakers and requests.</summary>
        public void RegisterVoice(VoiceStyle voice) => _voices[voice.Name] = voice;

        // ------------------------------------------------------------------ synthesis

        /// <summary>Generates the full line and returns raw PCM samples (mono, SampleRate).</summary>
        public async Task<float[]> SynthesizeSamplesAsync(string text, TTSRequest request = null, CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(text)) return Array.Empty<float>();
            await InitializeAsync();
            var (voice, lang, p, useCache) = await ResolveAsync(request);
            string key = CacheKey(text, voice.Name, lang, p);

            if (useCache && TryGetCached(key, out var cached)) return cached;

            using (var linked = CancellationTokenSource.CreateLinkedTokenSource(ct, _lifetime.Token))
            {
                var token = linked.Token;
                float[] samples = await RunGuarded(() => _engine.Synthesize(text, lang, voice, p, token), token);
                WavUtility.ApplyEdgeFade(samples, SampleRate);
                if (useCache) await StoreCachedAsync(key, samples);
                return samples;
            }
        }

        /// <summary>Generates the full line as an AudioClip.</summary>
        public async Task<AudioClip> SynthesizeClipAsync(string text, TTSRequest request = null, CancellationToken ct = default)
        {
            var samples = await SynthesizeSamplesAsync(text, request, ct);
            return ToClip(samples, MakeClipName(text));
        }

        /// <summary>
        /// Streams sentence chunks. onChunk is invoked on the main thread with each chunk's AudioClip as soon as it is ready.
        /// Cached lines are delivered as a single clip immediately.
        /// </summary>
        public Task SynthesizeStreamingAsync(string text, Action<AudioClip> onChunk, TTSRequest request = null, CancellationToken ct = default) =>
            SynthesizeStreamingWithTimingAsync(text, info => onChunk(info.clip), request, ct);

        /// <summary>
        /// Like <see cref="SynthesizeStreamingAsync"/>, but each delivered piece also carries its text and
        /// per-word timings (for word highlighting / subtitles). Word indices refer to <see cref="TTSText.Words"/>
        /// of the whole <paramref name="text"/>.
        /// </summary>
        public async Task SynthesizeStreamingWithTimingAsync(string text, Action<TTSClipInfo> onChunk, TTSRequest request = null,
                                                             CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            await InitializeAsync();
            var (voice, lang, p, useCache) = await ResolveAsync(request);
            string key = CacheKey(text, voice.Name, lang, p);

            if (useCache && TryGetCached(key, out var cached))
            {
                onChunk(MakeLineInfo(text, lang, p, cached));
                return;
            }

            var context = SynchronizationContext.Current;
            var collected = new List<float>();
            int silence = (int)(p.ChunkSilence * SampleRate);
            int sampleRate = SampleRate;
            int index = 0, wordIndex = 0;

            using (var linked = CancellationTokenSource.CreateLinkedTokenSource(ct, _lifetime.Token))
            {
                var token = linked.Token;
                await RunGuarded(() =>
                {
                    foreach (var (chunkText, chunk) in _engine.SynthesizeChunksWithText(text, lang, voice, p, token))
                    {
                        WavUtility.ApplyEdgeFade(chunk, sampleRate);
                        // Bake inter-chunk silence into the head of each subsequent chunk so playback timing matches.
                        int lead = index > 0 ? silence : 0;
                        float[] withGap = chunk;
                        if (lead > 0)
                        {
                            withGap = new float[lead + chunk.Length];
                            Array.Copy(chunk, 0, withGap, lead, chunk.Length);
                        }
                        var words = TTSText.Words(chunkText);
                        var timings = WordTimingEstimator.EstimateChunk(words, withGap, lead, chunk.Length, sampleRate, wordIndex);
                        wordIndex += words.Count;
                        collected.AddRange(withGap);
                        int i = index++;

                        void Deliver(object _)
                        {
                            if (token.IsCancellationRequested) return;
                            onChunk(new TTSClipInfo
                            {
                                clip = ToClip(withGap, $"{MakeClipName(text)}_{i}"),
                                text = chunkText, chunkIndex = i, words = timings,
                            });
                        }
                        if (context != null) context.Post(Deliver, null); else Deliver(null);
                    }
                    return true;
                }, token);
            }

            if (useCache && collected.Count > 0) await StoreCachedAsync(key, collected.ToArray());
        }

        /// <summary>Whole line as one clip, plus per-word timings.</summary>
        public async Task<TTSClipInfo> SynthesizeClipWithTimingAsync(string text, TTSRequest request = null, CancellationToken ct = default)
        {
            var samples = await SynthesizeSamplesAsync(text, request, ct);
            var (_, lang, p, _) = await ResolveAsync(request);
            return MakeLineInfo(text, lang, p, samples);
        }

        TTSClipInfo MakeLineInfo(string text, string lang, SynthesisParams p, float[] samples) => new TTSClipInfo
        {
            clip = ToClip(samples, MakeClipName(text)),
            text = text,
            chunkIndex = 0,
            words = WordTimingEstimator.EstimateLine(text, samples, SampleRate, p.ChunkSilence, TTSLanguages.MaxChunkLength(lang)),
        };

        /// <summary>Pre-generates lines (e.g. during a loading screen or before a video starts) so they play instantly later.</summary>
        public async Task PrewarmAsync(IEnumerable<string> lines, TTSRequest request = null, IProgress<float> progress = null, CancellationToken ct = default)
        {
            var list = new List<string>(lines);
            for (int i = 0; i < list.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                await SynthesizeSamplesAsync(list[i], request ?? new TTSRequest(), ct);
                progress?.Report((i + 1f) / list.Count);
            }
        }

        /// <summary>Writes a line to a WAV file (for video editing / voice-over pipelines at runtime).</summary>
        public async Task<string> SynthesizeToWavAsync(string text, string path, TTSRequest request = null, CancellationToken ct = default)
        {
            var samples = await SynthesizeSamplesAsync(text, request, ct);
            int sr = SampleRate;
            await Task.Run(() => WavUtility.Save(path, samples, sr), ct);
            return path;
        }

        public AudioClip ToClip(float[] samples, string name = "TTS")
        {
            var clip = AudioClip.Create(name, Math.Max(1, samples.Length), 1, SampleRate, false);
            if (samples.Length > 0) clip.SetData(samples, 0);
            return clip;
        }

        public void ClearCache(bool includeDisk = false)
        {
            _lru.Clear(); _lruIndex.Clear();
            if (includeDisk && Directory.Exists(CacheDir)) Directory.Delete(CacheDir, true);
        }

        // ------------------------------------------------------------------ helpers

        async Task<(VoiceStyle voice, string lang, SynthesisParams p, bool useCache)> ResolveAsync(TTSRequest r)
        {
            r ??= new TTSRequest();
            var voice = await GetVoiceAsync(string.IsNullOrEmpty(r.voice) ? settings.defaultVoice : r.voice);
            string lang = string.IsNullOrEmpty(r.language) ? settings.defaultLanguage : r.language;
            var p = settings.DefaultParams;
            if (r.steps > 0) p.Steps = r.steps;
            if (r.speed > 0) p.Speed = r.speed;
            p.Seed = r.seed;
            return (voice, lang, p, r.useCache);
        }

        static async Task<T> RunGuarded<T>(Func<T> work, CancellationToken token)
        {
            try { return await Task.Run(work, token); }
            catch (OnnxRuntimeException) when (token.IsCancellationRequested) { throw new OperationCanceledException(token); }
        }

        static string CacheKey(string text, string voice, string lang, SynthesisParams p)
        {
            using (var sha = SHA1.Create())
            {
                var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes($"{voice}|{lang}|{p.Steps}|{p.Speed:0.###}|{p.ChunkSilence:0.###}|{p.Seed}|{text}"));
                var sb = new StringBuilder(40);
                foreach (var b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        bool TryGetCached(string key, out float[] samples)
        {
            if (_lruIndex.TryGetValue(key, out var node))
            {
                _lru.Remove(node); _lru.AddFirst(node);
                samples = node.Value.samples;
                return true;
            }
            if (settings.diskCache && WavUtility.TryLoad(Path.Combine(CacheDir, key + ".wav"), out samples, out int sr) && sr == SampleRate)
            {
                AddToMemory(key, samples);
                return true;
            }
            samples = null;
            return false;
        }

        async Task StoreCachedAsync(string key, float[] samples)
        {
            AddToMemory(key, samples);
            if (!settings.diskCache) return;
            string path = Path.Combine(CacheDir, key + ".wav");
            int sr = SampleRate;
            try { await Task.Run(() => WavUtility.Save(path, samples, sr)); }
            catch (Exception e) { Debug.LogWarning($"[OfflineTTS] Disk cache write failed: {e.Message}"); }
        }

        void AddToMemory(string key, float[] samples)
        {
            if (settings.memoryCacheEntries <= 0) return;
            if (_lruIndex.TryGetValue(key, out var existing)) _lru.Remove(existing);
            var node = _lru.AddFirst((key, samples));
            _lruIndex[key] = node;
            while (_lru.Count > settings.memoryCacheEntries)
            {
                _lruIndex.Remove(_lru.Last.Value.key);
                _lru.RemoveLast();
            }
        }

        static string MakeClipName(string text)
        {
            var t = text.Length > 24 ? text.Substring(0, 24) : text;
            return "TTS_" + t.Replace(' ', '_');
        }
    }
}
