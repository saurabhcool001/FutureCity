// FutureCity Offline TTS — local overrides of the global TTS settings.
//
// Add a "TTS Override" component to any GameObject (a dialogue card, a UI panel, an NPC, a scene root)
// and tick only the settings you want to change. Everything underneath that GameObject uses the
// overridden values; everything else keeps the global settings asset. If several overrides are
// nested, the one closest to the object wins for each setting (like CSS / URP Volume overrides).
//
// Precedence for speech settings (highest first):
//   values passed in a TTSRequest by code  >  nearest TTS Override  >  TTS Speaker fields  >  settings asset.
// Precedence for word highlight settings:
//   nearest TTS Override  >  settings asset.

using System;
using System.Collections.Generic;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS
{
    // ---------------------------------------------------------------- highlight settings

    /// <summary>How the word currently being spoken is highlighted in a TextMeshPro text.</summary>
    [Serializable]
    public struct TTSHighlightSettings
    {
        [Tooltip("Highlight the word that is currently being spoken in TextMeshPro texts that have a " +
                 "TTS Word Highlighter component. Off = text stays as it is.")]
        public bool enabled;

        [Tooltip("Recolour the current word with Highlight Color.")]
        public bool applyColor;

        [Tooltip("Colour of the word currently being spoken.")]
        public Color highlightColor;

        [Tooltip("How much the current word zooms in. 1 = no zoom, 1.25 = 25% bigger, 2 = double size.")]
        [Range(1f, 2f)] public float zoomScale;

        [Tooltip("How long the zoom-in (pop) animation takes, in seconds. Smaller = snappier.")]
        [Range(0.02f, 0.6f)] public float popDuration;

        [Tooltip("Extra 'bounce' at the end of the pop: 0 = smooth ease-in, 1 = strong overshoot.")]
        [Range(0f, 1f)] public float bounce;

        [Tooltip("ON: the word stays zoomed until it has been spoken.\nOFF: the word pops and immediately settles back to normal size.")]
        public bool holdZoomWhileSpoken;

        [Tooltip("Lift the current word up a little, as a fraction of the font size (0 = no lift, 0.15 = small hop).")]
        [Range(0f, 0.5f)] public float lift;

        [Tooltip("Tint words that have already been spoken with Spoken Word Color (karaoke style).")]
        public bool tintSpokenWords;

        [Tooltip("Colour for words that have already been spoken (only used when Tint Spoken Words is on).")]
        public Color spokenWordColor;

        public static TTSHighlightSettings Default => new TTSHighlightSettings
        {
            enabled = true,
            applyColor = true,
            highlightColor = new Color(1f, 0.78f, 0.15f),
            zoomScale = 1.2f,
            popDuration = 0.15f,
            bounce = 0.5f,
            holdZoomWhileSpoken = true,
            lift = 0.08f,
            tintSpokenWords = false,
            spokenWordColor = new Color(0.65f, 0.65f, 0.7f),
        };
    }

    /// <summary>Speech settings resolved from TTS Override components (null / empty = not overridden).</summary>
    public struct TTSSpeechOverrides
    {
        public bool? speechEnabled;
        public string voice;
        public string language;
        public float? speed;
        public int? steps;
        public int? seed;
        public bool? streamSentences;
    }

    // ---------------------------------------------------------------- override value types

    /// <summary>Base for "tick to override" values. The Inspector draws a checkbox + the value on one line.</summary>
    [Serializable] public abstract class TTSOverrideValue { public bool overrideState; }

    [Serializable] public class OverrideBool : TTSOverrideValue { public bool value; public OverrideBool(bool v = false) => value = v; }
    [Serializable] public class OverrideFloat : TTSOverrideValue { public float value; public OverrideFloat(float v = 0f) => value = v; }
    [Serializable] public class OverrideInt : TTSOverrideValue { public int value; public OverrideInt(int v = 0) => value = v; }
    [Serializable] public class OverrideColor : TTSOverrideValue { public Color value; public OverrideColor(Color v) => value = v; public OverrideColor() => value = Color.white; }
    [Serializable] public class OverrideVoice : TTSOverrideValue { public string value; public OverrideVoice(string v = "F1") => value = v; }
    [Serializable] public class OverrideLanguage : TTSOverrideValue { public string value; public OverrideLanguage(string v = "en") => value = v; }

    /// <summary>Slider range for an override value in the Inspector (not a PropertyAttribute on purpose).</summary>
    [AttributeUsage(AttributeTargets.Field)]
    public class TTSOverrideRangeAttribute : Attribute
    {
        public readonly float min, max;
        public TTSOverrideRangeAttribute(float min, float max) { this.min = min; this.max = max; }
    }

    // ---------------------------------------------------------------- component

    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/TTS Override")]
    [DisallowMultipleComponent]
    public class TTSOverride : MonoBehaviour
    {
        [Tooltip("ON: overrides apply to this GameObject and everything under it.\nOFF: only to components on this same GameObject.")]
        public bool applyToChildren = true;

        [Header("Speech")]
        [Tooltip("Turn speech on/off here. Off = TTS Speakers under this object stay silent, and dialogue integrations skip TTS for it.")]
        public OverrideBool speechEnabled = new OverrideBool(true);

        [Tooltip("Voice used here instead of the speaker's / global voice.")]
        public OverrideVoice voice = new OverrideVoice("F1");

        [Tooltip("Language used here.")]
        public OverrideLanguage language = new OverrideLanguage("en");

        [Tooltip("Speaking rate here. 1.0 = natural.")]
        [TTSOverrideRange(0.5f, 2f)] public OverrideFloat speed = new OverrideFloat(1.05f);

        [Tooltip("Quality steps here (1–16).")]
        [TTSOverrideRange(1, 16)] public OverrideInt steps = new OverrideInt(8);

        [Tooltip("Random seed here (-1 = random each time).")]
        public OverrideInt seed = new OverrideInt(42);

        [Tooltip("Sentence streaming here (start talking after the first sentence).")]
        public OverrideBool streamSentences = new OverrideBool(true);

        [Header("Word Highlight")]
        [Tooltip("Turn word highlighting on/off here (e.g. off for a few specific cards).")]
        public OverrideBool highlightEnabled = new OverrideBool(true);

        [Tooltip("Recolour the current word.")]
        public OverrideBool applyColor = new OverrideBool(true);

        [Tooltip("Colour of the word being spoken.")]
        public OverrideColor highlightColor = new OverrideColor(new Color(1f, 0.78f, 0.15f));

        [Tooltip("Zoom of the current word (1 = none, 2 = double).")]
        [TTSOverrideRange(1f, 2f)] public OverrideFloat zoomScale = new OverrideFloat(1.2f);

        [Tooltip("Pop animation length in seconds.")]
        [TTSOverrideRange(0.02f, 0.6f)] public OverrideFloat popDuration = new OverrideFloat(0.15f);

        [Tooltip("Pop overshoot (0 = smooth, 1 = bouncy).")]
        [TTSOverrideRange(0f, 1f)] public OverrideFloat bounce = new OverrideFloat(0.5f);

        [Tooltip("Keep the word zoomed until it has been spoken (off = pop and settle).")]
        public OverrideBool holdZoomWhileSpoken = new OverrideBool(true);

        [Tooltip("Lift of the current word as a fraction of font size.")]
        [TTSOverrideRange(0f, 0.5f)] public OverrideFloat lift = new OverrideFloat(0.08f);

        [Tooltip("Tint already-spoken words (karaoke style).")]
        public OverrideBool tintSpokenWords = new OverrideBool(false);

        [Tooltip("Colour of already-spoken words.")]
        public OverrideColor spokenWordColor = new OverrideColor(new Color(0.65f, 0.65f, 0.7f));

        // ---------------------------------------------------------------- resolution

        static readonly List<TTSOverride> _chain = new List<TTSOverride>();

        /// <summary>Overrides affecting <paramref name="target"/>, ordered from farthest ancestor to nearest.</summary>
        static List<TTSOverride> Chain(Transform target)
        {
            _chain.Clear();
            for (var t = target; t != null; t = t.parent)
            {
                var o = t.GetComponent<TTSOverride>();
                if (o != null && o.isActiveAndEnabled && (o.applyToChildren || t == target)) _chain.Add(o);
            }
            _chain.Reverse();
            return _chain;
        }

        /// <summary>The global highlight settings with every TTS Override above <paramref name="target"/> applied.</summary>
        public static TTSHighlightSettings ResolveHighlight(Transform target)
        {
            var s = GlobalSettings != null ? GlobalSettings.wordHighlight : TTSHighlightSettings.Default;
            if (target == null) return s;
            foreach (var o in Chain(target))
            {
                if (o.highlightEnabled.overrideState) s.enabled = o.highlightEnabled.value;
                if (o.applyColor.overrideState) s.applyColor = o.applyColor.value;
                if (o.highlightColor.overrideState) s.highlightColor = o.highlightColor.value;
                if (o.zoomScale.overrideState) s.zoomScale = o.zoomScale.value;
                if (o.popDuration.overrideState) s.popDuration = o.popDuration.value;
                if (o.bounce.overrideState) s.bounce = o.bounce.value;
                if (o.holdZoomWhileSpoken.overrideState) s.holdZoomWhileSpoken = o.holdZoomWhileSpoken.value;
                if (o.lift.overrideState) s.lift = o.lift.value;
                if (o.tintSpokenWords.overrideState) s.tintSpokenWords = o.tintSpokenWords.value;
                if (o.spokenWordColor.overrideState) s.spokenWordColor = o.spokenWordColor.value;
            }
            return s;
        }

        /// <summary>Speech values overridden by TTS Override components above <paramref name="target"/>.</summary>
        public static TTSSpeechOverrides ResolveSpeech(Transform target)
        {
            var r = new TTSSpeechOverrides();
            if (target == null) return r;
            foreach (var o in Chain(target))
            {
                if (o.speechEnabled.overrideState) r.speechEnabled = o.speechEnabled.value;
                if (o.voice.overrideState) r.voice = o.voice.value;
                if (o.language.overrideState) r.language = o.language.value;
                if (o.speed.overrideState) r.speed = o.speed.value;
                if (o.steps.overrideState) r.steps = o.steps.value;
                if (o.seed.overrideState) r.seed = o.seed.value;
                if (o.streamSentences.overrideState) r.streamSentences = o.streamSentences.value;
            }
            return r;
        }

        /// <summary>The settings asset of the running TTS service (or the project default in edit mode).</summary>
        public static TTSSettings GlobalSettings
        {
            get
            {
                if (OfflineTTS.Instance != null && OfflineTTS.Instance.Settings != null) return OfflineTTS.Instance.Settings;
                if (EditorDefaultSettings != null) return EditorDefaultSettings;
                return TTSSettings.FindLoaded();
            }
        }

        /// <summary>Set by the Editor assembly so edit-mode previews use the project's settings asset.</summary>
        public static TTSSettings EditorDefaultSettings;
    }
}

namespace SaurabhFutureCity.OfflineTTS
{
    /// <summary>
    /// Per-object highlight look: tick any setting to override it for this object only.
    /// Unticked settings keep the value from TTS Override components above it, or the global settings asset.
    /// </summary>
    [Serializable]
    public class TTSHighlightOverrides
    {
        [Tooltip("Turn word highlighting on/off for this text only.")]
        public OverrideBool enabled = new OverrideBool(true);

        [Tooltip("Recolour the current word in this text.")]
        public OverrideBool applyColor = new OverrideBool(true);

        [Tooltip("Colour of the word being spoken in this text.")]
        public OverrideColor highlightColor = new OverrideColor(new Color(1f, 0.78f, 0.15f));

        [Tooltip("How much the current word zooms in (1 = no zoom, 1.25 = 25% bigger, 2 = double size).")]
        [TTSOverrideRange(1f, 2f)] public OverrideFloat zoomScale = new OverrideFloat(1.2f);

        [Tooltip("How long the zoom-in (pop) animation takes, in seconds. Smaller = snappier.")]
        [TTSOverrideRange(0.02f, 0.6f)] public OverrideFloat popDuration = new OverrideFloat(0.15f);

        [Tooltip("Overshoot at the end of the pop: 0 = smooth, 1 = bouncy.")]
        [TTSOverrideRange(0f, 1f)] public OverrideFloat bounce = new OverrideFloat(0.5f);

        [Tooltip("ON: the word stays zoomed until it has been spoken. OFF: it pops and settles back.")]
        public OverrideBool holdZoomWhileSpoken = new OverrideBool(true);

        [Tooltip("Lift the current word up a little, as a fraction of the font size (0 = none).")]
        [TTSOverrideRange(0f, 0.5f)] public OverrideFloat lift = new OverrideFloat(0.08f);

        [Tooltip("Tint words that have already been spoken (karaoke style).")]
        public OverrideBool tintSpokenWords = new OverrideBool(false);

        [Tooltip("Colour of words already spoken (when Tint Spoken Words is on).")]
        public OverrideColor spokenWordColor = new OverrideColor(new Color(0.65f, 0.65f, 0.7f));

        /// <summary>Applies the ticked values on top of <paramref name="s"/>.</summary>
        public void Apply(ref TTSHighlightSettings s)
        {
            if (enabled.overrideState) s.enabled = enabled.value;
            if (applyColor.overrideState) s.applyColor = applyColor.value;
            if (highlightColor.overrideState) s.highlightColor = highlightColor.value;
            if (zoomScale.overrideState) s.zoomScale = zoomScale.value;
            if (popDuration.overrideState) s.popDuration = popDuration.value;
            if (bounce.overrideState) s.bounce = bounce.value;
            if (holdZoomWhileSpoken.overrideState) s.holdZoomWhileSpoken = holdZoomWhileSpoken.value;
            if (lift.overrideState) s.lift = lift.value;
            if (tintSpokenWords.overrideState) s.tintSpokenWords = tintSpokenWords.value;
            if (spokenWordColor.overrideState) s.spokenWordColor = spokenWordColor.value;
        }

        /// <summary>Copies values from <paramref name="s"/> and ticks (or unticks) every setting.</summary>
        public void SetAll(TTSHighlightSettings s, bool overrideAll)
        {
            enabled.value = s.enabled; applyColor.value = s.applyColor; highlightColor.value = s.highlightColor;
            zoomScale.value = s.zoomScale; popDuration.value = s.popDuration; bounce.value = s.bounce;
            holdZoomWhileSpoken.value = s.holdZoomWhileSpoken; lift.value = s.lift;
            tintSpokenWords.value = s.tintSpokenWords; spokenWordColor.value = s.spokenWordColor;
            foreach (var o in All) o.overrideState = overrideAll;
        }

        public bool AnyOverridden { get { foreach (var o in All) if (o.overrideState) return true; return false; } }

        TTSOverrideValue[] All => new TTSOverrideValue[]
            { enabled, applyColor, highlightColor, zoomScale, popDuration, bounce, holdZoomWhileSpoken, lift, tintSpokenWords, spokenWordColor };
    }
}
