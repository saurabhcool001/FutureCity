// FutureCity Offline TTS
// Put this on an NPC (or narrator) next to an AudioSource. Anything that reads the AudioSource
// (lip sync, spatializers, Unity Recorder) works with TTS output exactly like recorded dialogue.

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;

namespace SaurabhFutureCity.OfflineTTS
{
    [RequireComponent(typeof(AudioSource))]
    [AddComponentMenu("FutureCity/Plugins/OfflineTTS/TTS Speaker")]
    public class TTSSpeaker : MonoBehaviour
    {
        [Header("Voice")]
        [Tooltip("Which voice this character speaks with.\nFemale 1–5 (F1–F5) or Male 1–5 (M1–M5). " +
                 "Voices registered from code (e.g. blends via OfflineTTS.RegisterVoice) can also be set by name from scripts.")]
        [TTSVoice]
        public string voice = "F1";

        [Tooltip("Language of the text this character speaks. The text itself must be written in this language — " +
                 "TTS does not translate.")]
        [TTSLanguage]
        public string language = "en";

        [Tooltip("Speaking rate for this character. 1.0 = natural, < 1 slower, > 1 faster (pitch is unchanged).\n" +
                 "-1 = use the settings asset's Speed.")]
        public float speed = -1f;

        [Tooltip("Quality steps for this character (1–16). Higher = cleaner but slower to generate.\n" +
                 "-1 = use the settings asset (Steps on PC, Mobile Steps on headsets).")]
        public int steps = -1;

        [Tooltip("Random seed for the delivery. With a fixed seed, the same line always sounds exactly the same " +
                 "(and the disk cache can reuse it). Try different numbers to get a different intonation/take.\n" +
                 "-1 = different every time (disables effective caching).")]
        public int seed = 42;

        [Header("Playback")]
        [Tooltip("ON: start talking as soon as the first sentence is generated while the rest is generated in the " +
                 "background (much lower wait on headsets).\nOFF: generate the whole line first, then play it in one piece.")]
        public bool streamSentences = true;

        [Tooltip("ON: calling Speak() while talking stops the current line and starts the new one (typical for dialogue skipping).\n" +
                 "OFF: new lines are queued and played one after another.")]
        public bool interrupt = true;

        [Tooltip("On Awake, set the AudioSource up for 3D spatial audio (full 3D blend, logarithmic roll-off 1–20 m, " +
                 "spatializer plugin on) so the voice comes from the character's position in VR.\n" +
                 "Turn off to keep your own AudioSource settings.")]
        public bool configureSpatialAudio = true;

        [Tooltip("Also follow baked or human-recorded clips that OTHER scripts play on this AudioSource (an NPC voice script, " +
                 "a dialogue system, Timeline…). If the clip has word timings (Voice-over Baker / Word Timing Generator), " +
                 "word highlighting works exactly like live TTS. Clips without timings are ignored.")]
        public bool followExternalClips = true;

        [Tooltip("Log what this speaker does to the Console: lines started/finished/stopped, baked or recorded clips it " +
                 "follows, clips it ignores because they have no word timings, and lines it drops because another script " +
                 "started a clip. Turn on when highlighting doesn't appear.")]
        public bool debugLog = false;

        [Header("Events")]
        [Tooltip("Invoked with the line's text when audio for the line actually starts playing.\n" +
                 "Use it to start talking animations, subtitles, etc.")]
        public UnityEvent<string> onSpeechStarted = new UnityEvent<string>();

        [Tooltip("Invoked with the line's text when the line has finished playing (not called when it is stopped/interrupted).\n" +
                 "Use it to advance dialogue or end animations.")]
        public UnityEvent<string> onSpeechFinished = new UnityEvent<string>();

        [Tooltip("Invoked with an error message if generation fails (e.g. unknown voice, model not loaded).")]
        public UnityEvent<string> onError = new UnityEvent<string>();

        [Tooltip("Invoked with the line-level word index whenever the word being spoken changes (-1 = between words / finished).\n" +
                 "Words are counted with TTSText.Words(CurrentLineText). Word timing is estimated from the audio.")]
        public UnityEvent<int> onWordChanged = new UnityEvent<int>();

        /// <summary>Raised by every speaker when its current word changes (speaker, word index). Useful for global subtitle/highlight systems.</summary>
        public static event Action<TTSSpeaker, int> AnyWordChanged;
        /// <summary>Raised by every speaker when a line starts playing (speaker, spoken text).</summary>
        public static event Action<TTSSpeaker, string> AnyLineStarted;
        /// <summary>Raised by every speaker when a line ends or is stopped (speaker).</summary>
        public static event Action<TTSSpeaker> AnyLineEnded;

        public AudioSource Source { get; private set; }
        /// <summary>True while a TTS line is generating/playing, or a timed baked/recorded clip is playing.</summary>
        public bool IsSpeaking => _active != null || _external != null;
        /// <summary>True while following a baked or recorded clip that another script played on this AudioSource.</summary>
        public bool IsFollowingExternalClip => _external != null;
        public bool IsGenerating { get; private set; }

        /// <summary>Text of the line currently playing (as spoken, after rich-text removal), or null.</summary>
        public string CurrentLineText => _active != null && _active.started ? _active.text : _external?.text;
        /// <summary>Words of the current line (TTSText.Words), or an empty list.</summary>
        public IReadOnlyList<string> CurrentLineWords => _active != null && _active.started ? _active.words
                                                       : _external != null ? _externalWords : (IReadOnlyList<string>)Array.Empty<string>();
        /// <summary>Index into CurrentLineWords of the word being spoken now, or -1.</summary>
        public int CurrentWordIndex { get; private set; } = -1;
        /// <summary>0..1 progress through the current word.</summary>
        public float CurrentWordProgress { get; private set; }

        class Piece
        {
            public AudioClip clip;
            public TTSWordTiming[] words;
        }

        class Line
        {
            public string text;
            public List<string> words;
            public readonly Queue<Piece> pieces = new Queue<Piece>();
            public readonly List<AudioClip> owned = new List<AudioClip>();
            public Piece playing;
            public bool generationDone;
            public bool started;
            public TaskCompletionSource<bool> done = new TaskCompletionSource<bool>();
            public CancellationTokenSource cts = new CancellationTokenSource();
            public TTSRequest overrides;
            public AudioClip sourceClipAtQueue;   // what the AudioSource held when this line was queued
        }

        readonly Queue<Line> _pending = new Queue<Line>();
        TTSClipTiming _external;               // timed clip another script is playing on our AudioSource
        AudioClip _externalClip;
        List<string> _externalWords;
        AudioClip _lastCheckedClip;
        Line _active;
        bool _paused;
        float _lastPlaybackTime;

        [ThreadStatic] static bool s_keepAudioSettingsOnce;

        /// <summary>
        /// Adds a TTS Speaker to a GameObject that already has a configured AudioSource (e.g. one managed by an
        /// existing NPC voice script) without touching its 3D settings. Use this instead of AddComponent from code.
        /// </summary>
        public static TTSSpeaker AddTo(GameObject target, string voiceId = null, bool configureSpatialAudio = false)
        {
            s_keepAudioSettingsOnce = !configureSpatialAudio;
            try
            {
                var speaker = target.AddComponent<TTSSpeaker>();
                speaker.configureSpatialAudio = configureSpatialAudio;
                if (!string.IsNullOrEmpty(voiceId)) speaker.voice = voiceId;
                return speaker;
            }
            finally { s_keepAudioSettingsOnce = false; }
        }

        void Awake()
        {
            Source = GetComponent<AudioSource>();
            Source.playOnAwake = false;
            Source.loop = false;
            if (configureSpatialAudio && !s_keepAudioSettingsOnce)
            {
                Source.spatialBlend = 1f;
                Source.rolloffMode = AudioRolloffMode.Logarithmic;
                Source.minDistance = 1f;
                Source.maxDistance = 20f;
                Source.spatialize = true; // uses the project's spatializer plugin (Meta XR Audio, Resonance, etc.) if one is set
            }
        }

        // ------------------------------------------------------------------ public API

        /// <summary>Fire-and-forget speak (usable from UnityEvents / dialogue nodes).</summary>
        public void Speak(string text) => _ = SpeakAsync(text);

        /// <summary>Speaks a line. Completes when playback ends: true if it played to the end, false if stopped/interrupted/disabled.</summary>
        public Task<bool> SpeakAsync(string text, CancellationToken ct = default) => SpeakAsync(text, null, ct);

        /// <summary>
        /// Speaks a line with per-call overrides (voice, language, speed, steps, seed — empty / -1 fields are ignored).
        /// Rich-text tags in <paramref name="text"/> are removed before speaking.
        /// </summary>
        public Task<bool> SpeakAsync(string text, TTSRequest overrides, CancellationToken ct = default)
        {
            text = TTSText.ToSpeakable(text);
            if (string.IsNullOrWhiteSpace(text)) return Task.FromResult(false);

            var local = TTSOverride.ResolveSpeech(transform);
            if (local.speechEnabled == false) return Task.FromResult(false);

            if (interrupt) Stop();

            var line = new Line { text = text, words = TTSText.Words(text), overrides = overrides,
                                  sourceClipAtQueue = Source != null ? Source.clip : null };
            if (ct.CanBeCanceled) ct.Register(() => Cancel(line));
            _pending.Enqueue(line);
            _ = GenerateAsync(line, local);
            return line.done.Task;
        }

        /// <summary>
        /// Pre-generates lines with exactly the settings this speaker would use (voice, seed, speed, steps, overrides),
        /// so they're cached and play instantly later. Call during loading / fades.
        /// </summary>
        public async Task PrewarmAsync(IEnumerable<string> lines, TTSRequest overrides = null, CancellationToken ct = default)
        {
            var tts = OfflineTTS.GetOrCreate();
            var local = TTSOverride.ResolveSpeech(transform);
            if (local.speechEnabled == false) return;
            foreach (var raw in lines)
            {
                ct.ThrowIfCancellationRequested();
                string text = TTSText.ToSpeakable(raw);
                if (string.IsNullOrWhiteSpace(text)) continue;
                var r = BuildRequest(overrides, local);
                r.useCache = true;
                await tts.SynthesizeSamplesAsync(text, r, ct);
            }
        }

        public void Stop()
        {
            if (Source != null && _active != null && _active.playing != null && Source.clip == _active.playing.clip) Source.Stop();
            while (_pending.Count > 0) Cancel(_pending.Dequeue());
            if (_active != null) { var a = _active; _active = null; Cancel(a); EndLine(); }
        }

        public void Pause() { _paused = true; Source.Pause(); }
        public void Resume() { _paused = false; Source.UnPause(); }

        // ------------------------------------------------------------------ generation

        /// <summary>Request this speaker would send: per-call overrides > TTS Override > speaker fields > settings.</summary>
        TTSRequest BuildRequest(TTSRequest call, TTSSpeechOverrides local)
        {
            var r = new TTSRequest
            {
                voice = !string.IsNullOrEmpty(local.voice) ? local.voice : voice,
                language = !string.IsNullOrEmpty(local.language) ? local.language : language,
                speed = local.speed ?? speed,
                steps = local.steps ?? steps,
                seed = local.seed ?? seed,
                useCache = true,
            };
            if (call != null)
            {
                if (!string.IsNullOrEmpty(call.voice)) r.voice = call.voice;
                if (!string.IsNullOrEmpty(call.language)) r.language = call.language;
                if (call.speed > 0) r.speed = call.speed;
                if (call.steps > 0) r.steps = call.steps;
                if (call.seed >= 0) r.seed = call.seed;
                r.useCache = call.useCache;
            }
            return r;
        }

        async Task GenerateAsync(Line line, TTSSpeechOverrides local)
        {
            var tts = OfflineTTS.GetOrCreate();
            var request = BuildRequest(line.overrides, local);
            bool stream = local.streamSentences ?? streamSentences;
            IsGenerating = true;
            try
            {
                if (stream)
                    await tts.SynthesizeStreamingWithTimingAsync(line.text, info => Accept(line, info), request, line.cts.Token);
                else
                    Accept(line, await tts.SynthesizeClipWithTimingAsync(line.text, request, line.cts.Token));
            }
            catch (OperationCanceledException) { }
            catch (Exception e)
            {
                Debug.LogError($"[TTSSpeaker:{name}] {e.Message}");
                onError.Invoke(e.Message);
            }
            finally
            {
                line.generationDone = true;
                IsGenerating = false;
            }
        }

        void Accept(Line line, TTSClipInfo info)
        {
            if (info == null || info.clip == null) return;
            if (line.cts.IsCancellationRequested) { Destroy(info.clip); return; }
            line.pieces.Enqueue(new Piece { clip = info.clip, words = info.words });
            line.owned.Add(info.clip);
        }

        // ------------------------------------------------------------------ playback

        void Update()
        {
            if (_paused) return;

            if (_active == null)
            {
                if (_pending.Count == 0) { FollowExternalClip(); return; }
                EndExternalClip();
                _active = _pending.Dequeue();
            }

            // Another script started its own clip on the shared AudioSource while this line was still being
            // generated (before any of it played): that clip wins. Drop this line and follow the clip instead
            // (otherwise the generated audio would start over it, and a baked clip wouldn't be highlighted).
            if (_active.playing == null && ClipStartedByOtherScript())
            {
                Log($"Dropped TTS line \"{Short(_active.text)}\": another script started '{Source.clip.name}' before it began.");
                var a = _active; _active = null;
                Cancel(a);
                EndLine();
                FollowExternalClip();
                return;
            }

            // Another script (e.g. an existing voice/audio component) stopped our audio or put its own clip
            // on the shared AudioSource: drop the rest of this line instead of talking over / after it.
            if (_active.playing != null && ExternallyInterrupted())
            {
                Log($"TTS line \"{Short(_active.text)}\" was stopped or replaced by another script.");
                var a = _active; _active = null;
                Cancel(a);
                EndLine();
                return;
            }

            if (Source.isPlaying && _active.playing != null && Source.clip == _active.playing.clip)
            {
                _lastPlaybackTime = Source.time;
                UpdateWord(Source.time);
                return;
            }

            if (_active.pieces.Count > 0)
            {
                _active.playing = _active.pieces.Dequeue();
                Source.clip = _active.playing.clip;
                _lastPlaybackTime = 0f;
                Source.Play();
                if (!_active.started)
                {
                    _active.started = true;
                    onSpeechStarted.Invoke(_active.text);
                    AnyLineStarted?.Invoke(this, _active.text);
                    Log($"TTS line started: \"{Short(_active.text)}\"");
                }
                UpdateWord(0f);
            }
            else if (_active.generationDone)
            {
                var finished = _active;
                _active = null;
                if (finished.started) onSpeechFinished.Invoke(finished.text);
                Log($"TTS line finished: \"{Short(finished.text)}\"");
                Release(finished);
                EndLine();
                finished.done.TrySetResult(true);
            }
            else
            {
                SetWord(-1, 0f); // waiting for the next sentence
            }
        }

        bool ClipStartedByOtherScript() =>
            Source != null && Source.isPlaying && Source.clip != null &&
            Source.clip != _active.sourceClipAtQueue && !_active.owned.Contains(Source.clip);

        bool ExternallyInterrupted()
        {
            var expected = _active.playing.clip;
            if (Source.clip != expected) return true;                      // someone swapped the clip
            if (!Source.isPlaying)
            {
                // Natural end: we last saw the playhead near the end. Otherwise someone called Stop().
                return expected != null && _lastPlaybackTime < expected.length - 0.2f && Application.isFocused;
            }
            return false;
        }

        void UpdateWord(float time)
        {
            var timings = _active?.playing?.words;
            int i = WordTimingEstimator.FindWordAt(timings, time);
            if (i < 0) { SetWord(-1, 0f); return; }
            var w = timings[i];
            float progress = w.end > w.start ? Mathf.Clamp01((time - w.start) / (w.end - w.start)) : 1f;
            SetWord(w.wordIndex, progress);
        }

        // ------------------------------------------------------------------ baked / recorded clips

        void FollowExternalClip()
        {
            if (!followExternalClips || Source == null) { EndExternalClip(); return; }

            AudioClip clip = Source.clip;
            if (clip != null && Source.isPlaying)
            {
                if (clip != _externalClip)
                {
                    EndExternalClip();
                    if (clip != _lastCheckedClip)   // look each new clip up once (clips without timings are skipped)
                    {
                        _lastCheckedClip = clip;
                        if (TTSClipTimings.TryGet(clip, out var timing) && timing.words != null && timing.words.Length > 0)
                        {
                            _external = timing;
                            _externalClip = clip;
                            _externalWords = TTSText.Words(TTSText.ToSpeakable(timing.text));
                            Log($"Following '{clip.name}' ({timing.words.Length} timed words): \"{Short(timing.text)}\"");
                            AnyLineStarted?.Invoke(this, TTSText.ToSpeakable(timing.text));
                        }
                        else
                        {
                            Log($"'{clip.name}' started but has NO word timings in a linked timing library, so it can't be highlighted. " +
                                "Bake with 'Save word timings' or use the Word Timing Generator, then FutureCity ▸ Plugins ▸ OfflineTTS ▸ Repair Timing Library.");
                        }
                    }
                }
                if (_external != null)
                {
                    float time = Source.time;
                    int i = WordTimingEstimator.FindWordAt(_external.words, time);
                    if (i < 0) SetWord(-1, 0f);
                    else
                    {
                        var w = _external.words[i];
                        SetWord(w.wordIndex, w.end > w.start ? Mathf.Clamp01((time - w.start) / (w.end - w.start)) : 1f);
                    }
                }
            }
            else if (_external != null)
            {
                EndExternalClip();   // finished, stopped or paused by the other script
            }
            else if (clip == null || !Source.isPlaying)
            {
                _lastCheckedClip = null;
            }
        }

        void EndExternalClip()
        {
            if (_external == null) return;
            _external = null;
            _externalClip = null;
            _externalWords = null;
            _lastCheckedClip = null;
            EndLine();
        }

        void Log(string message)
        {
            if (debugLog) Debug.Log($"[TTSSpeaker:{name}] {message}", this);
        }

        static string Short(string s) => string.IsNullOrEmpty(s) ? "" : (s.Length > 50 ? s.Substring(0, 50) + "…" : s);

        void SetWord(int index, float progress)
        {
            CurrentWordProgress = progress;
            if (index == CurrentWordIndex) return;
            CurrentWordIndex = index;
            onWordChanged.Invoke(index);
            AnyWordChanged?.Invoke(this, index);
        }

        void EndLine()
        {
            SetWord(-1, 0f);
            AnyLineEnded?.Invoke(this);
        }

        void Cancel(Line line)
        {
            line.cts.Cancel();
            Release(line);
            line.done.TrySetResult(false);
        }

        void Release(Line line)
        {
            // Destroy generated clips to avoid leaking audio memory over long sessions.
            if (Source != null && Source.clip != null && line.owned.Contains(Source.clip))
            {
                Source.Stop();
                Source.clip = null;
            }
            foreach (var c in line.owned) if (c != null) Destroy(c);
            line.owned.Clear();
            line.pieces.Clear();
            line.playing = null;
        }

        void OnDisable() => Stop();
    }
}
