# FutureCity Offline TTS

Offline neural text-to-speech for FutureCity. Use it when the AI speaks or when important text should be read
aloud with the spoken word highlighted. Everything runs on the device (Quest / Android XR or desktop); no internet
is needed at runtime.

## Set up
1. Install: Package Manager ▸ **+** ▸ **Add package from tarball…** ▸ `com.saurabh.futurecity.offlinetts-1.0.0.tgz`.
   The first import adds the ONNX Runtime registry and package automatically.
2. **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Download Supertonic 3 Models** (saved to `StreamingAssets/Supertonic`).
3. **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Create or Locate Settings Asset**, then **Add TTS Service To Scene**.

## Use
- **Speak:** add a `TTSSpeaker` next to an AudioSource and call `speaker.Speak("text")` (or `await SpeakAsync`).
- **Highlight:** add a `TTSWordHighlighter` to a TextMeshPro text. It follows any speaker saying the same text, or
  a speaker you give it with `Bind(speaker)`.
- **Bake:** **FutureCity ▸ Plugins ▸ OfflineTTS ▸ Voice-over Baker** turns fixed lines into WAV files with word
  timings, so headsets play them instantly and highlighting still works.
- **Check:** **Run Diagnostics (no Play mode)** loads the model and speaks a test line in the Editor.

See `Documentation~/index.md` for details. Third-party licences: `THIRD_PARTY_NOTICES.md`.
