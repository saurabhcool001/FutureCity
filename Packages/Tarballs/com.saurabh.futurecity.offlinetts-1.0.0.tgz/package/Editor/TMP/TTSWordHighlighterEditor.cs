// FutureCity Offline TTS — Inspector for TTS Word Highlighter: per-object look, quick buttons, effective values, preview.
using UnityEditor;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    [CustomEditor(typeof(TTSWordHighlighter))]
    [CanEditMultipleObjects]
    public class TTSWordHighlighterEditor : UnityEditor.Editor
    {
        bool _showEffective = true;
        float _previewSpeed = 0.35f;

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("listenTo"));
            var mode = (TTSWordHighlighter.ListenMode)serializedObject.FindProperty("listenTo").enumValueIndex;
            if (mode == TTSWordHighlighter.ListenMode.SpecificSpeakers)
                EditorGUILayout.PropertyField(serializedObject.FindProperty("speakers"), true);
            if (mode == TTSWordHighlighter.ListenMode.AnySpeakerWithMatchingText)
                EditorGUILayout.PropertyField(serializedObject.FindProperty("minimumMatch"));

            EditorGUILayout.Space();
            EditorGUILayout.LabelField(new GUIContent("Look — this text only",
                "Tick a setting to override it for this text. Unticked = value from parent TTS Overrides or the global settings asset."),
                EditorStyles.boldLabel);

            var look = serializedObject.FindProperty("look");
            foreach (var name in new[] { "enabled", "applyColor", "highlightColor", "zoomScale", "popDuration", "bounce",
                                         "holdZoomWhileSpoken", "lift", "tintSpokenWords", "spokenWordColor" })
                EditorGUILayout.PropertyField(look.FindPropertyRelative(name), new GUIContent(ObjectNames.NicifyVariableName(name),
                    TooltipFor(name)));
            serializedObject.ApplyModifiedProperties();

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(new GUIContent("Customise all", "Tick every setting and fill it with the current effective values, " +
                                                                     "so you can tweak this text's look from where it is now.")))
                    ForEach(h => h.look.SetAll(Effective(h, withLocal: true), overrideAll: true), "Customise highlight");
                if (GUILayout.Button(new GUIContent("Use global", "Untick everything: this text follows parent TTS Overrides / the settings asset again.")))
                    ForEach(h => h.look.SetAll(Effective(h, withLocal: false), overrideAll: false), "Reset highlight look");
            }

            var target0 = (TTSWordHighlighter)target;
            _showEffective = EditorGUILayout.Foldout(_showEffective, new GUIContent("Effective look (what this text will use)",
                "Global settings asset → TTS Override components on parents → this component's ticked values."), true);
            if (_showEffective)
            {
                var e = target0.EffectiveSettings;
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUI.indentLevel++;
                    EditorGUILayout.Toggle("Enabled", e.enabled);
                    EditorGUILayout.ColorField("Highlight Color", e.applyColor ? e.highlightColor : Color.clear);
                    EditorGUILayout.FloatField("Zoom Scale", e.zoomScale);
                    EditorGUILayout.FloatField("Pop Duration (s)", e.popDuration);
                    EditorGUILayout.FloatField("Bounce", e.bounce);
                    EditorGUILayout.Toggle("Hold Zoom While Spoken", e.holdZoomWhileSpoken);
                    EditorGUILayout.FloatField("Lift", e.lift);
                    EditorGUILayout.Toggle("Tint Spoken Words", e.tintSpokenWords);
                    EditorGUI.indentLevel--;
                }
                if (TTSOverride.GlobalSettings != null && GUILayout.Button(new GUIContent("Select global settings asset",
                        "Open the settings asset that holds the default (global) highlight look.")))
                    Selection.activeObject = TTSOverride.GlobalSettings;
            }

            EditorGUILayout.Space();
            using (new EditorGUI.DisabledScope(!Application.isPlaying))
            using (new EditorGUILayout.HorizontalScope())
            {
                _previewSpeed = EditorGUILayout.Slider(new GUIContent("Preview speed (s/word)",
                    "Seconds each word stays highlighted during the preview."), _previewSpeed, 0.1f, 1f);
                if (GUILayout.Button(new GUIContent(target0.IsPreviewing ? "Stop" : "Preview",
                        "Play mode: step through this text's words without speech to see the look."), GUILayout.Width(70)))
                {
                    if (target0.IsPreviewing) target0.StopPreview(); else target0.PreviewHighlight(_previewSpeed);
                }
            }
            if (!Application.isPlaying)
                EditorGUILayout.HelpBox("Enter Play mode to preview the highlight on this text.", MessageType.None);
            if (Application.isPlaying && target0.IsPreviewing) Repaint();
        }

        static TTSHighlightSettings Effective(TTSWordHighlighter h, bool withLocal)
        {
            var s = TTSOverride.ResolveHighlight(h.transform);
            if (withLocal) h.look.Apply(ref s);
            return s;
        }

        void ForEach(System.Action<TTSWordHighlighter> action, string undoName)
        {
            foreach (var t in targets)
            {
                var h = (TTSWordHighlighter)t;
                Undo.RecordObject(h, undoName);
                action(h);
                EditorUtility.SetDirty(h);
            }
        }

        static string TooltipFor(string name)
        {
            switch (name)
            {
                case "enabled": return "Turn highlighting on/off for this text only.";
                case "applyColor": return "Recolour the word being spoken.";
                case "highlightColor": return "Colour of the word being spoken.";
                case "zoomScale": return "How much the word zooms in: 1 = none, 1.25 = 25% bigger, 2 = double.";
                case "popDuration": return "Length of the zoom-in animation in seconds (smaller = snappier).";
                case "bounce": return "Overshoot at the end of the pop: 0 = smooth, 1 = bouncy.";
                case "holdZoomWhileSpoken": return "On: word stays zoomed until spoken. Off: pops and settles back.";
                case "lift": return "Small upward hop, as a fraction of the font size.";
                case "tintSpokenWords": return "Karaoke style: colour words that were already spoken.";
                case "spokenWordColor": return "Colour of already-spoken words.";
            }
            return null;
        }
    }
}
