// FutureCity Offline TTS — Editor setup utilities.
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.UnityLinker;
using UnityEngine;
using UnityEngine.Networking;
using Object = UnityEngine.Object;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    public static class TTSModelSetup
    {
        const string BaseUrlPref = "SaurabhFutureCity.OfflineTTS.ModelBaseUrl";
        public const string DefaultBaseUrl = "https://huggingface.co/supertone-oss-archive/supertonic-3/resolve/main";

        public static string BaseUrl
        {
            get => EditorPrefs.GetString(BaseUrlPref, DefaultBaseUrl);
            set => EditorPrefs.SetString(BaseUrlPref, value);
        }

        public static string StreamingRoot(TTSSettings s = null) =>
            Path.Combine(Application.streamingAssetsPath, s != null ? s.modelFolder : "Supertonic");

        public static bool ModelsPresent(TTSSettings s = null)
        {
            var onnx = Path.Combine(StreamingRoot(s), ModelLocator.OnnxSubfolder);
            return SupertonicEngine.RequiredFiles.All(f => File.Exists(Path.Combine(onnx, f)));
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Download Supertonic 3 Models", priority = 1)]
        public static async void DownloadModels()
        {
            string root = StreamingRoot();
            if (!EditorUtility.DisplayDialog("Download Supertonic 3",
                    $"Download the Supertonic 3 ONNX models and 10 voices (~400 MB) from:\n{BaseUrl}\n\ninto:\n{root}\n\n" +
                    "The model weights are licensed under OpenRAIL-M (see LICENSE in the folder after download).",
                    "Download", "Cancel")) return;

            var files = SupertonicEngine.RequiredFiles.Select(f => $"{ModelLocator.OnnxSubfolder}/{f}")
                .Concat(ModelLocator.BuiltInVoices.Select(v => $"{ModelLocator.VoiceSubfolder}/{v}.json"))
                .Append("LICENSE")
                .ToArray();
            try
            {
                for (int i = 0; i < files.Length; i++)
                {
                    string dest = Path.Combine(root, files[i]);
                    if (File.Exists(dest) && new FileInfo(dest).Length > 0) continue;
                    await DownloadAsync($"{BaseUrl}/{files[i]}", dest, files[i], i, files.Length);
                }
                Debug.Log($"[OfflineTTS] Models ready in {root}");
            }
            catch (Exception e)
            {
                Debug.LogError($"[OfflineTTS] Model download failed: {e.Message}\nYou can also download manually (see README) into {root}.");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
                AssetDatabase.Refresh();
            }
        }

        static async Task DownloadAsync(string url, string dest, string label, int index, int count)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(dest));
            string tmp = dest + ".part";
            using (var req = new UnityWebRequest(url, UnityWebRequest.kHttpVerbGET))
            {
                req.downloadHandler = new DownloadHandlerFile(tmp) { removeFileOnAbort = true };
                var op = req.SendWebRequest();
                while (!op.isDone)
                {
                    if (EditorUtility.DisplayCancelableProgressBar("Offline TTS", $"Downloading {label} ({index + 1}/{count})",
                            (index + req.downloadProgress) / count))
                    {
                        req.Abort();
                        throw new OperationCanceledException("Download cancelled.");
                    }
                    await Task.Delay(100);
                }
                if (req.result != UnityWebRequest.Result.Success) throw new IOException($"{label}: {req.error}");
            }
            if (File.Exists(dest)) File.Delete(dest);
            File.Move(tmp, dest);
        }

        /// <summary>Where a new settings asset is created when none exists in the project.</summary>
        public const string SettingsFolder = "Assets/Features/TTS";
        public const string SettingsFileName = "OfflineTTSSettings.asset";

        /// <summary>Creates every missing folder in an "Assets/..." path through the AssetDatabase.</summary>
        public static void EnsureAssetFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder)) return;
            string parent = "Assets";
            foreach (var part in folder.Split('/').Skip(1))
            {
                string next = $"{parent}/{part}";
                if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(parent, part);
                parent = next;
            }
        }

        /// <summary>All TTSSettings assets in the project (any folder, any file name), sorted by path.</summary>
        public static string[] FindSettingsPaths() =>
            AssetDatabase.FindAssets($"t:{nameof(TTSSettings)}")
                .Select(g => AssetDatabase.GUIDToAssetPath(g))
                .Where(p => p.EndsWith(".asset"))
                .OrderBy(p => p)
                .ToArray();

        /// <summary>Returns the project's settings asset, preferring one named "OfflineTTSSettings". Null if none exists.</summary>
        public static TTSSettings FindSettings()
        {
            var paths = FindSettingsPaths();
            if (paths.Length == 0) return null;
            string preferred = paths.FirstOrDefault(p => Path.GetFileNameWithoutExtension(p) == "OfflineTTSSettings") ?? paths[0];
            return AssetDatabase.LoadAssetAtPath<TTSSettings>(preferred);
        }

        /// <summary>Finds the existing settings asset or creates one (only when none exists anywhere in the project).</summary>
        public static TTSSettings FindOrCreateSettings(out bool created)
        {
            var existing = FindSettings();
            if (existing != null) { created = false; return existing; }

            var s = ScriptableObject.CreateInstance<TTSSettings>();
            EnsureAssetFolder(SettingsFolder);
            string path = AssetDatabase.GenerateUniqueAssetPath($"{SettingsFolder}/{SettingsFileName}");
            AssetDatabase.CreateAsset(s, path);
            AssetDatabase.SaveAssets();
            created = true;
            return s;
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Create or Locate Settings Asset", priority = 2)]
        static void CreateOrLocateSettings()
        {
            var settings = FindOrCreateSettings(out bool created);
            string path = AssetDatabase.GetAssetPath(settings);

            if (created)
            {
                Debug.Log($"[OfflineTTS] Created settings asset at {path}");
            }
            else
            {
                var all = FindSettingsPaths();
                if (all.Length > 1)
                    Debug.LogWarning($"[OfflineTTS] {all.Length} TTSSettings assets found; using {path}. Others:\n  " +
                                     string.Join("\n  ", all.Where(p => p != path)));
                else
                    Debug.Log($"[OfflineTTS] Settings asset already exists at {path} (not creating a new one).");
            }

            // Reveal it in the Project window and Inspector.
            EditorUtility.FocusProjectWindow();
            Selection.activeObject = settings;
            EditorGUIUtility.PingObject(settings);
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Add TTS Service To Scene", priority = 3)]
        static void AddService()
        {
            var existing =
#if UNITY_2023_1_OR_NEWER
                Object.FindFirstObjectByType<OfflineTTS>();
#else
                Object.FindObjectOfType<OfflineTTS>();
#endif
            if (existing != null)
            {
                Debug.Log("[OfflineTTS] The scene already has a TTS service; selecting it.");
                Selection.activeObject = existing;
                EditorGUIUtility.PingObject(existing);
                return;
            }

            var go = new GameObject("[OfflineTTS]");
            var service = go.AddComponent<OfflineTTS>();
            AssignSettings(service, FindSettings());
            Undo.RegisterCreatedObjectUndo(go, "Add Offline TTS");
            Selection.activeObject = go;
        }

        /// <summary>Points an OfflineTTS component at a settings asset (serialized field, undo-free).</summary>
        public static void AssignSettings(OfflineTTS service, TTSSettings settings)
        {
            if (service == null || settings == null) return;
            var so = new SerializedObject(service);
            so.FindProperty("settings").objectReferenceValue = settings;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        /// <summary>Writes voice_styles/voices.txt so Android knows which voices to unpack from the APK.</summary>
        public static void WriteVoiceManifest(string root)
        {
            string dir = Path.Combine(root, ModelLocator.VoiceSubfolder);
            if (!Directory.Exists(dir)) return;
            var names = Directory.GetFiles(dir, "*.json").Select(f => Path.GetFileNameWithoutExtension(f)).OrderBy(n => n);
            File.WriteAllText(Path.Combine(dir, "voices.txt"), string.Join("\n", names));
        }
    }

    class TTSBuildPreprocess : IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;

        public void OnPreprocessBuild(BuildReport report)
        {
            foreach (var dir in Directory.Exists(Application.streamingAssetsPath)
                         ? Directory.GetDirectories(Application.streamingAssetsPath)
                         : Array.Empty<string>())
            {
                if (Directory.Exists(Path.Combine(dir, ModelLocator.OnnxSubfolder)))
                    TTSModelSetup.WriteVoiceManifest(dir);
            }

            // Preload the settings asset so it's found in builds even when a scene has no [OfflineTTS] service
            // (needed for auto-created services and for baked-clip word timings).
            var settings = TTSModelSetup.FindSettings();
            if (settings != null)
            {
                var preloaded = PlayerSettings.GetPreloadedAssets().Where(a => a != null).ToList();
                if (!preloaded.Contains(settings))
                {
                    preloaded.Add(settings);
                    PlayerSettings.SetPreloadedAssets(preloaded.ToArray());
                    Debug.Log($"[OfflineTTS] Added {AssetDatabase.GetAssetPath(settings)} to Player Settings ▸ Preloaded Assets.");
                }
            }

            // Word timings for baked/recorded clips: include every timing asset in the build, whichever settings
            // asset the scenes use (the Editor can find stray timings, builds can't).
            if (AssetDatabase.FindAssets("t:TTSClipTiming").Length > 0)
            {
                var (library, total, added, noClip) = TTSTimingAssets.SyncAllTimings();
                Debug.Log($"[OfflineTTS] Build includes {total} word timing(s) from {AssetDatabase.GetAssetPath(library)}" +
                          (added > 0 ? $" ({added} added to the library just now)." : ".") +
                          (noClip > 0 ? $" {noClip} timing asset(s) have no clip and were skipped." : ""));
            }

            if (!TTSModelSetup.ModelsPresent())
                Debug.LogWarning("[OfflineTTS] No Supertonic models found in StreamingAssets/Supertonic. " +
                                 "Runtime TTS will fail unless you load models from persistentDataPath or an absolute path.");
        }
    }

    /// <summary>Keeps ONNX Runtime's managed wrapper (P/Invoke + callbacks) from being stripped in IL2CPP builds.</summary>
    class TTSLinkerProcessor : IUnityLinkerProcessor
    {
        public int callbackOrder => 0;

        public string GenerateAdditionalLinkXmlFile(BuildReport report, UnityLinkerBuildPipelineData data)
        {
            string path = Path.Combine(Path.GetFullPath("Temp"), "FutureCity_OfflineTTS_link.xml");
            File.WriteAllText(path,
                "<linker>\n" +
                "  <assembly fullname=\"com.github.asus4.onnxruntime\" preserve=\"all\"/>\n" +
                "  <assembly fullname=\"SaurabhFutureCity.OfflineTTS\" preserve=\"all\"/>\n" +
                "  <assembly fullname=\"Newtonsoft.Json\">\n" +
                "    <type fullname=\"Newtonsoft.Json.Linq.*\" preserve=\"all\"/>\n" +
                "  </assembly>\n" +
                "</linker>\n");
            return path;
        }
    }
}
