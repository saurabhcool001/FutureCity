// FutureCity Offline TTS — Inspector dropdowns for [TTSVoice] and [TTSLanguage] string fields.
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    [CustomPropertyDrawer(typeof(TTSVoiceAttribute))]
    public class TTSVoiceDrawer : PropertyDrawer
    {
        static string[] _cachedVoices;
        static double _cacheTime;

        /// <summary>Voice ids available in the project: voice_styles/*.json in the model folder, else the 10 built-ins.</summary>
        public static string[] AvailableVoices()
        {
            if (_cachedVoices != null && EditorApplication.timeSinceStartup - _cacheTime < 5) return _cachedVoices;
            var list = new List<string>(ModelLocator.BuiltInVoices);
            string dir = Path.Combine(TTSModelSetup.StreamingRoot(TTSModelSetup.FindSettings()), ModelLocator.VoiceSubfolder);
            if (Directory.Exists(dir))
                foreach (var f in Directory.GetFiles(dir, "*.json"))
                {
                    var name = Path.GetFileNameWithoutExtension(f);
                    if (!list.Contains(name)) list.Add(name);
                }
            // Female first, then male, then anything custom
            _cachedVoices = list.OrderBy(v => v.StartsWith("F") ? 0 : v.StartsWith("M") ? 1 : 2).ThenBy(v => v).ToArray();
            _cacheTime = EditorApplication.timeSinceStartup;
            return _cachedVoices;
        }

        public static string Label(string id)
        {
            if (id.Length == 2 && char.IsDigit(id[1]))
            {
                if (id[0] == 'F') return $"Female {id[1]}  ({id})";
                if (id[0] == 'M') return $"Male {id[1]}  ({id})";
            }
            return $"{id}  (custom voice file)";
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (property.propertyType != SerializedPropertyType.String) { EditorGUI.PropertyField(position, property, label); return; }
            var attr = (TTSVoiceAttribute)attribute;

            var ids = new List<string>();
            var labels = new List<GUIContent>();
            if (attr.allowDefault) { ids.Add(""); labels.Add(new GUIContent("(Use default)")); }
            foreach (var v in AvailableVoices()) { ids.Add(v); labels.Add(new GUIContent(Label(v))); }

            string current = property.stringValue ?? "";
            int index = ids.IndexOf(current);
            if (index < 0)
            {
                // Keep values set from code (e.g. a blended voice registered at runtime) instead of overwriting them.
                ids.Add(current);
                labels.Add(new GUIContent($"{current}  (registered at runtime)"));
                index = ids.Count - 1;
            }

            EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            int picked = EditorGUI.Popup(position, label, index, labels.ToArray());
            if (EditorGUI.EndChangeCheck()) property.stringValue = ids[picked];
            EditorGUI.EndProperty();
        }
    }

    [CustomPropertyDrawer(typeof(TTSLanguageAttribute))]
    public class TTSLanguageDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (property.propertyType != SerializedPropertyType.String) { EditorGUI.PropertyField(position, property, label); return; }
            var attr = (TTSLanguageAttribute)attribute;

            var ids = new List<string>();
            var labels = new List<GUIContent>();
            if (attr.allowDefault) { ids.Add(""); labels.Add(new GUIContent("(Use default)")); }
            foreach (var code in TTSLanguages.All.OrderBy(TTSLanguages.DisplayName))
            {
                ids.Add(code);
                labels.Add(new GUIContent($"{TTSLanguages.DisplayName(code)} ({code})"));
            }

            string current = property.stringValue ?? "";
            int index = ids.IndexOf(current);
            if (index < 0)
            {
                ids.Add(current);
                labels.Add(new GUIContent($"{current} (unsupported!)"));
                index = ids.Count - 1;
            }

            EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            int picked = EditorGUI.Popup(position, label, index, labels.ToArray());
            if (EditorGUI.EndChangeCheck()) property.stringValue = ids[picked];
            EditorGUI.EndProperty();
        }
    }
}

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    /// <summary>Draws "tick to override" values as  [✓] Label  [value]  — value greyed out until ticked.</summary>
    [CustomPropertyDrawer(typeof(TTSOverrideValue), true)]
    public class TTSOverrideValueDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var state = property.FindPropertyRelative("overrideState");
            var value = property.FindPropertyRelative("value");
            if (state == null || value == null) { EditorGUI.PropertyField(position, property, label, true); return; }

            EditorGUI.BeginProperty(position, label, property);
            var toggleRect = new Rect(position.x, position.y, 18f, EditorGUIUtility.singleLineHeight);
            state.boolValue = EditorGUI.Toggle(toggleRect, state.boolValue);

            var fieldRect = new Rect(position.x + 20f, position.y, position.width - 20f, EditorGUIUtility.singleLineHeight);
            using (new EditorGUI.DisabledScope(!state.boolValue))
            {
                var type = fieldInfo.FieldType;
                var range = (TTSOverrideRangeAttribute)System.Attribute.GetCustomAttribute(fieldInfo, typeof(TTSOverrideRangeAttribute));
                if (type == typeof(OverrideVoice))
                    DrawPopup(fieldRect, label, value, TTSVoiceDrawer.AvailableVoices(), TTSVoiceDrawer.Label);
                else if (type == typeof(OverrideLanguage))
                    DrawPopup(fieldRect, label, value, TTSLanguages.All, c => $"{TTSLanguages.DisplayName(c)} ({c})");
                else if (range != null && value.propertyType == SerializedPropertyType.Float)
                    value.floatValue = EditorGUI.Slider(fieldRect, label, value.floatValue, range.min, range.max);
                else if (range != null && value.propertyType == SerializedPropertyType.Integer)
                    value.intValue = EditorGUI.IntSlider(fieldRect, label, value.intValue, (int)range.min, (int)range.max);
                else
                    EditorGUI.PropertyField(fieldRect, value, label);
            }
            EditorGUI.EndProperty();
        }

        static void DrawPopup(Rect rect, GUIContent label, SerializedProperty value, string[] ids, System.Func<string, string> name)
        {
            int index = System.Array.IndexOf(ids, value.stringValue);
            var labels = ids.Select(i => new GUIContent(name(i))).ToList();
            if (index < 0) { labels.Add(new GUIContent($"{value.stringValue} (custom)")); index = labels.Count - 1; }
            int picked = EditorGUI.Popup(rect, label, index, labels.ToArray());
            if (picked < ids.Length) value.stringValue = ids[picked];
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label) => EditorGUIUtility.singleLineHeight;
    }

    /// <summary>Lets edit-mode code (previews, Inspector) resolve overrides against the project's settings asset.</summary>
    [InitializeOnLoad]
    static class TTSEditorSettingsHook
    {
        static TTSEditorSettingsHook() => EditorApplication.delayCall += () => TTSOverride.EditorDefaultSettings = TTSModelSetup.FindSettings();
    }
}
