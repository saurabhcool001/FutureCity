// FutureCity Offline TTS — word timings for baked clips (Editor).
// Creates TTSClipTiming assets for any AudioClip + its script (human voice-over, other TTS, baked WAVs),
// adds them to the timing library and links the library to the settings asset, so word highlighting
// follows those clips at runtime.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    /// <summary>Editor hook: Play mode finds timing assets even if they're missing from the linked library (with a warning).</summary>
    [InitializeOnLoad]
    static class TTSTimingEditorHook
    {
        static TTSTimingEditorHook()
        {
            TTSClipTimings.EditorFallback = TTSTimingAssets.FindTimingAssetCached;
            EditorApplication.projectChanged += () => { TTSTimingAssets.InvalidateIndex(); TTSClipTimings.ClearMissCache(); };
        }
    }

    public static class TTSTimingAssets
    {
        public const string DefaultLibraryPath = TTSModelSetup.SettingsFolder + "/TTSTimingLibrary.asset";

        /// <summary>The library new timings go into: the first one already linked in settings, else the default (created if needed).</summary>
        public static TTSClipTimingLibrary GetOrCreateLibrary()
        {
            var settings = TTSModelSetup.FindOrCreateSettings(out _);
            var linked = settings.timingLibraries?.FirstOrDefault(l => l != null);
            if (linked != null) return linked;

            var lib = AssetDatabase.LoadAssetAtPath<TTSClipTimingLibrary>(DefaultLibraryPath);
            if (lib == null)
            {
                TTSModelSetup.EnsureAssetFolder(TTSModelSetup.SettingsFolder);
                lib = ScriptableObject.CreateInstance<TTSClipTimingLibrary>();
                AssetDatabase.CreateAsset(lib, DefaultLibraryPath);
            }
            LinkToSettings(settings, lib);
            return lib;
        }

        public static void LinkToSettings(TTSSettings settings, TTSClipTimingLibrary lib)
        {
            if (settings == null || lib == null) return;
            var list = (settings.timingLibraries ?? new TTSClipTimingLibrary[0]).Where(l => l != null).ToList();
            if (list.Contains(lib)) return;
            Undo.RecordObject(settings, "Link timing library");
            list.Add(lib);
            settings.timingLibraries = list.ToArray();
            EditorUtility.SetDirty(settings);
        }

        /// <summary>Creates or updates "&lt;clip&gt;_Timing.asset" next to the clip and adds it to the library.</summary>
        public static TTSClipTiming SaveTiming(AudioClip clip, string text, TTSWordTiming[] words, TTSClipTiming.TimingSource source,
                                               TTSClipTimingLibrary library = null)
        {
            string clipPath = AssetDatabase.GetAssetPath(clip);
            string dir = string.IsNullOrEmpty(clipPath) ? TTSModelSetup.SettingsFolder : Path.GetDirectoryName(clipPath).Replace('\\', '/');
            string path = $"{dir}/{clip.name}_Timing.asset";

            var timing = AssetDatabase.LoadAssetAtPath<TTSClipTiming>(path);
            if (timing == null)
            {
                timing = ScriptableObject.CreateInstance<TTSClipTiming>();
                AssetDatabase.CreateAsset(timing, path);
            }
            Undo.RecordObject(timing, "Update word timing");
            timing.clip = clip;
            timing.text = text;
            timing.words = words ?? Array.Empty<TTSWordTiming>();
            timing.source = source;
            timing.StoreClipIdentity();
            EditorUtility.SetDirty(timing);

            library ??= GetOrCreateLibrary();
            Undo.RecordObject(library, "Add word timing");
            library.Add(timing);
            EditorUtility.SetDirty(library);
            TTSClipTimings.Register(timing);
            return timing;
        }

        static Dictionary<AudioClip, TTSClipTiming> _index;

        public static void InvalidateIndex() => _index = null;

        /// <summary>
        /// Fast lookup for Play mode: one project scan builds a clip → timing index, reused until the project changes.
        /// </summary>
        public static TTSClipTiming FindTimingAssetCached(AudioClip clip)
        {
            if (clip == null) return null;
            if (_index == null)
            {
                _index = new Dictionary<AudioClip, TTSClipTiming>();
                foreach (var guid in AssetDatabase.FindAssets("t:TTSClipTiming"))
                {
                    var t = AssetDatabase.LoadAssetAtPath<TTSClipTiming>(AssetDatabase.GUIDToAssetPath(guid));
                    if (t != null && t.clip != null) _index[t.clip] = t;
                }
            }
            return _index.TryGetValue(clip, out var timing) ? timing : null;
        }

        /// <summary>Finds the timing asset for a clip anywhere in the project (next to the clip first).</summary>
        public static TTSClipTiming FindTimingAsset(AudioClip clip)
        {
            if (clip == null) return null;
            string clipPath = AssetDatabase.GetAssetPath(clip);
            if (!string.IsNullOrEmpty(clipPath))
            {
                var nextTo = AssetDatabase.LoadAssetAtPath<TTSClipTiming>(
                    $"{Path.GetDirectoryName(clipPath).Replace('\\', '/')}/{clip.name}_Timing.asset");
                if (nextTo != null && nextTo.clip == clip) return nextTo;
            }
            foreach (var guid in AssetDatabase.FindAssets("t:TTSClipTiming"))
            {
                var t = AssetDatabase.LoadAssetAtPath<TTSClipTiming>(AssetDatabase.GUIDToAssetPath(guid));
                if (t != null && t.clip == clip) return t;
            }
            return null;
        }

        /// <summary>
        /// Makes every timing asset in the project available in builds: adds them all to the timing library,
        /// links the library to EVERY settings asset in the project, and preloads the library.
        /// Runs automatically before each build, after baking, and from Repair Timing Library.
        /// </summary>
        public static (TTSClipTimingLibrary library, int total, int added, int noClip) SyncAllTimings()
        {
            var library = GetOrCreateLibrary();
            int added = 0, noClip = 0;
            Undo.RecordObject(library, "Sync timing library");
            foreach (var guid in AssetDatabase.FindAssets("t:TTSClipTiming"))
            {
                var t = AssetDatabase.LoadAssetAtPath<TTSClipTiming>(AssetDatabase.GUIDToAssetPath(guid));
                if (t == null) continue;
                if (t.clip == null) { noClip++; continue; }
                if (t.clipName != t.clip.name || Mathf.Abs(t.clipLength - t.clip.length) > 0.001f)
                {
                    t.StoreClipIdentity();            // name + length for Addressables / AssetBundles matching
                    EditorUtility.SetDirty(t);
                }
                if (!library.timings.Contains(t)) { library.Add(t); added++; }
            }
            library.timings.RemoveAll(t => t == null);
            EditorUtility.SetDirty(library);

            // Link to every settings asset, so it doesn't matter which one a scene's [OfflineTTS] uses.
            foreach (var path in TTSModelSetup.FindSettingsPaths())
                LinkToSettings(AssetDatabase.LoadAssetAtPath<TTSSettings>(path), library);

            EnsurePreloaded(library);
            AssetDatabase.SaveAssets();
            return (library, library.timings.Count, added, noClip);
        }

        /// <summary>Adds an asset to Player Settings ▸ Preloaded Assets (so builds load it at startup).</summary>
        public static void EnsurePreloaded(UnityEngine.Object asset)
        {
            if (asset == null) return;
            var preloaded = PlayerSettings.GetPreloadedAssets().Where(a => a != null).ToList();
            if (preloaded.Contains(asset)) return;
            preloaded.Add(asset);
            PlayerSettings.SetPreloadedAssets(preloaded.ToArray());
            Debug.Log($"[OfflineTTS] Added {AssetDatabase.GetAssetPath(asset)} to Player Settings ▸ Preloaded Assets.");
        }

        [MenuItem("FutureCity/Plugins/OfflineTTS/Repair Timing Library", priority = 23)]
        public static void RepairLibrary()
        {
            var (library, total, added, noClip) = SyncAllTimings();
            string msg = $"Timing library: {total} timings ({added} added)." +
                         (noClip > 0 ? $" {noClip} timing asset(s) have no clip assigned and were skipped." : "") +
                         $"\nLibrary: {AssetDatabase.GetAssetPath(library)}\n" +
                         $"Linked to {TTSModelSetup.FindSettingsPaths().Length} settings asset(s) and added to Preloaded Assets, " +
                         "so these timings are included in builds.";
            Debug.Log("[OfflineTTS] " + msg);
            EditorUtility.DisplayDialog("Repair Timing Library", msg, "OK");
            Selection.activeObject = library;
        }

        /// <summary>
        /// Mono samples of an AudioClip asset. If the clip's import settings don't allow reading
        /// (compressed / streaming), it's temporarily re-imported as Decompress On Load, then restored.
        /// </summary>
        public static bool TryReadSamples(AudioClip clip, out float[] mono, out int sampleRate)
        {
            mono = null; sampleRate = 0;
            if (clip == null) return false;
            if (ReadDirect(clip, out mono, out sampleRate)) return true;

            string path = AssetDatabase.GetAssetPath(clip);
            if (!(AssetImporter.GetAtPath(path) is AudioImporter importer)) return false;
            // The sample settings struct also holds Preload Audio Data (it moved there in Unity 2022.2),
            // so restoring the original struct restores everything we change here.
            var original = importer.defaultSampleSettings;
#if !UNITY_2022_2_OR_NEWER
            bool originalPreload = importer.preloadAudioData;
#endif
            try
            {
                var temp = original;
                temp.loadType = AudioClipLoadType.DecompressOnLoad;
#if UNITY_2022_2_OR_NEWER
                temp.preloadAudioData = true;
#else
                importer.preloadAudioData = true;
#endif
                importer.defaultSampleSettings = temp;
                importer.SaveAndReimport();
                clip = AssetDatabase.LoadAssetAtPath<AudioClip>(path);
                return ReadDirect(clip, out mono, out sampleRate);
            }
            finally
            {
                importer.defaultSampleSettings = original;
#if !UNITY_2022_2_OR_NEWER
                importer.preloadAudioData = originalPreload;
#endif
                importer.SaveAndReimport();
            }
        }

        static bool ReadDirect(AudioClip clip, out float[] mono, out int sampleRate)
        {
            mono = null; sampleRate = clip.frequency;
            try
            {
                if (clip.loadState != AudioDataLoadState.Loaded) clip.LoadAudioData();
                int channels = Mathf.Max(1, clip.channels);
                var data = new float[clip.samples * channels];
                if (!clip.GetData(data, 0)) return false;
                mono = new float[clip.samples];
                for (int i = 0; i < clip.samples; i++)
                {
                    float sum = 0f;
                    for (int c = 0; c < channels; c++) sum += data[i * channels + c];
                    mono[i] = sum / channels;
                }
                return true;
            }
            catch (Exception) { return false; }
        }

        /// <summary>Estimates word timings for any speech clip from its audio and script.</summary>
        public static bool TryEstimate(AudioClip clip, string text, out TTSWordTiming[] words)
        {
            words = null;
            if (!TryReadSamples(clip, out var mono, out int sr)) return false;
            words = WordTimingEstimator.EstimateLine(TTSText.ToSpeakable(text), mono, sr, chunkSilence: 0.25f, maxChunkLength: 300);
            return words != null && words.Length > 0;
        }
    }

    // ------------------------------------------------------------------ timing asset inspector

    [CustomEditor(typeof(TTSClipTiming))]
    public class TTSClipTimingEditor : UnityEditor.Editor
    {
        bool _showWords = true;

        public override void OnInspectorGUI()
        {
            var t = (TTSClipTiming)target;
            serializedObject.Update();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("clip"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("text"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("source"));
            serializedObject.ApplyModifiedProperties();

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(t.clip == null))
                {
                    if (GUILayout.Button(new GUIContent("Play clip", "Listen to the clip in the Editor.")) &&
                        TTSTimingAssets.TryReadSamples(t.clip, out var mono, out int sr))
                        EditorAudioPreview.Play(mono, sr, t.clip.name);
                    if (GUILayout.Button(new GUIContent("Re-estimate timings",
                            "Recalculate the word timings from the clip's audio and the Text above (e.g. after editing the text).")))
                    {
                        if (TTSTimingAssets.TryEstimate(t.clip, t.text, out var words))
                        {
                            Undo.RecordObject(t, "Re-estimate word timings");
                            t.words = words;
                            t.source = TTSClipTiming.TimingSource.EstimatedFromRecording;
                            EditorUtility.SetDirty(t);
                        }
                        else Debug.LogWarning("[OfflineTTS] Couldn't read this clip's audio.");
                    }
                }
            }

            var spoken = TTSText.Words(TTSText.ToSpeakable(t.text ?? ""));
            _showWords = EditorGUILayout.Foldout(_showWords, $"Words ({t.words?.Length ?? 0})", true);
            if (_showWords && t.words != null)
            {
                using (new EditorGUI.DisabledScope(true))
                    foreach (var w in t.words)
                    {
                        string word = w.wordIndex >= 0 && w.wordIndex < spoken.Count ? spoken[w.wordIndex] : "?";
                        EditorGUILayout.LabelField(word, $"{w.start:0.00}s – {w.end:0.00}s");
                    }
            }
            if (t.words != null && t.words.Length != spoken.Count)
                EditorGUILayout.HelpBox($"The text has {spoken.Count} words but there are {t.words.Length} timings. Press Re-estimate timings.", MessageType.Warning);
        }
    }
}
