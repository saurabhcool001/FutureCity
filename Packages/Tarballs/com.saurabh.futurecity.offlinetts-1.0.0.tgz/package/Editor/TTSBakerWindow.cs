// FutureCity Offline TTS — Voice-over baker.
// Generates WAV assets in the Editor: use them in Timeline, as pre-recorded NPC dialogue,
// in Unity Recorder captures, or export them to a video editor.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace SaurabhFutureCity.OfflineTTS.Editor
{
    public class TTSBakerWindow : EditorWindow
    {
        TTSSettings _settings;
        string _voice = "F1";
        string _language = "en";
        int _steps = 8;
        float _speed = 1.05f;
        int _seed = 42;
        bool _batchMode;
        string _fileName = "line_001";
        string _text = "Before lifting, check the weight of the load and plan your route.";
        string _batch = "intro_01 | Welcome to the manual handling module.\nintro_02 | Today you will learn how to lift safely.";
        string _outputFolder = DefaultOutputFolder;
        bool _saveTimings = true;

        /// <summary>Default location for baked clips (created automatically).</summary>
        public const string DefaultOutputFolder = TTSModelSetup.SettingsFolder + "/TTS_Baked";
        Vector2 _scroll;

        // Preview voice blending
        bool _blend;
        string _blendWith = "M1";
        float _blendAmount = 0.5f;

        SupertonicEngine _engine;
        string _engineRoot;

        [MenuItem("FutureCity/Plugins/OfflineTTS/Voice-over Baker", priority = 20)]
        static void Open() => GetWindow<TTSBakerWindow>("TTS Baker").minSize = new Vector2(420, 520);

        void OnEnable()
        {
            if (_settings == null) _settings = TTSModelSetup.FindSettings();
        }

        void OnDisable()
        {
            _engine?.Dispose();
            _engine = null;
        }

        string Root => _settings != null && _settings.location == ModelLocation.AbsolutePath
            ? _settings.modelFolder
            : TTSModelSetup.StreamingRoot(_settings);

        string[] AvailableVoices()
        {
            string dir = Path.Combine(Root, ModelLocator.VoiceSubfolder);
            return Directory.Exists(dir)
                ? Directory.GetFiles(dir, "*.json").Select(f => Path.GetFileNameWithoutExtension(f)).OrderBy(n => n).ToArray()
                : ModelLocator.BuiltInVoices;
        }

        void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            _settings = (TTSSettings)EditorGUILayout.ObjectField(new GUIContent("Settings",
                "Settings asset used to find the model files. Filled automatically with the project's existing settings asset."),
                _settings, typeof(TTSSettings), false);

            if (!Directory.Exists(Path.Combine(Root, ModelLocator.OnnxSubfolder)))
            {
                EditorGUILayout.HelpBox($"Models not found in {Root}", MessageType.Warning);
                if (GUILayout.Button("Download Supertonic 3 models")) TTSModelSetup.DownloadModels();
                TTSModelSetup.BaseUrl = EditorGUILayout.TextField(new GUIContent("Model URL",
                    "Where the model downloader gets the Supertonic 3 files from. Change only if you host a mirror."), TTSModelSetup.BaseUrl);
                EditorGUILayout.EndScrollView();
                return;
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Voice", EditorStyles.boldLabel);
            var voices = AvailableVoices();
            _voice = Popup(new GUIContent("Voice", "Voice for every line in this bake. Female 1–5 (F1–F5) or Male 1–5 (M1–M5)."), _voice, voices, true);
            _blend = EditorGUILayout.Toggle(new GUIContent("Blend with another voice",
                "Mix two preset voices to create a new, distinct voice (useful when you need more than 10 characters)."), _blend);
            if (_blend)
            {
                EditorGUI.indentLevel++;
                _blendWith = Popup(new GUIContent("Second voice", "The voice to blend towards."), _blendWith, voices, true);
                _blendAmount = EditorGUILayout.Slider(new GUIContent("Amount",
                    "0 = only the first voice, 1 = only the second voice, 0.5 = halfway between them."), _blendAmount, 0f, 1f);
                EditorGUI.indentLevel--;
            }
            _language = Popup(new GUIContent("Language", "Language the script is written in (TTS does not translate)."), _language, TTSLanguages.All, false);
            _steps = EditorGUILayout.IntSlider(new GUIContent("Quality steps",
                "Denoising steps per sentence. 8 = reference quality. Baking happens offline, so 8–12 is a good choice."), _steps, 1, 16);
            _speed = EditorGUILayout.Slider(new GUIContent("Speed", "Speaking rate. 1.0 = natural, < 1 slower, > 1 faster (pitch unchanged)."), _speed, 0.5f, 2f);
            _seed = EditorGUILayout.IntField(new GUIContent("Seed",
                "Same seed + text + voice = exactly the same audio, so re-baking is reproducible. " +
                "Change the number to get a different take (intonation) of the same lines."), _seed);
            _saveTimings = EditorGUILayout.Toggle(new GUIContent("Save word timings",
                "Also save a word-timing asset next to each WAV (<name>_Timing.asset) and add it to the timing library, so the " +
                "spoken word is highlighted when the baked clip plays on an AudioSource that has a TTS Speaker."), _saveTimings);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Script", EditorStyles.boldLabel);
            _batchMode = GUILayout.Toolbar(_batchMode ? 1 : 0, new[]
            {
                new GUIContent("Single line", "Bake one line to one WAV file."),
                new GUIContent("Batch (id | text per line)",
                    "One WAV per line. Format: file_id | text to speak.\nLines without '|' are numbered line_001, line_002…\n" +
                    "Lines starting with # are ignored. CSV (id,text) files can be loaded too."),
            }) == 1;
            if (_batchMode)
            {
                _batch = EditorGUILayout.TextArea(_batch, GUILayout.MinHeight(160));
                if (GUILayout.Button(new GUIContent("Load from .txt / .csv",
                    "Load a script file: 'id | text' per line, or CSV with id,text columns."))) LoadBatchFile();
            }
            else
            {
                _fileName = EditorGUILayout.TextField(new GUIContent("File name", "Name of the WAV file (without .wav). Invalid characters become _."), _fileName);
                _text = EditorGUILayout.TextArea(_text, GUILayout.MinHeight(80));
            }

            EditorGUILayout.Space();
            using (new EditorGUILayout.HorizontalScope())
            {
                _outputFolder = EditorGUILayout.TextField(new GUIContent("Output folder",
                    $"Project folder the WAV files are written to (created if missing). Default: {DefaultOutputFolder}.\n" +
                    "Existing files with the same name are overwritten."), _outputFolder);
                if (GUILayout.Button(new GUIContent("…", "Pick a folder inside Assets"), GUILayout.Width(28)))
                {
                    var picked = EditorUtility.OpenFolderPanel("Output folder", "Assets", "");
                    if (!string.IsNullOrEmpty(picked) && picked.StartsWith(Application.dataPath))
                        _outputFolder = "Assets" + picked.Substring(Application.dataPath.Length);
                }
            }

            EditorGUILayout.Space();
            using (new EditorGUILayout.HorizontalScope())
            {
                if (!_batchMode && GUILayout.Button(new GUIContent("Preview", "Generate and play the line in the Editor without saving."), GUILayout.Height(30))) Preview();
                if (GUILayout.Button(new GUIContent(_batchMode ? "Bake all to WAV" : "Bake to WAV",
                        "Generate the WAV file(s) into the output folder and import them as AudioClips."), GUILayout.Height(30))) Bake();
                if (GUILayout.Button(new GUIContent("Reset folder", $"Set the output folder back to {DefaultOutputFolder}"),
                        GUILayout.Width(90), GUILayout.Height(30))) _outputFolder = DefaultOutputFolder;
            }

            EditorGUILayout.HelpBox(
                "Baked WAVs work in Timeline Audio Tracks, as normal NPC dialogue clips (lip sync reads them like recorded VO), " +
                "and can be dropped into any video editor. Keep the seed fixed for reproducible takes.",
                MessageType.Info);

            EditorGUILayout.EndScrollView();
        }

        static string Popup(GUIContent label, string value, string[] options, bool voices)
        {
            if (options.Length == 0) return value;
            int i = Math.Max(0, Array.IndexOf(options, value));
            var shown = options.Select(o => new GUIContent(voices ? TTSVoiceDrawer.Label(o)
                                                                  : $"{TTSLanguages.DisplayName(o)} ({o})")).ToArray();
            return options[EditorGUILayout.Popup(label, i, shown)];
        }

        SupertonicEngine Engine()
        {
            if (_engine != null && _engineRoot == Root) return _engine;
            _engine?.Dispose();
            EditorUtility.DisplayProgressBar("Offline TTS", "Loading models…", 0.2f);
            try
            {
                _engine = new SupertonicEngine(ModelLocator.OnnxDir(Root), EngineOptions.Default);
                _engineRoot = Root;
            }
            finally { EditorUtility.ClearProgressBar(); }
            return _engine;
        }

        VoiceStyle LoadVoice()
        {
            var a = VoiceStyle.FromFile(ModelLocator.VoicePath(Root, _voice));
            if (!_blend) return a;
            var b = VoiceStyle.FromFile(ModelLocator.VoicePath(Root, _blendWith));
            return VoiceStyle.Blend(a, b, _blendAmount);
        }

        SynthesisParams Params() => new SynthesisParams { Steps = _steps, Speed = _speed, ChunkSilence = 0.3f, Seed = _seed };

        void Preview()
        {
            try
            {
                var engine = Engine();
                var samples = engine.Synthesize(_text, _language, LoadVoice(), Params());
                WavUtility.ApplyEdgeFade(samples, engine.SampleRate);
                EditorAudioPreview.Play(samples, engine.SampleRate);
            }
            catch (Exception e) { Debug.LogError($"[OfflineTTS] Preview failed: {e}"); }
        }

        void Bake()
        {
            var jobs = _batchMode ? ParseBatch(_batch) : new List<(string, string)> { (_fileName, _text) };
            if (jobs.Count == 0) { Debug.LogWarning("[OfflineTTS] Nothing to bake."); return; }

            if (!_outputFolder.StartsWith("Assets"))
            {
                EditorUtility.DisplayDialog("TTS Baker", "The output folder must be inside the project's Assets folder.", "OK");
                return;
            }
            _outputFolder = _outputFolder.TrimEnd('/');
            TTSModelSetup.EnsureAssetFolder(_outputFolder);
            string folderAbs = Path.GetFullPath(_outputFolder);
            var written = new List<string>();
            var timings = new List<(string assetPath, string text, TTSWordTiming[] words)>();
            try
            {
                var engine = Engine();
                var voice = LoadVoice();
                for (int i = 0; i < jobs.Count; i++)
                {
                    var (id, line) = jobs[i];
                    if (EditorUtility.DisplayCancelableProgressBar("Baking voice-over", $"{id}: {Trim(line)}", i / (float)jobs.Count)) break;

                    var (samples, words) = SynthesizeWithTimings(engine, line, voice);
                    string fileName = Sanitize(id) + ".wav";
                    WavUtility.Save(Path.Combine(folderAbs, fileName), samples, engine.SampleRate);
                    written.Add(fileName);
                    timings.Add(($"{_outputFolder}/{fileName}", TTSText.ToSpeakable(line), words));
                }
            }
            catch (Exception e) { Debug.LogError($"[OfflineTTS] Bake failed: {e}"); }
            finally { EditorUtility.ClearProgressBar(); }

            AssetDatabase.Refresh();

            if (_saveTimings && timings.Count > 0)
            {
                var library = TTSTimingAssets.GetOrCreateLibrary();
                foreach (var (assetPath, text, words) in timings)
                {
                    var clip = AssetDatabase.LoadAssetAtPath<AudioClip>(assetPath);
                    if (clip != null) TTSTimingAssets.SaveTiming(clip, text, words, TTSClipTiming.TimingSource.BakedTTS, library);
                }
                TTSTimingAssets.SyncAllTimings();   // link to every settings asset + preload, so builds include them
            }
            Debug.Log($"[OfflineTTS] Baked {written.Count} clip(s) to {_outputFolder}" + (_saveTimings ? " (with word timings)" : ""));
            if (written.Count > 0)
                EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(
                    _outputFolder + "/" + written[written.Count - 1]));
        }

        /// <summary>
        /// Synthesises like the live speaker does (sentence by sentence, joined with the chunk silence) and records
        /// exact per-sentence word timings on the way, so the baked clip highlights the same as live TTS.
        /// </summary>
        (float[] samples, TTSWordTiming[] words) SynthesizeWithTimings(SupertonicEngine engine, string line, VoiceStyle voice)
        {
            var p = Params();
            int sr = engine.SampleRate;
            int silence = Mathf.Max(0, (int)(p.ChunkSilence * sr));
            var all = new List<float>();
            var words = new List<TTSWordTiming>();
            int wordIndex = 0;
            foreach (var (chunkText, chunk) in engine.SynthesizeChunksWithText(TTSText.ToSpeakable(line), _language, voice, p))
            {
                if (all.Count > 0 && silence > 0) all.AddRange(new float[silence]);
                WavUtility.ApplyEdgeFade(chunk, sr);
                int offset = all.Count;
                all.AddRange(chunk);
                var chunkWords = TTSText.Words(chunkText);
                var t = WordTimingEstimator.EstimateChunk(chunkWords, chunk, 0, chunk.Length, sr, wordIndex);
                for (int i = 0; i < t.Length; i++) { t[i].start += offset / (float)sr; t[i].end += offset / (float)sr; }
                words.AddRange(t);
                wordIndex += chunkWords.Count;
            }
            return (all.ToArray(), words.ToArray());
        }

        void LoadBatchFile()
        {
            string path = EditorUtility.OpenFilePanel("Script", "", "txt,csv");
            if (string.IsNullOrEmpty(path)) return;
            var lines = File.ReadAllLines(path).Select(l =>
            {
                // Accept "id,text" CSV as well as "id | text"
                if (l.Contains("|")) return l;
                int comma = l.IndexOf(',');
                return comma > 0 ? l.Substring(0, comma) + " | " + l.Substring(comma + 1).Trim().Trim('"') : l;
            });
            _batch = string.Join("\n", lines);
        }

        static List<(string id, string text)> ParseBatch(string batch)
        {
            var result = new List<(string, string)>();
            int n = 1;
            foreach (var raw in batch.Split('\n'))
            {
                var l = raw.Trim();
                if (l.Length == 0 || l.StartsWith("#")) continue;
                int bar = l.IndexOf('|');
                if (bar > 0) result.Add((l.Substring(0, bar).Trim(), l.Substring(bar + 1).Trim()));
                else result.Add(($"line_{n:000}", l));
                n++;
            }
            return result;
        }

        static string Sanitize(string s) => Regex.Replace(s, @"[^A-Za-z0-9_\-]", "_");
        static string Trim(string s) => s.Length > 50 ? s.Substring(0, 50) + "…" : s;
    }
}
